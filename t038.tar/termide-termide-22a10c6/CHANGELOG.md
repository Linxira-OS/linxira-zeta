# Changelog

All notable changes to TermIDE will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.38.0] - 2026-10-04

[0.38.0]: https://github.com/termide/termide/releases/tag/0.38.0

### Added
- **Projects stay open in the background.** Switching to another project no longer closes the one you leave: programs in its terminals keep running, its agents keep working and unsaved edits stay as they were. A project stays open until you close it or quit. The `Projects` menu and the `Alt+\` switcher list the same projects in one flat list — the open ones first, sorted by path, then the others, the most recently used first, with the time you last worked on them. ● marks the current project, ○ one open in the background and 🔔 one whose panel waits for you (an agent's question or finished work, a terminal bell); while any does, the `Projects` title is highlighted. `Alt+\` then `Enter` goes back to the project you left last. `Delete`/`F8` closes a background project, or deletes the saved layout of one that is not open, after a confirmation; quitting names the background projects that still run something. `prev_project`, `next_project` and `goto_project_1`…`goto_project_9` switch by keyboard; they ship unbound, see [`doc/en/keybindings.md`](doc/en/keybindings.md). Requested in [#61](https://github.com/termide/termide/issues/61).
- **Files travel through the system clipboard.** `Ctrl+C` in the file manager puts the selection on the clipboard as files, so Finder, Explorer or a file manager pastes them as files, and `Ctrl+V` (also `Cmd+V`) pastes files copied there into the panel. `Ctrl+X` marks the selection as cut, so the next paste moves it, and the confirmation says Move before anything is deleted; a cut is refused in a remote panel or inside an archive rather than turning into a copy. Paths copied as text paste too. Linux keeps a text-only clipboard. See [`doc/en/file-manager.md`](doc/en/file-manager.md).
- **An `auto` permission mode with a reviewer model.** What would put a permission card up is decided by a separate model call that sees your messages and the agent's calls, never tool results, so content from files and pages cannot talk it into anything. Rules, plan mode and hooks still come first, and a block reaches the agent with its reason. Every call records who decided it. `[ai] auto_reviewer` picks the connection.
- **Rewind to a chosen message.** `Esc` in the empty prompt (or `F4`) lists the messages you sent above the prompt; picking one rewinds the conversation to before it and puts the message back in the input. When files changed since, a card asks whether to restore the files, the conversation or both.
- **Fork a session.** `F5`, `/fork` or the `[≡]` menu copies the session into a new agent panel, which continues from the same point while the original carries on; the copy is named `Refactor (2)`, `(3)` and so on.
- **Run shell commands from the agent prompt.** `$` in the empty prompt turns it into a shell line that runs at once without asking the model; the agent reads the command and its output at your next message. A new `suggest_command` tool lets the agent hand you a command instead of running it, on a card offering Run, Edit first, Copy and Don't run.
- **MCP servers over HTTP.** `url` servers in `.mcp.json` connect over streamable HTTP, with server push, OAuth sign-in (grants kept in `mcp-auth.json`) and `/mcp reload`, `login` and `logout`. `.mcp.json` is read from the panel's directory and every directory above it. Each server keeps one live status line, and the open toolset checklist fills in as servers connect.
- **Save the agent chat as Markdown** with `Ctrl+S`.
- **A livelier welcome banner.** It draws the project logo, is titled by the agent with its description, lists notices that arrived early under it, dates sessions to the minute, and lets a fresh session pick its directory with a click.
- **URLs in the agent chat open with `Ctrl+click`**, and a fetched URL is dimmed.
- **Built-in language servers for PHP, Terraform and Docker** (`phpantom_lsp`, `terraform-ls`, `docker-language-server`, with its telemetry turned off), used automatically when the binary is on `PATH`. Dockerfiles and Compose files are recognized by name. `.tsx` and `.jsx` files now start the TypeScript server.
- **Lua** syntax highlighting and outline.
- **Tabs reach the next tab stop.** A tab used to be drawn one column wide whatever the tab size; it now spans to the next stop everywhere the editor measures text — drawing, the cursor, clicks, wrapping and scrolling.
- **`.` toggles hidden directories in the directory picker.**
- **A bell from a terminal asks for attention**: the header of a terminal panel that is not focused turns the warning colour until you focus it.

### Changed
- **New agent sessions start in `auto` mode.** Pick another starting mode in the settings.
- **Service prompts and the root prompt template are read from the configuration directory only.** A repository can no longer ship a `.termide/ai/system/` or `.termide/ai/AGENTS.md` of its own that changes how the agent summarises, plans or judges, or drops its base guidelines. A project's conventions still reach the prompt through its `AGENTS.md` instructions.
- **Your own `[lsp.servers.*]` entries add to the built-in servers instead of replacing them all**; an entry for a built-in language changes only the fields it sets.
- **The Projects menu is a flat list instead of a directory tree**, and deleting the saved layouts of every project in a directory at once is gone with it. The `Alt+\` switcher shows one row per project with an inverted cursor.
- **Up and down keep the cursor in its screen column**, also across short lines without word wrap.
- **Auto reasoning reaches local servers.** A connection left to `auto` now sends the chat template's `enable_thinking` switch to servers on this machine or the local network (llama.cpp, vLLM, omlx, LM Studio), so their Reasoning chip appears.

### Fixed
- **Pasting a file into its own directory could empty it.** Choosing Overwrite on the conflict truncated the source before copying it onto itself. A copy onto itself now gets the next free name (`notes (1).txt`), a move onto itself does nothing, and copying or moving a directory into itself is refused.
- **A panic in one detached instance could take down every other instance** served by the same daemon; the web tools could likewise fail for good after one error.
- **On Windows, paths showed a `\\?\` prefix** in panel titles, bookmarks, git and the terminal.
- **Diagnostic underlines, completion and code actions sat in the wrong column** on lines with tabs, a repeated diagnostic was counted twice, and git diffs lost the indentation of tab-indented lines.
- **A click in a long, scrolled text field landed on the wrong character** and the field jumped back to its start; the editor's find bar now takes mouse clicks.
- **The status bar misplaced text with wide characters.**
- **The language server could receive requests before it was initialized.**
- **The toolset checklist dropped changes when closed without `Enter`**, and the agent banner's labels were not translated.
- **The rename dialog showed a "Move … to:" hint.**
- **The fullscreen column expanded when a fit-height panel took focus.**
- **russh updated to 0.63** for open security advisories in SSH connections.

## [0.37.0] - 2026-09-30

[0.37.0]: https://github.com/termide/termide/releases/tag/0.37.0

### Added
- **Archives open in the file manager like directories.** `Enter` on a zip, a tar (plain, `.gz`, `.bz2`, `.xz`, `.zst`) or an ISO 9660 image lists it read-only, and `..` or `Backspace` at its root goes back to the directory holding it. Files can be viewed, copied and extracted out of it with progress, pause and cancel; commands that would change the archive are refused up front. Archives open wherever they lie: on the local disk, on a connected server, or inside another archive. An encrypted zip (ZipCrypto or AES) asks for its password, and asks again after a wrong one. Zip names written by Russian Windows (CP866) come out as Cyrillic instead of box drawing, and an ISO image shows its Rock Ridge or Joliet names when it has them. Entry names are treated as untrusted: nothing is ever extracted outside the target directory. See [`doc/en/vfs.md`](doc/en/vfs.md).
- **Pack the selection into an archive with `P`.** The file manager asks where to write it, `<name>.zip` next to the selection by default, and the suffix picks the format: zip or tar (plain, `.gz`, `.bz2`, `.xz`, `.zst`). Permissions, modification times and symlinks are kept, the archive only appears once it is complete, an existing file is never overwritten, and the run shows in the Operations panel. The key is `file_manager.keybindings.pack`.
- **A reasoning level per model.** The **Reasoning** chip now opens a level picker (off, minimal, low, medium, high, xhigh, max) offering what the model accepts, and is hidden when the model cannot be asked. Before, the on/off switch never reached the server, so no model was actually asked to reason. Anthropic models get adaptive thinking or a thinking budget; OpenAI-compatible connections choose how to ask with `reasoning_param` (`reasoning_effort`, the chat template's `enable_thinking`, or nothing). `[ai] reasoning` replaces `prefer_reasoning`, which is still read as `high` or `off`.
- **The prefill shows live.** Until the first token arrives the footer shows how long the model has been reading the prompt and roughly how big it is. With `prefill_progress` on a connection (also in the settings modal), a llama.cpp server reports its progress and the line shows a bar, the tokens read out of the total, and the speed.
- **Recent sessions on the agent's welcome banner.** A fresh session's banner lists the directory's other sessions, newest first. A click or `Enter` opens one, `Tab` moves into the list, and `Delete`/`F8` deletes the session under the cursor. Sessions open in another panel are left out. The banner now sits at the top of the panel, leaving the room below to the list.
- **Save a web page as Markdown.** `Ctrl+S`, or **Save page as Markdown…** in the HTML viewer's `[≡]` menu, saves the page with its headings, lists, code, tables and links, relative links made absolute. Like a reader mode it keeps the page's main content and leaves out navigation, sidebars and footers. Requested in [#56](https://github.com/termide/termide/issues/56).
- **Web pages show that they are loading.** `Ctrl+G` with a URL opens the viewer at once, with a spinner and the URL in its title, and fills it when the page arrives, or shows the error. A followed link keeps the page on screen and spins the title until the next one arrives. Several pages can load at once, and closing a viewer drops its request.
- **`Ctrl+A` in the HTML and Markdown viewers** selects the whole document, so `Ctrl+C` copies the page.
- **Conditional sections in prompt templates.** `{{if name}} … {{else}} … {{/if}}` drops a section when its value is empty. The shipped system prompt uses it to leave out empty sections, such as a skills section in a session without skills.
- **An agent's `tools` list can leave out `task`**, so that agent cannot delegate.
- **Checklist groups toggle from their heading.** In the **Tools** picker, the checkbox on a group's heading switches the whole group, and shows `[-]` while the group is partly on.
- **The AI menu lists agents, skills and prompts with their descriptions.**

### Changed
- **"Allow always" and "for the session" are offered only where the rule can vouch for the calls it will allow.** One click on a permission card could grant `rm *`, `git push *` or `env *`, which also vouches for whatever program `env` runs. A lasting grant now needs a single command whose program is known, and neither lasting grant is offered for a command that destroys what it touches or runs a program its name does not tell. Denying for the session is still offered.
- **The shipped system prompt is shorter.** It no longer lists the tools, which the model already receives with their descriptions. It no longer carries a date, which went stale in a long session and was in UTC; instead it tells the model to check the date, a file or the history with a tool rather than guess, and to say when it did not check.
- **An empty `SOUL.md` means no system prompt.** It used to fall back to the shipped prompt.
- **Modals close on a click outside them**, as they do on `Esc`: selection lists, checklists, input prompts, confirmations and info windows. The pickers the agent panel opens could only be left with `Esc`.
- **The file manager no longer stalls in repositories with huge ignored directories.** Git status used to walk every ignored directory, which took up to 19 seconds per directory load with a large `target/`. A directory that no ignore pattern matches but that holds only ignored files now shows its files dimmed, not the directory itself.
- **File manager statuses and item counts are translated** in all fifteen languages.

### Fixed
- **Indented files scrambled the screen.** Since 0.35.0 a TAB in the editor was written to the terminal as is, so the rest of the row landed at the next tab stop and the screen slowly filled with fragments of earlier frames, on every terminal. Control characters now render as blanks in the editor, the status bar and other text cells. Reported in [#55](https://github.com/termide/termide/issues/55).
- **`Ctrl` shortcuts on a Cyrillic layout.** `Ctrl+С` did not interrupt a program in the terminal; a `Ctrl` chord on a letter of another layout now goes out as the Latin key under the same finger. Text fields (select all, copy, cut, paste, undo), the find bar's `Ctrl+R`, and the letter shortcuts of modals and panels (`y`/`n`, `j`/`k`, `q`, …) now work on any layout too.
- **Copying from a server could copy a local file instead.** A batch copy or move of a remote path that also existed locally (`/etc` on a server) read it from the local disk. Sources now come from the panel they were selected in.
- **A `$(…)` in a command made every part of the line ask**, and answering the card could write rules such as `cd *` or `ls *` to the configuration, which silence the built-in check of those commands' dangerous flags. The substitution now counts only for the part that carries it.
- **Multi-line prompts were shown as one line in the transcript.**
- **Long options and answers of the agent's questions were cut off**; they now wrap.
- **The Save As field could not be selected with the mouse**, and a click on a long path landed on the wrong character. A click now places the cursor, a drag selects, and a paste goes into the field.
- **Going up in a remote panel left the cursor on the old row**; it now lands on the directory just left, as in a local panel.

## [0.36.0] - 2026-09-28

[0.36.0]: https://github.com/termide/termide/releases/tag/0.36.0

### Breaking Changes
- **`--list-sessions` is gone, and shell completions installed by 0.35.0 must be installed again.** A detached run is now an *instance*, and the flag that lists them is `--list-instances`; the old spelling is removed rather than hidden, so a script that still calls it fails loudly instead of quietly getting nothing. The completion scripts that `termide --install-completions` wrote in 0.35.0 call `--list-sessions` to offer the ids after `--attach`, so after upgrading run `termide --install-completions` once more. The `.deb`, `.rpm` and AUR packages update their system-wide copies on their own, but a copy that `--install-completions` placed in your home directory stays as it was and keeps calling the old flag. See the "Session now means one thing" entry below for the rest of the rename.

### Added
- **Built-in coding agent.** A new panel (`Alt+A`, Windows → Agent, or **Open Agent** in the command palette) where you describe a task and a language model carries it out in your project: it reads files, edits them, runs shell commands, searches the web and asks you when a decision is yours. Like a new terminal, the panel works in the directory of the panel that had focus. Each `Alt+A` opens another panel, so several agents can work side by side, and two panels never share one session. An agent panel is saved with the project layout and comes back on the session it was in. See [`doc/en/agent.md`](doc/en/agent.md).
- **A conversation made of foldable blocks.** Your message, the agent's reasoning, each tool call and the answer are separate blocks, each opened by a glyph and an action (`$ Running`, `< Reading src/main.rs`, `± Editing`, `↓ Fetching`, `& Delegating to reviewer`, …). Reasoning and tool calls fold to their one-line headline; `[ai] fold_blocks` (**Fold blocks** in settings) sets whether that happens immediately, once a block finishes, or never. `Ctrl+O` unfolds every block and keeps new ones unfolded until pressed again. `Tab` moves into the chat, where `↑`/`↓` pick a block, `Space`/`Enter` or `→`/`←` unfold and fold it as in the file manager's tree, `o` opens it in its own read-only panel and `Ctrl+C` copies it. A click selects a block and a second click folds it; a mouse drag selects transcript text the way a terminal does. Edits show a coloured diff. Every block carries a dim time and `✓`/`✗`, a tool call its duration (`🕒 6s`), and a turn its prefill and generation figures (`⏫ 6s (↑42k, 7k tok/s)`, `✍️ 12s (↓5k, 420 tok/s)`). While a run works, an animated run clock under the last block counts its total time, and it freezes when the run ends. A fresh session opens on a banner naming the connection, model, agent and tools, each a click away from its picker. The status bar holds the agent, **Permissions**, **Reasoning**, connection and model chips, plus the session's token totals (`↑` billed input, `↻` cache hits, `↓` output) and the context window as a fill bar.
- **The prompt box.** `Enter` sends; text typed while the agent works is queued in a strip above the input and goes out as one message at the next turn, and `↑` takes the queue back to edit. `↑`/`↓` also recall earlier requests. `@` completes a file or directory path from the panel's directory with fuzzy matching (`@srmain` finds `src/main.rs`), leaving out what git ignores. A paste of more than five lines or 2000 characters is held as a `[#1 pasted 40 lines]` placeholder and spliced back in on send; pasting it again unmasks it. The box wraps long lines and grows to half the panel. It selects, cuts, pastes and undoes like every other input. The run controls on its top border pause (`[‖]`), continue (`[▶]`) or stop (`[■]`) a run.
- **Permissions, with five modes.** Nothing that changes the project runs unasked. A card above the input offers allow once, allow for the session, allow always in this project or everywhere, deny, deny for the session, deny with a reason the model reads, or stop the run. Allowing always writes a rule to `[ai.permissions]`. Rules are per tool, and the strictest match wins. A shell command is judged part by part: `cargo build && rm -rf target` needs both halves allowed, termide follows `cd` through the line, and a quoted script or here-document stays one command. Reading inside the project and a list of look-only commands (`ls`, `rg`, `git status`, …) never ask. The **Permissions** chip and `Shift+Tab` switch between `ask`, `plan`, `edit`, `configured` (the default) and `all`, and a change reaches a running task at its next tool call; settings pick the mode new sessions start in. In `plan` mode nothing that could change anything runs; the agent answers with a plan, and a card then offers to carry it out, accepting edits or under the configured rules. A panel waiting on you while out of sight turns its header the warning colour and rings the terminal bell, as does a long run that finished; `bell_on_attention = false` silences the bell.
- **Connections to any model.** Models are configured as named connections under `[ai.connections.<name>]`, each with a `provider`, `base_url`, `model`, `api_key_env` and `context_window_fallback`, and edited on a **Connections** page in the settings modal's new **AI** section. `openai_compatible` covers local servers (llama.cpp, Ollama, vLLM, omlx), OpenAI, OpenRouter, the Gemini API and most gateways, with no key needed for a local server. `anthropic_compatible` speaks Anthropic's Messages API. An API key is read from the environment variable `api_key_env` names and never stored in the config. A connection may leave the model to the provider, and when the endpoint reports a model's context window, the panel uses it; `context_window_fallback` applies only when it does not. The **Connection** and **Model** chips switch a session to another connection or model and carry the conversation over; the session log records both, so a reopened session continues where it ran. **Reasoning** turns extended thinking / `reasoning_effort` on or off per session (`prefer_reasoning`, on by default). By default no output limit is sent (`max_tokens_per_turn = 0`).
- **Claude Code, Codex and Gemini CLI in the same panel.** The `claude_code`, `codex` and `gemini_cli` providers drive those CLIs over the Agent Client Protocol through `npx`, on their own sign-in or subscription; a **Model** chip lists each agent's own models. Claude Code runs on termide's system prompt and tools, served to it over a local MCP server, so every call goes through the same permission mode, rules, plan mode and `/undo` checkpoints as the built-in loop. Codex and Gemini CLI keep their own tools and are put in the approval modes that match the panel's. Any other ACP agent can be added with an `[acp]` table in an agent's `agent.toml`. An external agent's permission requests go through termide's rules and session answers first, so nothing already allowed is asked twice.
- **An `ai` directory for everything the agent reads.** It exists at three levels: the panel's directory, the project root (`.termide/ai/`) and the configuration directory. The system prompt is a template, `AGENTS.md`, assembled from files alone; `/prompt` shows the result. The service prompts are files as well: compaction, plan mode, `/goal`'s judge and `/handoff`. Further agents are directories under `agents/`, with an optional `SOUL.md` and an `agent.toml` naming a description, model, mode and a subset of tools. With more than one agent, a `task` tool hands a self-contained job to another agent, which reports back only its final answer. Skills in the agentskills.io shape (`skills/<name>/SKILL.md`, also `.agents/skills/`) are listed in the prompt and loaded on demand, or sent by hand as `/name args`. Prompt templates (`prompts/<name>.md`) and executable command scripts (`commands/<name>`) run as `/name args`, and a script that came with the project asks first. MCP servers in `mcp.toml` join over stdio as `server__tool`. Command hooks in `hooks.toml` run around tool calls and may block, rewrite or approve them. Shims in `shims/` shadow shell commands to save tokens. The agent follows `AGENTS.md` (or `CLAUDE.md`) files from the filesystem root down to its working directory. The **Tools** chip switches built-in tools, skills and MCP tools off for a session. Shipped files are kept current on upgrade, and a file you edited is left alone, with the new version written beside it as `<file>.new`.
- **Web tools.** `web_search` and `fetch` work through a local Chrome, Chromium, Edge or Brave, on a profile of the agent's own that has none of your logins. The browser runs without a window by default; when a search engine asks for a human check, a window opens to solve it. **Show browser window** in the AI menu shows the browser so you can watch it work. Without such a browser, `fetch` falls back to plain HTTP. `[ai.web]` picks the backend, the search engine (DuckDuckGo, Bing, Google, Yandex, or a file of your own) and the window mode.
- **A `question` tool.** The agent can put up to four questions to you in a card, with a note per choice, one or several picks, and a line for your own answer. Declining stops the run.
- **Sessions, and taking work back.** Every session is a JSON Lines log under `ai/sessions/` in the configuration directory. `F7` starts a new session, `F6` switches between this directory's sessions, `F8` deletes one, `F2` renames it and `F3` shows its details (also `/usage`). The new **AI** menu in the menu bar browses and edits agents, sessions, skills and prompts at both project and global level. A session you never sent anything to is discarded on close. `/undo` restores the files the last request edited or wrote and rewinds the conversation to before it, and `F4` rolls back to a chosen checkpoint. When a session nears the context window, older messages are summarised automatically, and `/compact [focus]` does the same on request. Command output is cleaned for the model before it enters the context: escapes, progress redraws and repeated build lines are stripped, and the passing tests of `cargo test`/`nextest`, `pytest`, `go test`, `jest` and `vitest` are dropped. The raw log stays on disk.
- **Built-in slash commands.** `/new`, `/clear`, `/rename` (`/name`), `/compact`, `/undo`, `/usage` and `/prompt`. `/pause` and `/continue` pause a run between tool calls and resume it. `/loop [interval] <prompt>` re-runs a prompt on an interval or back-to-back. `/goal <what to achieve>` works autonomously until a separate judge call says the goal is reached. `/handoff` writes a brief of the unfinished work, which you can save to `HANDOFF.md` or open as a new session. A built-in command always wins over a template, script or skill of the same name, and names defined more than once are reported.
- **Headless runs.** `termide --prompt "..."` (or `--prompt -` to read the prompt from stdin) runs one task without the UI and prints the answer, for scripts and CI. `--agent` picks the agent, and `--output json` or `stream-json` gives a machine-readable result. With no one to answer a card, it does only what the rules and the mode already allow.
- **Take over or end a detached instance from outside.** `termide --attach <ID> --force` (`-f`) takes an instance over from a client left attached on a locked desktop or behind a hung SSH link, and the displaced client is told so. `termide --kill <ID>` ends a wedged instance with everything running in it, and completion offers ids after `--kill` too. Requested in [#53](https://github.com/termide/termide/issues/53).
- **The Open prompt suggests paths and opens on `Ctrl+G`.** **Windows → Open…** now lists suggestions as you type. A name is matched fuzzily against the project's files, skipping what git ignores; a path starting with `/`, `~/`, `./` or `../` completes from its directory. `Ctrl+G` opens the prompt from every panel except the file manager, where the same suggestions now drive its "go to path", and the terminal, which passes the key through. The Markdown and HTML viewers' own `Ctrl+G` gives way to it. Requested in [#50](https://github.com/termide/termide/issues/50).
- **View a branch without checking it out.** Choosing a branch in Git Status only changes what the panel shows. A branch checked out in the main copy or a linked worktree shows that working copy, and staging, committing, push and pull act in it. A branch checked out nowhere shows how far it is ahead of and behind the main copy's branch, with a `[Checkout]` button; a refused checkout shows git's message as an error. The branch lists in Git Status and Git Log mark the main copy's branch with `●` and a worktree's with `⧉`, and a linked worktree no longer shows up as a repository of its own. `[Log]` opens the log on the same branch.
- **The Projects menu lists every known project as a directory tree.** Single-child chains fold into one row, and the current project is shown in bold. `Delete`/`F8` removes the saved layout of a project, or of every project in a directory, after a confirmation. The current project is never deleted.
- **The system monitor understands APFS.** All volumes of one APFS container share a single space pool, so the disk list shows them as one row instead of six identical ones, with the filesystem type in a second column.

### Changed
- **"Session" now means one thing.** The word used to cover three things: the saved panel layout of a directory, a detached run that outlives its terminal, and now a conversation with the agent. The first two are renamed, so "session" belongs to the agent alone, as it does in every other coding agent. Saved layouts are now **projects**: the menu is `Projects`, and storage moves from `<data>/termide/sessions/` to `<data>/termide/projects/`. Existing layouts are moved across automatically on first launch, whatever an older termide writes to `sessions/` afterwards is folded in on the next launch, and the Journal reports what was moved. A detached run is now an **instance**: `--list-sessions` becomes `--list-instances` (see Breaking Changes), and `Options → Detach session` becomes `Detach instance`. Configuration keeps working as written: `session_retention_days`, `open_sessions`, `new_session` and `detach_session` are still read as `project_retention_days`, `open_projects`, `new_project` and `detach_instance`.
- **The editor follows its file on disk.** A buffer without unsaved work used to show `[changed on disk]` and wait for `Ctrl+Shift+R`, which then put the cursor back at the top. It now reloads by itself when a formatter, a checkout or the agent rewrites the file, and keeps the cursor and scroll position, clamped when the file got shorter; `Ctrl+Shift+R` keeps them too. A buffer with unsaved work behaves as before: it keeps its changes, shows the marker and refuses to save over the newer file.
- **One input bar under every panel.** The find/replace bar and the agent's prompt box are now the same widget, so they type, scroll, place the cursor and take focus the same way. The find/replace bar moves to the **bottom** of the editor, file manager, terminal, markdown, binary and HTML panels (it used to sit at the top). It gains a titled top border — `─ Find ─`, `─ Search ─` or `─ Replace ─` — that doubles as the divider from the content above. `Tab` still moves focus between the bar and the panel body.
- **Every text field edits the same way.** Find bars, settings fields and prompts now share one grammar: character and word movement, `Shift`+arrows and mouse-drag selection, `Ctrl+A`, the clipboard and undo/redo. A settings field used to take only typing and `Backspace`, and a find field could not select at all.
- **Lists that filter as you type rank by fuzzy match.** The command palette, the project switcher, the Git Status repository and branch selectors, and the editor's completion popup all now match fuzzily (fzf syntax: `'exact`, `^prefix`, `suffix$`, `!negated`) and list the best match first. The command palette used to promise fuzzy filtering while doing substring matching; it now also underlines the matched letters.
- **Git Log reads the whole history as you scroll.** The panel stopped at the first 100 commits. It now reads more as the view nears the end, `End` reads to the oldest commit, the scrollbar spans the whole history, and a reload keeps the selected commit in place instead of jumping to the top.
- **F5/F6 copy and move default to the other file manager.** The destination was the alphabetically first panel directory outside the source, so a pane in a subdirectory of the source was skipped, and a terminal or editor counted as much as a file manager. The nearest other file manager now wins, as in two-pane file managers. Prompted by [#54](https://github.com/termide/termide/issues/54).
- **Files given on the command line open where they belong.** `termide inventory.db` or an image used to fail with "Failed to read file", because every path went to the text editor. Text files still open in the editor, so termide stays a drop-in `$EDITOR`, while images, SQLite files, other binaries and directories go where the file manager would send them. Paths are made absolute first, so a language server started for `termide report.py` gets a real workspace root.
- **Markdown tables wrap their cells.** Columns are sized to their content, and a long cell wraps onto extra lines instead of being cut off.
- **Status bars keep their indicators on narrow terminals.** Background operations and disk usage sit flush right, and on a narrow bar the panel's own text is cut with an ellipsis instead of pushing the indicators out.
- **Every checkbox is drawn as `[✓]` or `[ ]`.** Settings used `[✓]`/`[✗]`, other modals `[x]`/`[ ]`, so a cross meant "off" in one place and "on" in another.

### Fixed
- **One bad setting no longer discards the whole configuration.** A value of the wrong type or out of range made the entire file fall back to defaults, and the next save from Settings then wrote those defaults over it. Such a value is now dropped on its own, the file is first copied to `<name>.bak`, and the warnings go to the Journal and to `--diagnostics`.
- **MySQL databases showed no tables.** MySQL 8 reports `information_schema` names as binary strings, which failed to decode, and the error was swallowed, so the panel showed no databases, no tables and every column as "Other". Text filters (`contains`, `starts with`, `ends with`) also failed on MySQL with error 1064, and a connection URL with a trailing space broke the reconnect after picking a database. Contributed by [@MathysHaubert](https://github.com/MathysHaubert) in [#52](https://github.com/termide/termide/pull/52).
- **Menu clicks landed on the wrong row.** Nested submenus (shells, themes, languages, command and bookmark groups) were hit-tested at a different width than they were drawn at, so clicking a shell did nothing while clicking the parent's shortcut column launched one. Near the screen edges, where dropdowns shrink, shift or scroll to fit, a click picked a different row or closed the menu. Contributed by [@MathysHaubert](https://github.com/MathysHaubert) in [#47](https://github.com/termide/termide/pull/47) and [#49](https://github.com/termide/termide/pull/49) (fixes [#48](https://github.com/termide/termide/issues/48)).
- **Disk sizes on macOS were 256 times too large.** Block counts were scaled by the preferred I/O size instead of the fragment size, so a 1.8 TB APFS volume showed as 464 TB. The percentages were right, which hid the bug.
- **Windows: the terminal ignored `cd`.** A terminal reported the directory it started in, so `Alt+F`, the directory switcher, the title and layout restore all missed every `cd`. It now reads the shell's directory, and a directory PowerShell announces with `OSC 9;9` or `OSC 7` takes precedence; `doc/en/terminal.md` shows the prompt setup.
- **Windows: other drives were out of reach from a drive root.** At a drive or share root, `..` and `Backspace` now open the directory switcher, which lists every drive, and the switcher spells its `cd` for cmd and PowerShell as well.
- **Deleting a project's saved layout also deleted those of the projects nested inside it.**
- **A detached instance could leave a frame on the shell's screen.** On attach, the hosted termide could paint a whole frame before entering the alternate screen, and it stayed on the shell's screen after `Alt+D`. The client now enters the alternate screen before any output.
- **An image stayed covered after a menu or modal over it closed.** Overlays drawn over an image are now painted over again once they go.
- **Pickers and settings measured text in bytes.** Cyrillic labels and `●` widened select modals up to the screen width, and a long multi-byte value could crash the settings modal. Both now measure display width.
- **`(indexing)` stuck in the editor title** for a language server that reports no progress.
- **The file manager's loading row acted as a file.** While a directory was being expanded, `Enter`, `F3`, `F4`, rename and batch operations could pick up its `…` placeholder. And with the cursor on an expanded directory, a new file or directory is now created inside it, where its visible children are.
- **Commands menu fixes.** A command with parameters run from the menu no longer skips asking for them, and in terminal mode the values reach the shell as `TERMIDE_PARAM_*` too. Saving, renaming or deleting a command edits `commands.toml` in place, keeping the other commands, their order and comments, and a new command with a taken identifier gets a free variant instead of replacing the other one. The report window keeps the output's indentation and blank lines.
- **The command palette's Switch directory opened the project switcher** instead of the focused panel's directory switcher.
- **Mermaid flowcharts.** An inline edge label (`A -- yes --> B`, also dotted and thick) became a node of its own, sibling boxes in one rank were spaced too tight, and edges attached to box corners.


## [0.35.0] - 2026-09-13

[0.35.0]: https://github.com/termide/termide/releases/tag/0.35.0

### Added
- **Zoom in the image viewer.** An image used to be drawn at its own size in the top-left corner of the panel, shrunk only when it did not fit, so a small icon sat in a corner of an otherwise empty panel and a photo could not be inspected closer than the panel allowed. It now opens fitted to the panel — as large as the width or height permits, aspect ratio kept, centred — and `+` / `-`, the mouse wheel over the panel, or the `[−]` `[+]` buttons in the status bar zoom around the centre of the visible part; the arrow keys pan a magnified image and `0` (or the `Fit` button) returns to the fitted view. The status bar shows the pixel size and the zoom as a percentage of the source pixels. Only the visible window is handed to the terminal's graphics protocol, so zooming into a large photo costs a crop rather than a full re-encode, and magnified pixels are drawn crisp instead of blurred.
- **Shell completions.** `termide --install-completions` writes the script for the shell in `$SHELL` where that shell looks for it: bash and fish then need nothing else, and for zsh the one `fpath` line to add to `~/.zshrc` is printed rather than written, since it has to land before `compinit` and rc files are the user's. `termide --completions bash|zsh|fish` prints the script for placing by hand. Loaded, it completes the options, the values `--log-level` and `--completions` take, and — the part that matters on a server with several detached sessions — the session ids after `--attach`, read from `--list-sessions` at the moment Tab is pressed. The scripts are hand-written and live in `completions/`, so packagers can install them without running the binary; the release tarballs carry them, and the `.deb`, `.rpm` and AUR packages install them system-wide. Prompted by the bash script shared in [discussion #45](https://github.com/termide/termide/discussions/45).

### Changed
- **The line-number gutter is only as wide as the last line number.** It reserved four digit cells for every file, so a three-line file carried three blank columns before each number. The gutter now takes what the buffer's line count needs — one digit for a short file, five for 10k+ lines as before — and hands the rest to the text. The content shifts one column when a buffer grows past 9, 99 or 999 lines; that trade was made in favour of the width, which a narrow terminal feels on every line.
- **Enter and double-click in Git Status open the file.** They used to stage or unstage it, so the gesture that opens a file everywhere else in termide silently changed the index here. Both now open the file in the editor; staging keeps its own keys, the header buttons and the popup menu. The help panel's Enter entry says so.
- **The Operations panel is as tall as its cards.** Opening it used to take an equal share of the column — half of it next to a single editor, the whole column under the fullscreen preset — for what is usually one progress card. It now asks for exactly the rows its cards need, grows and shrinks as operations start and finish, never claims more than half of the column (the cards scroll beyond that), and keeps that height through the fullscreen preset. Resizing it by hand switches it to an ordinary fixed height until it is closed. Panels declare this through a new `height_mode` in the `Panel` contract; every other panel keeps sharing the column as before.

### Fixed
- **Directory rows in Git Status were painted as created when most of their changes were new files.** The folder colour was the most common status among its changed files, so an existing directory with one modified file and two new ones turned green as if it had just been created, and one with a deletion and two additions did the same. A folder is now shown as created only when every change in it is an addition, and as deleted only when every change is a deletion; any mixture means the folder already existed and it is shown as modified, as the file manager's nested status does.
- **Directory rows in Git Status were not coloured by their contents.** The per-directory aggregate that gives a folder the colour of its changed files was computed only when a folder was folded or unfolded; a refresh rebuilt the tree without it, so after every update the directories sat in the plain text colour until one was toggled. The rebuild now derives it along with the visible rows, as the file manager's nested status has done all along.
- **Unfocused git panels showed stale content.** Watcher and git updates went in full only to the focused panel of each column; every other panel was "marked stale" and caught up when it next took focus — a rule from the accordion layout, where the focused panel was the only one on screen. With free heights the rest of the column is visible too, so a Git Status panel next to an editor updated its title counts (which the stale path refreshes) but kept the old file tree until clicked. Updates now go to every panel that shows content; only a panel collapsed to its title bar — by the fullscreen preset or a manual shrink — is marked stale, and it catches up as soon as it grows again, whether or not it takes focus. Git Log and Git Diff, which used to reload on every focus gain, now reload only when an update actually arrived while they were collapsed; live updates while visible are unchanged.
- **Windows menu entries opened their neighbour.** The shortcut annotation in 0.34.0 dropped the separator row under `Open…` from the list, while the row indices the dispatcher uses still counted it, so from `Terminal` down every entry ran the action of the one above and the shell picker never appeared. The row is back, and a test now ties the list to the indices.
- **Leftover fragments on panel borders and inside TUI applications.** The workspace's `unicode-width` fork had dropped the emoji sequence rules, so `✔️`, `⚠️`, `❤️`, skin-tone and ZWJ emoji counted as one column while every terminal draws them in two. ratatui's frame diff then shifted the rest of the row by a column and never repainted it, leaving pieces of a previous frame — a border line through `pi`'s editor, a stray cell on a panel border — until something else touched those cells. The fork now carries the upstream tables and state machine again, keeping only the Bengali spacing-mark override it was created for. Variation selectors are the one place terminals disagree — Ghostty, WezTerm and iTerm2 make `⏱️` two columns while `wcwidth` terminals such as alacritty and foot leave it at one — so termide asks the host terminal at startup (the attach client asks for a detached session) and follows its answer; the Journal records it, and `TERMIDE_VS16_WIDE=0|1` overrides it. ratatui's frame diff has its own workaround for such emoji — it writes the cell after them as an explicit blank, assuming the terminal kept them narrow — which on a terminal that widens puts that blank one column too far and shifts the rest of the row (`twoocolumnsswide`); termide now flags those cells as skipped before the diff runs.
- **The terminal grid understands character width.** Wide characters (CJK, emoji) occupy two cells, combining accents and variation selectors attach to the character before them, and skin-tone and ZWJ sequences stay one cluster. Before, every code point took exactly one cell: a padded full-width line with an accent wrapped onto an extra row and pushed a differential renderer such as `pi`'s out of sync, so old lines were erased in the wrong place, and the cursor sat a few columns off after any emoji. Erasing or overwriting half of a wide character now removes the whole character, as terminals do.
- **Minutes of stutter after opening a session with a large repository on macOS.** The watcher registered one non-recursive watch per directory, and notify's FSEvents backend rebuilds the whole event stream — thread teardown, thread spawn, `FSEventStreamCreate` over every path so far — on each of those calls, all on the main thread. A repo with a tracked `node_modules` (about 2,500 directories) kept the UI frozen for most of a minute or more. FSEvents is recursive by nature, so a repository is now a single recursive watch on its root, and events from `.gitignore`d subtrees are dropped when they arrive instead of by never subscribing to them. Linux keeps the per-directory inotify walk, which is cheap there.
- **`\[` and `\]` are no longer stripped from terminal output.** They were treated as bash prompt markers, but readline consumes those before anything reaches the terminal; program output such as regexes, LaTeX and escaped markdown lost the characters, and a backslash at the end of a line was held back or dropped.


## [0.34.1] - 2026-09-11

### Added
- **The hover popup's text can be copied.** `Ctrl+C` while the popup is open puts the symbol's type, signature or documentation on the clipboard instead of the editor selection — what a reader usually wants it for is pasting an unfamiliar signature or error into a search engine, and until now it could only be read and retyped. The copy carries the text as the language server sent it, not as the popup wrapped it.


## [0.34.0] - 2026-09-11

### Added
- **Detached sessions.** `termide --detached` starts a session that outlives the terminal it was launched from: close the SSH connection, come back hours later, `termide --attach`, and the editors, shells, LSP servers and long-running jobs are where you left them. `--list-sessions` shows what is running, and `Alt+D` — or Options → Detach session — lets go of the client without stopping anything. This is what `tmux` and `screen` give, without a second multiplexer between you and termide: no prefix key competing with termide's own bindings, and no second layer to configure for colours or mouse reporting. Unix only; Windows has no `fork`/`setsid` and its ConPTY model needs a different host.
- **`general.always_detachable`** makes every session detachable without having to remember `--detached` at launch. Off by default, because it changes what closing a terminal means: the session survives it, and so do its language servers and shells. Ignored for `$EDITOR`-style launches — `git commit` waits for the editor to exit, and a detach would tell it the edit finished when it had not.
- **Enum settings open a dropdown** instead of only cycling through variants. Enter and Left/Right stepped to the next value with no way to see what else was on offer or to reach a distant entry — workable for three icon modes, not for twenty-five themes. The list takes keyboard, wheel and click selection.

### Changed
- **`Alt+D` now detaches and `Alt+W` closes a panel.** Both letters were held by the WASD navigation alternatives (`Alt+W/S/A/D` mirroring the arrows), which are no longer bound by default; the arrows keep doing the navigation and `Alt+X`/`F10` still close. Those alternatives also covered terminals that swallow `Alt+<arrow>` — Ghostty rebinds `Option+Left`/`Right` to `ESC b`/`ESC f` out of the box — and that now belongs in the terminal's own configuration, which `doc/*/keybindings.md` explains. Configs still carrying the old defaults verbatim are migrated automatically; a binding you chose yourself is never rewritten, even when it names the same keys.
- **Menus show the shortcut of every action that has one** — Windows, Sessions, Bookmarks, Options, Commands and the panel context menu — in a dimmed column on the right. The keyboard route was discoverable only through the help panel or Settings. Commands, whose hotkey used to be glued onto the label as ` [Ctrl+K]`, now use that same column.
- **Reset to Defaults moved to the right of the button row**, next to Cancel, and the per-project buttons now read **Apply to Project** / **Remove from Project**. Reset sat between the two Apply buttons, where a miss while reaching for the project one wiped the configuration; "Create project override" named the file being written rather than what pressing it does.
- **The Keybindings group in Settings starts expanded.** It holds nine sections, and collapsing it by default hid every binding behind a step users have no reason to expect.

### Fixed
- **Settings did not respond to the mouse.** Clicking a control only moved the cursor and left the switch alone, and on a localised build the buttons could not be clicked at all: the renderer drew `[ label ]` character by character while hit-testing measured it in bytes, so every button past the first sat some columns away from where clicks landed.
- **"Reset to Defaults" was greyed out exactly when it had the most to do**, and left the Keybindings tab empty when it did run. It keyed off whether the modal had unsaved edits — the state it opens in — instead of whether the config differs from the defaults, and it installed a bare `Config::default()`, whose bindings are all unset.
- **Saving froze the entire keybinding table into `config.toml`.** Settings you never touched were written out on the first save, because the diff ran against a baseline whose bindings were all unset. A binding frozen that way stops tracking the defaults, so a later version that adds or moves one collides with the copy instead of applying it.
- **Settings showed only the first key of a multi-key binding.** `Close panel` answers to `Alt+W`, `Alt+X` and `F10`, but the list displayed `Alt+W` alone — and `Delete` then removed all three at once, two of them invisible. Every alternative is now listed, and `Delete` removes them one at a time (`Shift+Delete` clears the action outright), which also makes a multi-key binding editable at all: the capture dialog can only add.
- **The theme could not be changed from Settings on a fresh install.** Cycling looked the current value up in the theme list by position, and the stock config ships `theme = "default"` — a fallback name rather than a theme — so it found nothing and silently did not move.
- **A long field label ran into its own value.** The label column was fixed at 32 characters, which the longest English label already filled and a translated one overran.

[0.34.1]: https://github.com/termide/termide/releases/tag/0.34.1

[0.34.0]: https://github.com/termide/termide/releases/tag/0.34.0

## [0.33.0] - 2026-09-07

### Added
- Settings now exposes the **Database** and **Viewer** keybinding sections. The modal listed seven of the nine sections the configuration defines, so the database panel's six bindings and the viewer's two could only be changed by editing `config.toml` by hand.

### Changed
- The **git diff panel loads in the background**. It used to run `git status` twice plus a `git diff` for every changed file on the UI thread — and not only when opening: the panel refreshes on filesystem and git events, so editing a file anywhere in the repository froze the interface on each watcher tick. Measured on a warm cache, that was 90 ms for four changed files and 360 ms for thirty. The panel now opens immediately with a loading marker in its title and keeps showing the previous diff while the new one loads.
- **Language servers receive only the ranges that changed.** Every keystroke used to ship the whole document, which allocated a copy of the file and walked the entire buffer — a cost that grew with the file rather than with the edit, and was noticeable on multi-megabyte files. The whole document is still sent where ranges cannot be trusted: to a server that only advertises full synchronization, after a reload from disk, and when a backlog of unsent changes accumulates.
- The contributor gate now also checks for unused dependency declarations (`cargo machete`) and runs tests through `cargo nextest`, which cut the workspace suite from 21.5 s to 4.1 s. The pre-commit hook checks what is actually staged rather than the working tree, so splitting a session into separate commits no longer needs `--no-verify`.

### Fixed
- **Hover, completion, go-to-definition, find-references and rename asked language servers about the wrong token** whenever an emoji, a combining accent or a ZWJ sequence sat earlier on the same line. Editor columns count grapheme clusters while the Language Server Protocol counts UTF-16 code units, and one was being passed as the other; the two agree for ASCII and for the whole Basic Multilingual Plane, which is why plain text and Cyrillic were unaffected. Completion's own text edits were misread the same way and could replace the wrong span.
- **Opening an SFTP bookmark could take down the whole application.** Failing to start the SFTP backend panicked on whichever thread reached it first, which is the interface thread; it now surfaces as a connection error.
- **Cancelling a file copy left a truncated file behind** that looked like a finished one. The destination is now removed unless the copy completes. Note that cancelling a copy *over an existing file* now removes that file: it was already destroyed when the copy began, and a fragment posing as a complete copy is worse than its absence.
- **Creating a file or directory on an SFTP, FTP or SMB share froze the interface** for the length of the round trip — up to the backend's thirty-second deadline on an unresponsive server. The entry now appears when the server answers, and the interface stays usable meanwhile.
- **Double-clicking `some_long_name` selected only `some`.** Word selection treated `_` as a separator, while this editor's own vim motions and the terminal's double-click both already counted it as part of a word.
- Timestamps a year or older fell back to English in Bengali, Hindi, Indonesian, Japanese, Korean, Thai, Turkish, Vietnamese and Chinese: the `year` plural was missing from those nine translations.

[0.33.0]: https://github.com/termide/termide/releases/tag/0.33.0

## [0.32.0] - 2026-09-06

### Added
- Startup diagnostics for keybindings the terminal cannot deliver. On macOS, termide reports how many `Alt+<key>` bindings are lost to Option composing text, and lists the actions bound to a function key and nothing else, each with the setting that fixes it for the terminal at hand.
- `general.report_all_keys` (macOS only, on by default) — asks the terminal to report every key as an escape code, which is what makes `Alt+<letter>` hotkeys reachable there. Turn it off if you need dead-key or IME composition inside termide.

### Changed
- macOS: `Alt+<letter>` hotkeys work out of the box on terminals with the Kitty keyboard protocol (Ghostty, kitty, WezTerm, iTerm2 3.5+). Previously all ~25 of them were swallowed by Option's text composition.
- Continuous integration runs the full format / lint / test gate on macOS as well as Linux. macOS used to be built only at release time, so platform regressions could not be caught before a tag.

### Fixed
- **Save as, Reload, Redo, Search in files and Replace in files** (`Ctrl+Shift+S`, `Ctrl+Shift+R`, `Ctrl+Shift+Z`, `Ctrl+Shift+F`, `Ctrl+Shift+H`) never worked on any terminal implementing the Kitty keyboard protocol, on every platform.
- **Find references** could not be triggered by its `F24` fallback on xterm-style terminals: function keys above F12 were rejected when the binding was read.
- macOS: the file watcher ran out of file descriptors on any real project and crashed its thread, and panels re-ran git status in a loop — visible as a spinner appearing in panel titles roughly once a second.
- macOS: the terminal panel showed the directory it was opened in instead of the shell's current one, left the running command missing from its title, and never noticed a running process — so closing a busy panel asked no confirmation, and "open here", the directory switcher and the git panels' repository search all worked from the wrong directory.
- macOS: the resource monitor listed no disks at all.
- macOS: opening a bookmark that points at a file or a URL did nothing.
- Rebinding a key through Settings could store a chord that no keypress would ever match, most visibly for `Alt+<letter>` on macOS.

### Security
- Remote connection diagnostics no longer write the account's user name to the log. Two `VfsManager` error messages printed the raw provider lookup key, which embeds the user name; they now use the same redacted form (`sftp://***@host:port`) as the rest of the codebase. No password was ever logged.

[0.32.0]: https://github.com/termide/termide/releases/tag/0.32.0

## [0.31.0] - 2026-09-01

### Added
- The Structure panel now recognizes Alatyr `.al` files. Alatyr has no declaration keywords — a declaration binds a name to a value (`name := value`) — so the outline lists bindings and classifies the right-hand-side introducer: `fn`, `struct`, `enum`, `union`, `mod` and `brand`, including declarations inside inline `mod { ... }` values. Locals inside a function body are skipped, and `:=` inside strings or comments is not mistaken for a declaration. Works whether or not you have set up `[[highlight.custom_languages]]` for the extension.

### Fixed
- The editor's line-number column now grows for large files. It was fixed at four digits, so from line 10 000 on the number overran the diagnostic marker and the separator space next to the code; the width is now derived from the file's line count, keeping the four-digit minimum so ordinary files look exactly as before.

### Security
- Updated the `suppaftp` FTP client to 10.0.2, clearing RUSTSEC-2026-0271 (FTP command injection via CRLF in control-channel arguments). Command arguments — user name, password and remote paths — are now validated before they go on the wire, so a path containing `\r` or `\n` fails with an error instead of smuggling a second FTP command into the session.

[0.31.0]: https://github.com/termide/termide/releases/tag/0.31.0

## [0.30.0] - 2026-08-21

### Added
- Database viewer: values can now be edited. `Enter` on a cell opens it in place with a caret — `Enter` again saves, `Escape` discards — and `Space` opens the row dialog, where every field is editable next to the copy actions it already had. A column that accepts NULL gets a `NULL` checkbox; clearing a text field writes an empty value, not NULL. Editing requires a table with a primary key, since without one there is no way to name exactly one row; other tables stay readable and say why. A SQLite file is still held open read-only while browsing and reopened for writing only on the first edit.
- Panel scrollbars can be dragged with the mouse. Grabbing the thumb on a panel's right border (or the bottom border, where a horizontal bar is drawn) scrolls the panel to that position, following the cursor as you drag; the bar's track and borders without a bar keep resizing the layout as before. Works in every panel that draws a scrollbar, and dragging an unfocused panel's thumb scrolls it in place without stealing focus.

### Changed
- Terminal panels now track the shell's working directory. The title shows the directory you are actually in and follows a `cd`, the panel reports that directory to the directory switcher, to "open a panel here" and to the git panels' repository search, and a restored session reopens the terminal where you left off rather than where the panel was first created.
- Bulk file operations no longer walk the tree when they don't have to. Moving inside one filesystem is a rename, so it no longer scans the whole subtree first — for a 35k-entry tree that scan cost more than the move itself. Deleting reads the file type from the directory listing instead of a separate stat per entry, and reports progress on a timer instead of once per file. The burst of filesystem events that follows a large delete is collapsed per directory, which removes a visible pause after the operation finished.
- The delete confirmation now starts on "No", so a stray `Enter` cannot remove files. Other confirmations keep "Yes" as the default.

### Fixed
- Git panels no longer lose repositories. A repository open in one panel stayed out of the dropdown whenever another panel sat in a parent directory, the repository of the session's own directory was missing unless a panel happened to be inside it, and a repository the panel was opened for could disappear a moment after unrelated panel paths arrived.
- The elapsed-time counter in the operations panel now uses the current language's units instead of always showing `h`/`m`/`s`.

[0.30.0]: https://github.com/termide/termide/releases/tag/0.30.0

## [0.29.7] - 2026-08-01

### Security
- Updated the `russh` SSH library to 0.62.5, clearing advisory GHSA-m65r-rprj-r5rg (a server-side channel-lifecycle flaw). TermIDE only uses russh as an SFTP client, so the vulnerable server path isn't exercised, but the dependency is bumped to the patched release.

### Fixed
- A single invalid field in the config (most easily an `[lsp.servers.*]` entry with no `command`) no longer discards every other setting — configuration now degrades to the largest valid subset instead of silently falling back to defaults.
- Terminal panel: a leftover text selection is now cleared when the mouse wheel scrolls a mouse-tracking application (e.g. an agent or editor) inside the terminal, instead of the highlight staying stuck on screen and bleeding over the freshly scrolled content.
- The editor's "file changed on disk" message no longer points at a non-existent force-save shortcut; it now names the actions that actually exist (reload with `Ctrl+Shift+R`, or Save As).

### Changed
- Completed localization for the remaining 12 languages (de/es/fr/pt/ko/hi/ja/th/tr/vi/id/bn): the database viewer, in-files find/replace, and the remote-connection dialog strings are now translated instead of falling back to English; all bundled locales are now at full key parity.
- Corrected documented keybindings across the English/Russian/Chinese docs: the directory switcher is `Ctrl+\` (not `Ctrl+/`), "Add bookmark" is `Alt+B` (not `Alt+K`), and `Alt+P` opens the Settings modal.

## [0.29.6] - 2026-08-01

### Fixed
- Markdown and HTML tables now render inline formatting (inline code, `**bold**`, `*italic*`) and clickable links inside cells. Previously a formatted cell was left blank and its content leaked out as plain text below the table.
- The diagnostics panel no longer panics when the terminal is only a few rows tall.
- Git status and log panels no longer stack redundant background refresh workers during rapid `.git` activity (rebase, gc, fetch, large checkout), avoiding CPU and git-subprocess spikes.
- The editor's inline git diff no longer risks a git/SSH credential prompt being drawn over the interface, and now resolves diffs correctly for files opened through a symlinked path.

### Changed
- Git blame ages and the relative times in the session list now follow the interface language (blame was previously always English) and gain a "years" bucket; the new string is translated across all bundled locales.
- Faster editor rendering while searching in large files, and lower per-frame work in the git-status panel.

## [0.29.5] - 2026-07-28

### Security
- Updated the `russh` SSH library (used by the SFTP remote-file backend) to 0.62.4, addressing three medium-severity advisories affecting russh ≤ 0.62.3: GHSA-5xvq-cp9x-6p6r, GHSA-cqjc-rmpq-xprq and GHSA-g9hv-x236-4qp3.

## [0.29.4] - 2026-07-16

### Fixed
- Terminal panel: a completed text selection no longer gets "stuck" after a mouse-tracking application (e.g. an agent) turns mouse reporting on. Previously any subsequent click extended the stale selection to the click point with no way to clear it. Selection now only keeps capturing the mouse while a drag is actually in progress, and clicking into a mouse-tracking application clears the leftover local highlight.

### Changed
- Copy / cut / paste are now a single set of **global** keybindings (`Ctrl+C` / `Ctrl+X` / `Ctrl+V`) routed to the focused panel, instead of being configured separately per panel. Each panel handles them by capability — the editor copies/cuts/pastes selected text, the file manager the selected paths, the database the current cell, the git panels the file path / commit hash. In the **terminal**, `Ctrl+C` copies the selection when there is one and otherwise sends `SIGINT` to the shell, and `Ctrl+V` pastes (previously `Ctrl+Shift+C` / `Ctrl+Shift+V`). The per-panel `copy` / `cut` / `paste` / `clipboard_copy` bindings were removed from the settings; rebind them once under **Global**.

### Added
- The file manager status bar now shows a labelled **Size:** field (to the right of **Owner:**) for the entry under the cursor — a plain byte size for files, and `<size> (N items)` for directories, where `N` is the immediate (non-recursive) child count. This matches the properties modal (`Space` / `F12`), whose **Size** line likewise appends the item count in parentheses (e.g. `1.2 MB (42 items)`); the count appears immediately while the recursive size is still being calculated.

## [0.29.3] - 2026-07-15

### Fixed
- The git status/log panels no longer reset the selected repository when working in a directory that contains many git projects. Navigating (which re-derives the repo list) dropped the asynchronously-discovered nested repositories and submodules, resetting the selection to the first repository; the repo list is now merged instead of replaced, so the selection is preserved.
- The diagram viewer now shows a horizontal scrollbar on the bottom border for diagrams wider than the panel, so you can tell how far along the X axis the view is (and that there's more to the right). Previously only a vertical scrollbar was drawn.
- Diagram layout is more balanced: a rank's nodes are now centred on their connected neighbours instead of drifting to one side, so a hub with many connections (e.g. an entity referenced by many others in an ER diagram) straddles its neighbours symmetrically. This removes the wide empty channels and long connecting lines that stranded the first boxes far to the left, and makes wide diagrams noticeably narrower.

## [0.29.2] - 2026-07-10

### Added
- **Open databases without a bookmark.** Pressing `Enter` or `F3` on a `.db` / `.sqlite` / `.sqlite3` / `.db3` file in the file manager now opens it in the database viewer (instead of the hex viewer).
- **`Windows ▸ Open…`** — a universal opener prompt (replacing the old `Web` entry, now the first item in the menu) that routes what you type by type: a file (by extension), a directory (file manager), a database URL (`sqlite://` / `postgres://` / `mysql://`), or an `http(s)://` address. `Ctrl+G` in any viewer shares the same behaviour.

### Fixed
- The database viewer's table and database dropdowns now draw a border, matching the git panel's branch/repository selectors (previously they rendered as an unframed list).
- The database viewer's data grid now shows scrollbars drawn on the panel frame: a vertical bar on the right border (position within the whole table, across pages) and a horizontal bar on the bottom border when the columns are wider than the panel. Previously there was no indication of how many pages remained or that columns extended off-screen.
- **File and git panels now track external changes live.** A watcher bug meant a git repository's per-directory watches were never actually installed, so the file manager and git panels only refreshed on focus or navigation — changes made from a terminal (or an agent) appeared to be ignored. Fixed, plus: directories created after a panel opened are now watched too; the file manager recomputes git status on watcher events instead of reusing a stale cache; the git log and git diff panels refresh from watcher events (and on focus), not only on manual reload; a directory reload coalesced away during a burst of changes is retried so the final state always lands; and watcher latency is lower (file debounce 1000→300 ms, git debounce is now a fixed 250 ms window instead of resetting on every change).

## [0.29.1] - 2026-07-08

### Added
- **Kotlin support.** `.kt` / `.kts` files now get syntax highlighting, an outline of their classes, interfaces, objects, enums and functions, and rich class diagrams (`View as diagram`) with properties, function signatures, `val`/`var` constructor properties, superclass/interface relationships, and top-level declarations collected in the file box.

### Fixed
- Project sessions are no longer deleted wholesale during cleanup. A stale parent directory that contains a fresh, in-use nested session now keeps that session — only the parent's own expired files are removed — so active sessions and their settings are no longer silently lost.

## [0.29.0] - 2026-07-03

### Added
- **Class diagrams from source code.** The editor's `View as diagram` menu entry builds a Mermaid class diagram of what the open file declares and opens it in the diagram viewer. Each box is titled with the declaration (`pub struct Cli`, `enum Mode`, `public interface Draw`, …), members carry UML visibility markers (`+`/`-`/`#`/`~`), and inheritance, trait/interface realization and field composition are drawn as edges. Rust, Python, TypeScript/TSX/JSX, Go, Java, C, C++, Ruby and PHP have rich extractors (types, signatures, relationships); other tree-sitter languages fall back to type boxes with method names plus a box of top-level functions named after the file.
- **Save a generated diagram** to a permanent `.mmd` file with `Ctrl+S` or the `Save diagram as…` entry in the diagram viewer menu.
- **Type-to-filter** in the git panel's repository and branch dropdowns — start typing to narrow the list.
- **Word delete in the editor:** `Ctrl+Backspace` (or `Alt+Backspace`) deletes the previous word, `Ctrl+Delete` the next.
- **Word/line selection by mouse:** double-click selects the word under the cursor and triple-click selects the whole line, in both the editor and the terminal.

### Changed
- Git status and git diff panels now refresh automatically when they gain focus, so changes made outside the panel show up without a manual `Ctrl+R`.
- Clipboard copy now detects an available display server (X11/Wayland) instead of guessing from SSH, so the OSC 52 fallback is used correctly in headless, Docker and serial-console sessions.
- The help panel is now fully localized across all 15 languages; previously many descriptions rendered in English even in translated locales.

### Fixed
- Pressing Enter in the git repository/branch filter with no matching entry no longer switches to the first repository/branch.
- Panel-specific actions (such as `View as diagram`) now appear in the panel `[≡]` dropdown menu.

## [0.28.0] - 2026-06-30

### Added
- **HTML preview panel.** `.html` / `.htm` files open as a rendered, read-only view (`F3`) with the full viewer UX — movable cursor, text selection, clipboard copy, incremental search (`Ctrl+F`), reload from disk (`Ctrl+R`), and `Ctrl+E` to toggle to the editable source. A supported subset of tags is styled (headings, lists, tables, `<pre>`/`<code>`, `<kbd>`/`<b>`/`<i>`/`<sub>`, links, image pictograms); unknown tags stay transparent and author CSS/scripts are ignored.
- **HTML embedded in Markdown now renders.** Raw HTML in `.md` files — centered `<img>` badges, `<details>`/`<summary>`, HTML `<table>`s, and inline tags like `<kbd>`/`<sub>` — renders through the same engine instead of appearing as literal angle-bracket text.
- **The Markdown and HTML viewers are now a text-mode browser.** `Ctrl+G` — or the new `Windows ▸ Web` menu entry — opens a path or an `http(s)://` URL; pages are fetched and rendered, links are followed in place with back/forward history (`[` / `]` or `Backspace`), relative and `#section` anchor links resolve, and image links open in the image preview. A fetched view shows the URL as its title with a 🌐 icon. Fetching is security-bounded: http/https only, verified TLS, 15-second timeout, at most 5 redirects with no `https→http` downgrade, an 8 MiB body cap, and embedded resources (e.g. `<img>`) are never loaded. The `[viewer] open_links` and `[viewer] open_images` settings choose panel-vs-external (default `panel`); `O` always opens the link in the external browser.
- **Bookmarks open in the viewer.** HTML / Markdown / Mermaid / image files and `http(s)` web links open in the built-in viewer by type (honouring `[viewer] open_links`), instead of always launching an external program. Directories, remote paths, SSH, and databases are unchanged.
- **Transparent background via the `"Reset"` theme colour.** Set any theme colour to `"Reset"` to use the terminal's native colour (e.g. `bg = "Reset"` shows the terminal background through). Named theme colours are now matched case-insensitively. (#37, thanks @shepelpavel)
- **Viewer shortcuts in the help panel** (`Alt+H` / `F1`) — a new "Viewers" section documenting the Markdown/HTML/diagram hotkeys.

### Fixed
- Markdown / diagram viewers: take focus on open, open a fresh viewer per file, draw the scrollbar on the panel border, reload from disk with `Ctrl+R`, hide the cursor when unfocused, and keep a heading that follows an HTML block on its own line.
- Git log panel: the selection cursor is now full-width (no uncoloured edges, no blank bottom row), and a stray "Refreshed" status note was removed.

### Documentation
- Added a Russian README (`README.ru.md`) and reworked the README with a hero screenshot and a feature-comparison table; synchronised the installation guides, new viewer docs, and translations across en/ru/zh.

## [0.27.0] - 2026-06-24

### Added
- **Mermaid diagram viewer.** `.mmd` / `.mermaid` files open as a read-only diagram drawn in text pseudographics — flowchart, sequence, state, class, ER, gantt, pie, journey, mindmap, timeline, gitGraph, and quadrant — with two-dimensional scrolling, copy to clipboard (`y` / `Ctrl+C` or the `[≡]` menu), and `Ctrl+E` to switch to the editable source. Fenced ```` ```mermaid ```` blocks render as diagrams inside the Markdown preview too. (#34)
- **Markdown preview panel.** `.md` / `.markdown` files open as a rendered read-only view — headings, lists, tables, block quotes, syntax-highlighted code blocks, clickable links, and image pictograms — with a movable cursor, text selection, clipboard copy, and `Ctrl+E` to toggle to the editable source. (#32)
- **Hex / binary viewer and editor.** Binary files open in an adaptive hex/ASCII view with a dual-zone byte cursor, drag / Shift selection and clipboard copy, ASCII and hex-byte search, and a hex↔text toggle (`Ctrl+L`); `F4` opens the same file for overwrite-in-place editing, writing a `.bak` backup on save and confirming on close with unsaved changes. (#31, #33)
- **Syntax-highlight language picker in the editor.** Pick the highlight language from the editor status bar to re-highlight a mis-detected file, without renaming it.
- **Clickable per-panel status-bar segments.** Panels contribute their own status-bar chips and `[≡]` action-menu entries; the editor and the new viewers use them for the view/edit toggle, copy, and type indicators. (#36)

### Changed
- The editor status bar was rebuilt from clickable segments, giving it parity with the hex viewer and mode-aware view/edit swaps.

### Fixed
- Selection dropdowns and menus now scroll with the mouse wheel and show a scrollbar where the list overflows — the Git branch / repository pickers, the editor's syntax-highlight picker, and the menu-bar and `[≡]` dropdowns. Previously the wheel scrolled the panel underneath and long lists had no scrollbar.

## [0.26.0] - 2026-06-22

### Added
- **Box-drawing commit graph in the Git Log panel.** Commit history is now drawn with proper pseudographics (`● │ ├ ╮ ╯`) laid out from each commit's parents, with every lane coloured so a branch can be followed by colour. Set `[git_log] unicode_graph = false` to fall back to git's native ASCII graph.
- **Database connection recovery dialog.** When a database connection or query fails fatally, the viewer now offers **Reconnect** or **Close** instead of leaving only a status-bar error; `Esc` dismisses it and keeps the last results visible.
- **Remote session recovery dialog.** When an SFTP/FTP/SMB operation fails because the session dropped (idle timeout, network loss), the file manager offers **Reconnect**, **Open home (local)**, or **Close** instead of a dead-end error.
- **Custom-language keyword highlighting from config.** Define a lightweight per-line highlighter for file types without a tree-sitter grammar directly in `config.toml` (`[[highlight.custom_languages]]`) — keywords, types, and line comments, with no rebuild required.
- **`Ctrl+R` re-runs the search in the inline find bar**, re-matching the current query against the latest content (file-manager directory, terminal scrollback, or editor buffer) without retyping it.
- **Find bar seeds from the selection.** Opening the editor find/replace bar with a single-line selection pre-fills the search field with the selected text.

### Fixed
- A dropped SFTP session no longer triggers an endless stream of "connection error" pop-ups; the file manager stops retrying a dead session.
- Switching the interface language now updates the top-level menu bar too, which previously stayed in the original language until restart.
- `Ctrl+C` now copies the buffer selection while the find bar is open — clicking or dragging in the buffer moves focus there first.

## [0.25.1] - 2026-06-20

### Changed
- **Terminal search is now an inline find bar.** `Ctrl+F` in the terminal opens a find bar docked at the top of the panel — matching the editor and file manager — with `[Aa]` case and `[.*]` regex toggles, `◄ Prev` / `Next ►` navigation, and an inline match counter. Terminal search is now regex-capable (previously literal only), and `Tab` moves focus between the bar and the terminal grid.
- Reduced per-frame allocations on the terminal, file-manager, and text-rendering paths, lowering CPU use on redraw.

### Fixed
- The editor's inline git-blame annotation now stays on the cursor's line when lines have been deleted relative to HEAD; previously the deletion markers pushed it above the cursor.

## [0.25.0] - 2026-06-17

### Added
- **Inline search and replace bars.** Editor find/replace and file-manager name/content search now dock inside their panels instead of opening floating modals, with live results, mouseable controls, `Esc` close behavior, and `Tab`/`Shift+Tab` focus movement between the form and results.
- **Regex & case toggles in search and replace.** The editor's search (`Ctrl+F`) and replace (`Ctrl+H`), file-manager name search, and file-manager content search now have `[.*] Regex` and `[Aa] Case` toggles. With regex on, replacement supports `$1` / `${name}` capture groups.
- **Project-wide find & replace** in the file manager's content search. Compose a replacement in the new `Repl:` field, preview the change as `-old/+new`, choose affected files with per-file checkboxes or **Select all**, and apply the replacement after confirmation.

### Changed
- **Search results are easier to scan and navigate.** File-manager content results are grouped by file with collapsible headers, match counts, a capped `+ N more` overflow row, folder/file navigation, and click targets for collapse and selection.
- **BREAKING (search behavior):** file-manager content search is now **literal by default** — the query is matched verbatim. Enable `[.*] Regex` for pattern search. Previously the query was always a regular expression.
- Installing from source now uses `cargo install --git` in the documented installer path, avoiding the obsolete crates.io package.

### Fixed
- Toggling panels from stacked to side-by-side no longer opens the separated panel at the minimum width; repeated split/merge toggles now preserve stable widths.
- Editor replace-current failures are now shown in the status bar instead of being silently discarded.
- File-manager name matching now applies the case toggle consistently in both name search and content search masks.

## [0.24.1] - 2026-06-12

### Changed
- Cancelling a background operation in the Operations panel now asks for confirmation first — via `Esc`, `Delete`/`Backspace`, or the card's popup menu — so a reflexive `Esc` no longer aborts a running transfer.

### Fixed
- Entering a **directory symlink on a remote SFTP filesystem** now navigates into it instead of showing an endless "synchronization". The link was misread as a file, which kicked off a recursive download of its target tree. Symlinks are now resolved on entry (directory → navigate into it, file → open it), the SFTP transfer walk is guarded against symlink cycles, and symlinks render with a distinct marker instead of being drawn bold like executables.
- **Held-key auto-repeat on Kitty-protocol terminals.** termide enables the Kitty keyboard protocol's `REPORT_EVENT_TYPES`, so a held key streams `Repeat` events; these were discarded, so held keys did nothing. `Repeat` is now treated like `Press`, restoring auto-repeat. (Thanks @olegpro171, #26.)

## [0.24.0] - 2026-06-07

### Added
- **Database viewer (read-only).** Browse **SQLite**, **PostgreSQL** and **MySQL/MariaDB** tables from a bookmark whose path is a database URL (`sqlite:///…`, `postgres://…`, `mysql://…`). The panel connects in the background and shows rows in a 2D grid with a cell cursor, sliding-window pagination, single-column server-side sort (ascending → descending → unsorted), type-aware per-column filtering (combined with `AND`), a full-row detail dialog (copy as TSV / JSON / INSERT), and cell/row copy. When the URL omits a database (PostgreSQL/MySQL) a selector lets you pick one (the first is auto-selected); the panel is restored across sessions. Queries run on a background runtime so the UI never blocks; everything is strictly read-only (`SELECT`/catalog queries only). Action keys are configurable under `[database.keybindings]` and shown in Help; the mouse can open the selectors, sort by clicking a column header, and move the cursor by clicking a cell. See [Database Viewer](doc/en/database.md).
- **Android / Termux support.** Releases now include a statically-linked `aarch64-unknown-linux-musl` binary that runs in Termux; see the installation docs.

### Fixed
- The Operations panel no longer offers **Pause** for script/command operations (it was never actually implementable); **Cancel** still stops them by killing the process. Pause/Resume remain for file transfers.

## [0.23.11] - 2026-06-05

### Added
- **Multiple Git Status panels.** Opening Git Status (`Alt+G` / Tools menu) now always creates a new panel instead of focusing the existing one, so several repositories can be watched side by side — each panel tracks its own repo via the dropdown.

### Security
- The SSH askpass helper now hands the passphrase to ssh via a raw stdout write rather than a `print!` macro. Behaviour is unchanged (ssh reads it over a pipe it owns — never a terminal or log); this just keeps static analysis from mistaking the askpass contract for cleartext logging.

## [0.23.10] - 2026-06-05

### Added
- **Git Status/Log now find nested repositories.** Opening termide in a directory that isn't a repo itself but contains git projects (or sits inside a whole-home/whole-disk repo) now lists those nested projects, discovered asynchronously up to two levels deep — alongside the usual submodule discovery.

### Changed
- The repository dropdown is sorted by name (case-insensitive) instead of full path, so the list reads alphabetically.

### Fixed
- The Git Status/Log panels no longer keep showing a repository's branch, files, or commits after it disappears (e.g. its `.git` was deleted) — the panel state is cleared, and it reloads when the selected repository changes.
- Navigating no longer briefly flashes "no repositories" while the repo list is re-scanned.

## [0.23.9] - 2026-06-03

### Fixed
- **SSH/credential prompts no longer corrupt the interface.** Opening a repo auto-fetches, and push/pull/fetch ran with the terminal attached, so when ssh needed an SSH key passphrase it drew the prompt straight over the TUI. Network git operations now run non-interactively (detached stdin, `GIT_TERMINAL_PROMPT=0`, ssh `BatchMode`), so a key already in ssh-agent just works and a missing one fails cleanly. A failed auto-fetch reports on the status line instead of popping a modal.

### Added
- **Enter an SSH key passphrase in a modal for git push/pull/fetch.** When an operation needs a passphrase that isn't in ssh-agent, termide now asks for it in a masked modal and retries (via a private, short-lived askpass handoff) instead of failing. The passphrase is cached in memory for the session so repeated operations don't re-prompt; it is never written to the config or persisted.

## [0.23.8] - 2026-06-03

### Fixed
- **Crash when opening a dropdown on a short or narrow terminal.** Theme/menu/language/git-selector popups sized themselves from their item count without clamping to the terminal, so a list taller or wider than the screen rendered past the buffer edge and panicked (e.g. opening Options → Themes on a 24-row terminal, or a git branch/stash selector on a small window). Popups are now clamped to the visible area and scroll instead.

## [0.23.7] - 2026-06-02

### Added
- **Open files from the command line / use termide as `$EDITOR`.** `termide path/to/file ...` now opens the given files (creating them if absent), so termide works as the editor for `git commit`, `crontab -e`, `visudo`, and similar tools that previously failed with "unexpected argument". When launched with file arguments termide starts in a lightweight editor mode: it shows only those files, does not restore or save the project session (so editing a commit message can't clobber it), and closing the last panel quits — returning control to the launching tool like nano or vim.

## [0.23.6] - 2026-06-02

### Fixed
- **"Import class" no longer deletes code or loses unsaved edits.** A command-based quick-fix's edit is computed by the language server against the document it tracks — the editor buffer — but it was being applied to the file on disk and the editor reloaded from there. With unsaved changes in the buffer (e.g. a just-typed `Order::where()`), disk and buffer diverged: the reload discarded the unsaved text and the edit landed on the wrong lines. Server-driven edits to an open file now go through its buffer, preserving unsaved work and landing where the server intended; the server is also synced before and after so repeated runs don't duplicate the import.

## [0.23.5] - 2026-06-02

### Fixed
- **"Import class" no longer mangles the file or duplicates the import.** The command-based quick-fix added in 0.23.4 could garble text around the insertion point — servers such as phpactor send the import as two edits at the same position, which the edit-application code mis-ordered — and running it a second time added a duplicate `use` line because the server was never told the file had changed. Edits are now applied by absolute document offset (every other line is preserved verbatim), and the language server is resynced after each applied edit.

## [0.23.4] - 2026-06-02

### Fixed
- **Command-based quick-fixes now apply.** Actions a language server performs through a command rather than an inline edit — such as phpactor's "Import class" — showed up in the `Alt+Enter` popup but did nothing when chosen. They now run via `workspace/executeCommand`, and the edit the server pushes back is applied (adding the `use` statement and reloading any affected editors). This completes the code-action support started in 0.23.2–0.23.3.
- The code-action shortcut (`Alt+Enter`) is now listed in the help panel alongside the other LSP shortcuts, and the documented manual-completion shortcut was corrected to `Ctrl+J` / `Ctrl+Space`.

## [0.23.3] - 2026-06-01

### Fixed
- **Code actions from servers that fill in the edit lazily now work.** Quick-fixes that a language server returns without an inline edit (resolving it only when chosen) previously never appeared in the `Alt+Enter` popup; they are now listed and resolved on accept, so more servers' actions (e.g. phpactor "Import class") apply.

## [0.23.2] - 2026-06-01

### Added
- **LSP code actions** — press `Alt+Enter` on a line to request quick-fixes (e.g. "Import class" for PHP) and pick one from a popup; the chosen edit is applied across files with open editors reloaded. (`Ctrl+.` stays bound to toggle-comment, so the default is `Alt+Enter`.)

### Changed
- Auto-completion now triggers on the characters the language server actually advertises (so PHP's `->` opens the popup), falling back to the built-in set only when the server reports none.

### Fixed
- **Completion no longer duplicates the typed prefix.** Accepting a suggestion now applies the server's edit verbatim instead of a word-boundary heuristic, so `$va`→`$var` (not `$$var`) and `Ord`→`Order` (not `OrdOrder`). Imports that accompany a completion (`use` statements) are applied too.

## [0.23.1] - 2026-05-31

### Added
- The version string (`termide --version` and the help panel header) now includes the git commit it was built from, e.g. `0.23.1 (50b81b1)`, so builds that share a version number can be told apart.

### Fixed
- **PHP syntax highlighting** — `.php` files are now highlighted instead of shown as plain text, including mixed HTML/PHP templates (the HTML, the `<?php … ?>` code, and the tags are all coloured). The PHP grammar had been silently disabled in the shipped binary: different crates pulled incompatible tree-sitter-php versions, whose clashing `tree_sitter_php` symbols collided at link time onto an ABI the runtime rejected. All crates are now pinned to the same grammar version.
- **JSX syntax highlighting** — `.jsx` files are now highlighted; the language was listed as supported but never actually loaded.
- **Multi-line constructs** — block comments and strings that span several lines now stay coloured to their end across every language, instead of losing highlighting after the first line.

### Changed
- The editor now highlights the whole buffer in one context-aware pass (files up to 1 MB) rather than line by line, which is what makes template languages and multi-line tokens colour correctly. Larger files fall back to the previous per-line highlighting.
- A syntax grammar that fails to load is now logged instead of being dropped silently, so missing highlighting is diagnosable.

### Security
- Bumped `russh` to 0.61.1 (CVE-2026-46702): the SFTP client now bounds post-decompression SSH packet size, closing a remote resource-exhaustion vector a malicious server could trigger when compression is negotiated.
- Refreshed the dependency lock off the yanked `aes` 0.9.0 onto 0.9.1 (no API change).

## [0.23.0] - 2026-05-23

### Added
- **Remote filesystems** — pure-Rust SFTP / FTP / FTPS via russh + russh-sftp + rustls. Browse, open, copy, rename and move remote files in the same FileManager as local paths. Bookmarks accept `sftp://user@host:port/path`, `ftp://`, `ftps://` URLs; `Auto` auth chains SSH agent → `~/.ssh/config` (`IdentityFile`, `User`, `Port`, `Hostname` aliases) → default keys → password. Non-ASCII paths round-trip through URL encoding intact. See [`doc/en/vfs.md`](doc/en/vfs.md).
- **Static musl Linux binary** — `termide-0.23.0-x86_64-unknown-linux-musl.tar.gz` published with every release. Runs on Alpine, distroless containers and any glibc-free Linux. The Nix flake also exposes the same recipe as `#termide-static`.
- **Operations panel** —
  - Per-card popup menu (Pause / Resume / Cancel) on the bracketed type icon `[↑]`/`[↓]`/`[⧉]` (mouse) plus `Space` / `Esc` / `Delete` keyboard equivalents.
  - Cancel-cleanup modal for interrupted remote uploads — "Delete partial upload 'filename'?" defaults to delete and is batch-safe (only the in-flight file).
  - `⏸` indicator next to the icon while an operation is paused.
  - Help panel now lists Esc alongside Delete/Backspace.
  - See [`doc/en/operations.md`](doc/en/operations.md).
- **`--diagnostics` CLI** — pre-flight check (config parse, XDG dirs, git availability) that runs before terminal init and exits 0/1 for scripts.
- **Journal panel: level pills** — clickable `[TRACE] [DEBUG] [INFO] [WARN] [ERROR]` in the header row, also togglable via `Alt+1..5`.
- **Unsaved buffer recovery** — orphaned buffers from a crashed session were already restored as editor panels; now each one is announced in the Journal so users see why the extra tabs appeared.
- **FileManager — cursor-level actions** — `Ctrl+N`, `D`/`F7` and `Ctrl+V` now land at the cursor's tree level (the same subdir the cursor is inside), not always at the panel root. Documented in `doc/{en,ru,zh}/file-manager.md`.
- **Editor** — `F8` deletes the current line (or every line touched by the active selection) outside vim mode; read-only buffers ignore it.
- **Config** — layered global + per-project override loading; `<project>/.termide/config.toml` overlays `~/.config/termide/config.toml`. Both files save only diffs against their baseline.
- **Architecture docs** — `doc/en/architecture.md` gained an "Async Pipelines" table and a dedicated VFS section.

### Changed
- **Massive startup / interaction perf work.** Opening a session whose FileManagers root at a tracked home directory used to freeze the UI for seconds. Each of the following moved off the main thread, all polling through the existing `tick()` pattern:
  - Initial directory read.
  - Subtree expand (local: spawn worker, placeholder `…` row; matches the existing remote pattern).
  - Git status / git log panel refresh (5–6 `git` calls per refresh).
  - Git submodule discovery (`RepoManager` — only the top-level repo is found sync; submodules fold in via `poll`).
  - File-search git status walk.
  - Session restore — every panel in a group is built on its own worker thread, then joined in saved order.
  - Watcher repository registration — `WalkBuilder` traversal moved to a worker; `inotify_add_watch` calls are chunked across ticks (`INSTALL_CHUNK = 256`) so a 5000-directory repo doesn't spike a single tick.
- **SFTP transfers are pause-correct.** The actor now serves only atomic open / read-chunk / write-chunk / close commands; the chunk loop lives on a sync worker and polls pause/cancel between dispatches. A paused upload actually stops the byte stream, and other panels' `list_dir` requests still go through unblocked.
- **Same-host SFTP / FTP renames stay on the server** — `mv` within one connection no longer downloads and re-uploads.
- **Wide-view directory size** — default per-walk budget lowered from 1000 ms → 100 ms; `Space` on a directory also publishes its exact size into the shared cache so the column picks it up on the next redraw.
- **Config / session load failures route to the Journal** instead of stderr-before-raw-mode where the message scrolled away.
- **Editor** — cursor and current-line highlight hidden when the panel is unfocused; the visual state now matches the FileManager.
- **Modal block** — an empty title no longer punches a 1-cell gap through the top border.
- **Async tree-expand for remote FileManager panels** with `…` placeholder rows; duplicate-on-repeat-expand fixed in the same pass.
- **Inline blame annotation** in wrapped editor lines anchors to the last wrap-row instead of the cursor's row.

### Fixed
- Several SFTP cancel-edge cases: hanging actor on cancel, file handles left open, stale receivers wedging the russh-sftp request-id space — pause / cancel / reconnect are clean now (the cached `ConnectOptions` enables seamless auto-reconnect after a cancelled transfer).
- Remote panel rename routed through local `fs::*` (created a local dir + leftover file); now goes through the VFS path.
- Newly-created file/dir cursor placement: matches by full path, so an entry nested inside an expanded subdir is found correctly.
- Repeated expand on a remote directory used to duplicate children.
- Paste from clipboard always landed at the panel root regardless of cursor position.
- Editor → Commands: editing a project command's hotkey now invalidates the in-memory hotkey table so the rebind takes effect immediately.
- Panel terminal: live output no longer drags the user's scrollback position toward the tail.

### Removed
- **`--features vendored-openssl` build flag** — the workspace is pure-Rust (rustls + russh + russh-sftp), no OpenSSL footprint. The flag was a no-op already; removed from `release.yml`.

### CI / DX
- New `.github/workflows/ci.yml` runs fmt / check / clippy / test on every PR and push to main (release.yml stays release-only).
- `deny.toml` + `cargo-deny check` step covers advisories, licenses, bans and sources.
- Pre-commit hook documented in `CONTRIBUTING.md`.

[0.30.0]: https://github.com/termide/termide/releases/tag/0.30.0
[0.29.7]: https://github.com/termide/termide/releases/tag/0.29.7
[0.29.6]: https://github.com/termide/termide/releases/tag/0.29.6
[0.29.5]: https://github.com/termide/termide/releases/tag/0.29.5
[0.29.4]: https://github.com/termide/termide/releases/tag/0.29.4
[0.29.3]: https://github.com/termide/termide/releases/tag/0.29.3
[0.29.2]: https://github.com/termide/termide/releases/tag/0.29.2
[0.29.1]: https://github.com/termide/termide/releases/tag/0.29.1
[0.29.0]: https://github.com/termide/termide/releases/tag/0.29.0
[0.28.0]: https://github.com/termide/termide/releases/tag/0.28.0
[0.27.0]: https://github.com/termide/termide/releases/tag/0.27.0
[0.26.0]: https://github.com/termide/termide/releases/tag/0.26.0
[0.25.1]: https://github.com/termide/termide/releases/tag/0.25.1
[0.25.0]: https://github.com/termide/termide/releases/tag/0.25.0
[0.24.1]: https://github.com/termide/termide/releases/tag/0.24.1
[0.24.0]: https://github.com/termide/termide/releases/tag/0.24.0
[0.23.11]: https://github.com/termide/termide/releases/tag/0.23.11
[0.23.10]: https://github.com/termide/termide/releases/tag/0.23.10
[0.23.9]: https://github.com/termide/termide/releases/tag/0.23.9
[0.23.8]: https://github.com/termide/termide/releases/tag/0.23.8
[0.23.7]: https://github.com/termide/termide/releases/tag/0.23.7
[0.23.6]: https://github.com/termide/termide/releases/tag/0.23.6
[0.23.5]: https://github.com/termide/termide/releases/tag/0.23.5
[0.23.4]: https://github.com/termide/termide/releases/tag/0.23.4
[0.23.3]: https://github.com/termide/termide/releases/tag/0.23.3
[0.23.2]: https://github.com/termide/termide/releases/tag/0.23.2
[0.23.1]: https://github.com/termide/termide/releases/tag/0.23.1
[0.23.0]: https://github.com/termide/termide/releases/tag/0.23.0

## [0.22.1] - 2026-05-10

### Added
- **Config**: Layered global + per-project override loading. `<project>/.termide/config.toml` overlays the user's global `~/.config/termide/config.toml`, which in turn overlays built-in defaults. Both files now save **only** fields that differ from their baseline (defaults for global, defaults+global for the project file), so config files stay small and a future release-changed default no longer gets silently masked by the user's saved-as-default value.
- **Settings**: New footer button "Create / Remove project override" — single visual control to start writing a per-project diff or delete it (with confirmation). State derived from the existence of the project file; no separate flag.
- **Editor**: `F8` deletes the current line (or every line touched by the active selection) outside vim mode. Read-only buffers ignore the binding; clipboard is intentionally untouched.

### Changed
- **VFS**: Provider dispatch deduplicated via a closure-based `dispatch_remote` helper (no behavioural change; ~70 LOC removed from `crates/vfs/src/lib.rs`).
- **Cleanup**: Three unused public helpers removed (`is_supported`, `is_language_supported`, `count_files_under`); `panel-terminal` test code re-formatted to silence two `clippy --all-targets` lints.

### Fixed
- **Editor**: Inline blame annotation is now anchored to the last wrap-row of the cursor's logical line in word-wrap mode. Earlier it tried to follow the cursor's exact wrap-row, which on long lines is the row most full of code and pushed the annotation off the right edge — effectively invisible.
- **Panel terminal**: While a background program writes new output, the user's scrollback position no longer drifts toward the live tail. `scroll_up` now bumps `scroll_offset` (capped at scrollback length) when a line goes into the scrollback, so the visible window stays on the same content. Tail-following users (offset == 0) keep seeing the latest output as before.
- **Editor → Commands**: Editing a project command's hotkey through the modal now invalidates the in-memory hotkey table, so the rebind takes effect immediately and survives a restart.

### Security
- **openssl** bumped to `0.10.79` (transitive via `native-tls → suppaftp → termide-vfs`), closing GHSA-xv59-967r-8726 / CVE-2026-44662 (heap overflow in AES key-wrap-with-padding) and GHSA-xp3w-r5p5-63rr / CVE-2026-42327 (UB in `X509Ref::ocsp_responders` on non-UTF-8 OCSP URLs). Termide does not exercise either code path directly.

[0.22.1]: https://github.com/termide/termide/releases/tag/0.22.1

## [0.22.0] - 2026-04-30

### Added
- **Layout**: Unified accordion + split layout model with three-mode header drag and live vertical-divider resize (#18)
- **Layout**: Split-mode borders and `Alt+Shift+=` / `Alt+Shift+-` step resize for the focused panel

### Changed
- **Hotkeys**: Single end-to-end canonicalization at the matcher boundary — Cyrillic→Latin, shifted-glyph undo, Caps-Lock strip on letters, and VTE-only legacy quirks (`Ctrl+7→Ctrl+/`, `Ctrl+4→Ctrl+\`); inline conflict warnings in the keybinding picker; startup warnings for chords that require Kitty proto
- **Hotkeys defaults**: Tighter punctuation defaults — `panel_grow_vertical`/`panel_shrink_vertical` → `Alt+Shift+=`/`Alt+Shift+-`; `open_sessions` → `Alt+\`; `*.switch_directory` → `Ctrl+\`; `editor.toggle_comment` → `["Ctrl+/", "Ctrl+."]`; `editor.replace_all` → `["Ctrl+Alt+R", "Alt+R"]`; `editor.trigger_completion` → `["Ctrl+J", "Ctrl+Space"]`
- **Layout**: Accordion and split modes share one layout model; resize, drag, and keyboard-resize behaviour now identical in both
- **VFS**: `VfsManager` provider dispatch deduplicated via a closure-based `dispatch_remote` helper; semantics preserved (read-guard scope, cache invalidation)
- **Cleanup**: Dead helpers pruned across `i18n`/`highlight`/`panel-git-status`; two `clippy --all-targets` lints (test-only) silenced; visibility tightened on tree helpers in `panel-git-status`

### Fixed
- **Commands**: Editing a command via the modal now invalidates the cached hotkey table, so the rebind takes effect immediately and survives a restart
- **Commands**: Project-local `commands.toml` is honoured after a session switch — `commands_registry` and `hotkey_table` are reset on `project_root` change in `switch_to_session` / `create_new_session` / `move_session_to`
- **Commands**: Refined command-config editing flow and local-definition handling
- **Mouse**: Wheel events route to the panel under the cursor instead of the active panel
- **Operations panel**: Status icons normalised to match the rest of the UI
- **File ops**: Symlink destination handling unified across copy paths
- **Panel terminal**: Input passthrough compatibility with more shells / TUIs

### Documentation
- Hotkeys reference (`doc/{en,ru,zh}/keybindings.md`) refreshed; new panel-resize step documented; drag-overlay copy updated
- Shared project skills generalised so non-Anthropic agents can run them

[0.22.0]: https://github.com/termide/termide/releases/tag/0.22.0

## [0.21.0] - 2026-04-27

### Added
- **Menu**: Battery percentage and AC-charging indicator next to the clock
- **Modal**: Mouse-wheel scrolling in list modals
- **Editor**: Shift+click to extend text selection (with Alt+click fallback)
- **Editor**: Click the Tab indicator in the status bar to override `tab_size` per editor
- **File Manager**: Wide-view directory size computation with a per-frame time budget
- **File Manager**: Directory symlinks included in wide-view size walks
- **File Manager**: Directory-size cache shared across all FM panels and preserved across navigation
- **File Manager**: Symlink target shown in the properties modal; nested-entry status bar arrow fixed

### Changed
- **Performance (input)**: Drain Release/Repeat key events without generating idle ticks; fewer hotkey-table rebuilds and lower idle poll latency
- **Performance (system-monitor)**: Cache mount/process/network lookups; battery readings cached instead of rereading `/sys` every frame; removed duplicated `disk_space` module
- **Performance (file-manager)**: Async directory reload for watcher-triggered updates
- **Performance (editor)**: Wrap points precomputed once per physical line; per-render diagnostics-by-line map built once
- **Performance (highlight)**: Syntax fallback returns `Cow<str>` segments to skip `String` allocations
- **Performance (core)**: `Panel::prepare_render` borrows `Arc<Config>` instead of cloning
- **Performance (app)**: LSP diagnostics fan-out folded into a single panel loop
- **Performance (misc)**: Cache foreground-command lookup, menu layout and hunk regex; consolidate per-frame panel iterations
- **Observability**: Swallowed filesystem and Git errors are now logged instead of silently discarded
- **i18n**: Trivial string accessors generated via macro; `normalize_lang` made internal
- **Workspace**: `scripts` renamed to `commands` across the codebase; ~1.7K LOC of dead code pruned, several public APIs tightened to `pub(crate)`

### Fixed
- **Hotkeys**: Letter bindings honour Caps Lock state via the Kitty keyboard protocol
- **Terminal**: Encode Ctrl/Shift/Alt modifiers for arrow, Home and End keys (#17)
- **Terminal**: Keep the PTY screen alive on very small terminal sizes
- **Modal**: Coalesced mouse-wheel events routed into the active modal
- **Modal**: Tab-size modal no longer shows a stray prompt row
- **Settings**: Removed the non-functional `[X]` close button from the modal title
- **Editor**: Smart-indent triggers gated behind a recognized syntax
- **File Manager**: Disconnected async-reload channels handled gracefully (no more panic)
- **System Monitor**: Add Windows fallback for `get_disk_space_info_cached` so the indicators code path compiles on Windows targets

### Security
- **deps**: Bump `openssl` 0.10.76 → 0.10.78 to address GHSA-pqf5-4pqq-29f5 (CVE-2026-41676), GHSA-8c75-8mhr-p7r9 (CVE-2026-41678), GHSA-ghm9-cr32-g9qj (CVE-2026-41681), GHSA-hppc-g8h3-xhp3 and GHSA-xmgf-hq76-4vx2 — buffer overflow / out-of-bounds advisories in `Deriver::derive`, `aes::unwrap_key`, `MdCtxRef::digest_final` and PSK/cookie/PEM callbacks. Reached transitively via `suppaftp` → `native-tls`.
- **deps**: Bump `rand` 0.8.5 → 0.8.6 to address GHSA-cq8v-f236-94qc (Stacked Borrows soundness issue triggered by custom loggers calling `thread_rng()` under trace-level logging).

## [0.20.1] - 2026-04-21

### Added
- **Panels**: Context menu on `[≡]` button with Close / Split / Merge / Move actions (closes #16)
- **Panels**: Hotkey for panel action context menu (`Alt+K` / `Shift+F10`)
- **Panels**: Drag-and-drop panels by their top border

### Changed
- **Architecture**: Deduplicated drag overlay and menu action dispatch
- **Architecture**: Deduplicated layout-op error handling and navigation bookkeeping

### Fixed
- **Bookmarks**: Suppress xdg-open output to prevent TUI corruption

## [0.20.0] - 2026-04-19

### Added
- **LSP**: Rename symbol (default `F4`) — full WorkspaceEdit flow with prompt modal, guards for unsaved/no-identifier cases, i18n feedback on applied edits across 15 locales
- **Settings**: Redesigned settings modal with sidebar layout, functional groupings with separators, expandable Keybindings group, checkbox `[✓]/[✗]` style, native language names, Tab/Shift+Tab zone cycling
- **InfoModal**: Scrollable content for long script reports — scrollbar on right border, Up/Down/PageUp/PageDown/Home/End + mouse wheel
- **Panels**: `Ctrl+C` copy support across all panels; VTE terminal keyboard handling fix
- **Git**: Stash dropdown menu from git status button (replaces separate stash panel)
- **Git**: `F2` rename stash message in dropdown menu
- **Git**: Stage all / Unstage all / Revert all / Log buttons in git status panel
- **Help**: Help generator reads configurable keybindings instead of hardcoded values
- **i18n**: Translated 46 missing settings/permission keys, added English runtime fallback, `lsp_rename_*` keys across 15 locales

### Changed
- **Architecture**: Decomposed `modal_handler.rs` (1694 → 659 LOC, -61%) into 6 focused submodules (git/bookmark/search/path/progress/script)
- **Architecture**: Decomposed `mouse_handler.rs` (1531 → 530 LOC, -65%) into 3 submodules (indicators/submenu/layout)
- **Architecture**: Added `AppState` facade getters (`is_menu_open`, `is_resource_modal_open`, `has_pending_action`, `active_modal`) and migrated 13 call sites
- **Architecture**: Consolidated 5 scattered batch-operation fields into `BatchOperationState`; activated `app-core` traits (`StateManager`, `ModalManager`, `PanelProvider`, `LayoutController`)
- **Architecture**: Save-and-close flow deduplicated via `queue_remote_editor_upload()` / `force_save_active_editor()` helpers
- **Config**: Migrated all panel hotkeys from hardcoded matchers to config-driven `HotkeyTable`
- **Hotkeys**: `rename_symbol` default set to `F4` to avoid conflict with `save = [F2, Ctrl+S]`
- **Cleanup**: Removed empty `app-event` crate; replaced `eprintln!` with `log` macros; dropped debug logging remnants

### Fixed
- **Security**: Updated `rand` 0.9.2 → 0.9.4 (advisory RUSTSEC)
- **App**: Closed 3 async-upload TODOs — remote editor saves now reliably queue uploads
- **Settings**: UTF-8-safe string truncation in labels (no more panics on multibyte characters)
- **Scripts**: `direnv` JSON integration, `setsid` for process groups, journal prepare_render fix
- **Git**: Directory color uses majority status instead of worst-wins
- **Git**: Stash drop message, `Delete` key handling, and button click offset
- **Git**: Stash dropdown polish and cleanup
- **UI**: Toggle behavior for disk indicator, stash dropdown, terminal submenu, bookmark/script groups
- **UI**: Centred `rwx` headers over permission checkboxes in file properties modal
- **Image**: Prevent double `Escape` firing when closing image viewer

### Removed
- **Crates**: Empty `app-event` crate

[0.21.0]: https://github.com/termide/termide/releases/tag/0.21.0
[0.20.1]: https://github.com/termide/termide/releases/tag/0.20.1
[0.20.0]: https://github.com/termide/termide/releases/tag/0.20.0

## [0.19.0] - 2026-04-14

### Added
- **Scripts**: Form-based script creation (ScriptCreateModal) with name, group, type (Terminal/Background/Report), and project scope
- **Scripts**: F2 rename and Delete with confirmation for scripts and bookmarks in menu
- **Scripts**: Type icons in menu and operation cards (terminal, background, report)
- **Hotkeys**: Config-based `HotkeyTable` system replacing hardcoded key matching — all hotkeys now configurable via TOML
- **Hotkeys**: Cyrillic keyboard normalization for all keys (ЙЦУКЕН → QWERTY mapping including punctuation)
- **Panels**: Escape requests panel close with confirmation dialog
- **Errors**: All errors now shown as InfoModal dialogs instead of transient status bar messages
- **File Manager**: Interactive permissions editor in file info modal
- **Menu**: Disk usage indicator, calendar grid in menu navigation
- **Menu**: Project-local `.termide/` support for bookmarks and scripts
- **Sessions**: Delete session via Delete key in sessions modal

### Changed
- **Hotkeys**: `open_external` unified across FM and Git Log panels — default changed to `O / Alt+Enter` for VTE terminal compatibility
- **Hotkeys**: Removed dead "Universal" hotkeys section from help panel and config (-435 LOC)
- **Operations**: Redesigned operation cards with border titles, icons, and elapsed timer
- **Operations**: Script name shown in card border title instead of generic "Script"
- **Layout**: Width distribution uses largest-remainder algorithm (fixes rounding errors)
- **Refactor**: Removed legacy HotkeyKind/Hotkey/HotkeyProcessor semantic layer
- **Refactor**: Editor blame converted from hotkey toggle to config setting
- **Logging**: Silent `let _ = fs::*` operations replaced with proper error logging

### Fixed
- **SSH**: Prevent blank screen on SSH — skip `supports_keyboard_enhancement()` detection, add panic handler for terminal state recovery, guard against 0×0 terminal size
- **SSH/Terminal**: Add bounds checks to prevent buffer index panics during terminal resize
- **SFTP**: Fix overwrite conflict for local-to-remote copy — use upload request instead of remote-to-remote, resolve destination as file or directory via VFS stat
- **Scripts**: Sanitize filenames in script create/rename (replace invalid chars with `-`)
- **Scripts**: Fix submenu executing wrong script with mixed project/global sources
- **Scripts**: Properly kill scripts on cancel, support parallel report scripts
- **Keyboard**: Restore lost keys from 0.18.2 (PageUp/PageDown/Enter in Outline, Diagnostics, Git panels)
- **Keyboard**: Fix editor F2/F4 binding conflicts with global hotkeys
- **File Operations**: Preserve permissions on copy, use `fs::rename` for same-filesystem move
- **i18n**: Remove duplicate keys, fix unlocalized help panel strings

## [0.18.2] - 2026-04-02

### Added
- **Layout**: Adaptive default layout — 1/2/3 panel groups based on terminal width (<100, 100-139, 140-199, 200+)
- **Directory Picker**: Tree-view navigation with expand/collapse (Right/Left), cursor matching file manager style
- **Hotkey**: `Alt+N` for creating new session (configurable)
- **Theme**: Norton Commander theme auto-selected on Linux VT (16-color terminals)
- **File Manager**: Single-file copy shows full path with filename for inline rename

### Fixed
- **Help Panel**: Opens in wide group instead of narrow sidebar
- **Command Palette**: Category and keybinding columns right-aligned consistently
- **Git**: Directory replacing deleted symlink now shows correct status (Added, not Deleted)
- **Directory Picker**: Long paths truncated left with ellipsis

### Changed
- **Layout**: Auto-width groups now receive remaining space (not average of fixed groups)
- **Documentation**: Updated theme count to 38, added missing themes to tables, Ctrl+Shift+P hotkey

## [0.18.1] - 2026-03-27

### Fixed
- **File Manager**: Canonicalize `current_path` at all write points (new, navigate, GoHomeDir) to fix symlink/bind-mount watcher mismatch — root cause of repeated auto-refresh failures
- **Git**: Skip diff coloring for gitignored files (added `git check-ignore` check)
- **Git**: Count local commits as ahead when remote refs are missing (empty remote after clone)
- **Watcher**: Canonicalize repo root from git events; detect MERGE_HEAD, FETCH_HEAD, REBASE_HEAD, CHERRY_PICK_HEAD
- **Terminal**: Strip spurious newlines from soft-wrapped lines on copy (track per-line `wrapped` flag)
- **Modal**: Use high-contrast fg/bg inversion for buttons in all remaining modals (info, info_action, editable_select, tree_search)
- **Terminal**: Add debug_assert for buffer/wrapped-flag length sync

## [0.18.0] - 2026-03-26

### Added
- **Git Stash Panel**: Dedicated panel for stash management (Pop, Apply, Drop, Diff via context menu); accessible from Tools menu and git-status Stash button; session persistence
- **Git Blame**: Inline blame annotation in editor (Alt+B) showing author, age, commit hash, and summary; enabled by default for git repos; async loading
- **Command Palette**: Quick access to all commands via Ctrl+Shift+P
- **LSP Find References**: Open references panel with Shift+F12 showing all symbol usages across project
- **LSP Rename Symbol**: Rename symbol under cursor with F2 via LSP WorkspaceEdit
- **Themes**: 4 new themes — blue-sky (light), pinky-pie (light), green-backs (light), billiard (dark)
- **Git Diff**: Adaptive diff colors and arrow key navigation

### Changed
- **Git Stash**: Extracted from inline ViewMode in GitStatusPanel into standalone `panel-git-stash` crate with SelectModal context menu
- **Panels**: Git Log, Git Stash, and Git Diff panels are now singletons (reuse existing instead of creating duplicates)
- **Editor**: Opening an already-open file focuses existing tab instead of creating duplicate
- **Modal Buttons**: Use high-contrast fg/bg inversion for reliable readability across all themes
- **Terminal**: F-key escape sequences replaced with lookup table
- **SFTP**: Magic number polling intervals replaced with named constant

### Fixed
- **InputModal**: Left/Right arrows now navigate between OK/Cancel buttons (were intercepted by text input handler)
- **Git**: Lines outside git repo no longer incorrectly highlighted
- **Git Blame**: Annotation rendered on correct line (was off by one)
- **Git Blame**: Age formatter shows months range (avoids "0 years ago")
- **Hotkeys**: Resolved terminal/tmux conflicts, added missing bindings
- **Config**: `switch_directory` hotkey now configurable in file_manager.keybindings

### Refactored
- **PanelExt**: Reduced deprecated downcasts and fixed code duplication
- **Documentation**: Updated hotkey references, added Git Blame docs, Find References and Rename Symbol docs in all 3 languages

## [0.17.4] - 2026-03-24

### Added
- **Git Diff**: File filter dropdown — click the `[filter ▼]` widget to show only Added, Modified, or Deleted files

### Fixed
- **Git**: Subdirectories inside untracked directories now highlighted green (previously only top-level untracked dir was highlighted)
- **File Manager / Git Status**: Actions on deleted files (move, copy, rename) now ignored to prevent errors
- **Editor**: All lines shown as Added (green) for untracked files, matching git status behavior

### Performance
- **Core**: `Panel::prepare_render()` now accepts `Arc<Config>` instead of `&Config`, eliminating per-frame allocations
- **Editor**: Pre-allocated syntax style vectors in line rendering

## [0.17.3] - 2026-03-23

### Added
- **Session Switcher**: Filter input field in the session switching modal — typing filters sessions by path (case-insensitive substring match); backspace removes last character; navigation (↑↓/Enter/Esc) works on filtered results
- **Git Log**: Repo and branch selector dropdowns — click `[repo ▼]` or `[branch ▼]` widgets to open inline dropdown lists for switching repositories and branches directly from the git log panel

### Fixed
- **Git Log**: Clicking an open selector now toggles it closed (instead of reopening); clicking one selector while another is open now switches immediately in one click
- **Git Log**: Branch dropdown aligned with its selector position; branch selector placed immediately after repo selector
- **File Manager**: Bare Cyrillic hotkeys now translated to Latin (e.g., pressing `щ` on ЙЦУКЕН layout acts as `o`)
- **File Manager**: `o` key added as fallback for open-with-external-viewer (in addition to `Ctrl+Enter`)
- **Git Status**: Modifiers cleared when rendering dropdown items to prevent strikethrough style bleeding from previous render
- **Git**: Repository paths canonicalized to deduplicate symlinked repos (prevents same repo appearing twice in repo selector)
- **Editor**: Render cache invalidated after file reload from disk — ensures updated content is displayed immediately

### Changed
- **Assets**: Theme screenshots refreshed, 15 new theme previews added
- **Refactor**: Magic submenu index numbers replaced with named constants (`SESSIONS_SUBMENU_SWITCH`, `TOOLS_SUBMENU_GIT_LOG`, etc.) across all menu action handlers

[0.17.4]: https://github.com/termide/termide/releases/tag/0.17.4
[0.17.3]: https://github.com/termide/termide/releases/tag/0.17.3

## [0.17.2] - 2026-03-22

### Added
- **Menu**: Keyboard navigation over resource indicators — Right/Left arrows now extend beyond the 5 menu items to the 4 right-side indicators (network ↓/↑, CPU, RAM, clock); Enter opens the corresponding modal and closes the menu; indicators highlight with the standard selected style when focused
- **System Monitor**: Network activity modal — clicking the ↓/↑ network indicator opens a modal showing top processes by connections; displays listening TCP ports and established connection count per process, sorted by connections descending; works cross-platform without elevated privileges (Linux: `/proc/net/tcp`+`/proc/<pid>/fd`; macOS: `lsof`; Windows: `netstat`+`tasklist`)

### Changed
- **Layout**: New panels inserted immediately after the currently active panel (instead of appending to the end of the group)
- **Git Status**: Panel now auto-registers with the filesystem watcher independently — no longer requires a file manager panel to be open in the same repository for auto-refresh to work
- **File Manager**: Read-only `R` attribute rendered in `disabled` color (less visual noise)
- **Theme**: Terminal `disabled` color changed from `[200,200,200]` to `[120,120,120]` to be visually distinct from `fg [204,204,204]`

### Fixed
- **App**: Log UTF-16 decode errors in WSL shell detection instead of silently dropping them

## [0.17.1] - 2026-03-21

### Fixed
- **Windows**: Session files now save correctly — drive letter prefix (`C:\`) is stripped via `Path::components()` to prevent sessions from being written to the project root
- **Windows**: Triangle symbols `▶` (U+25B6) replaced with WGL4-compatible `►` (U+25BA) in all UI panels — fixes square/tofu rendering in default Windows console fonts

### Changed
- **Refactor**: `panel-file-manager/src/lib.rs` split into focused modules — `SelectionState`→`selection.rs`, `NavigationState`→`navigation.rs`, git tracking→`git_status.rs`, file-open logic→`operations.rs`; file reduced from 2694→2143 LOC
- **Refactor**: LSP server mutex guards hardened against thread-panic lock poisoning (`unwrap()` → `unwrap_or_else(|e| e.into_inner())`)
- **Refactor**: Eliminated 29 redundant string allocations (`to_string_lossy().to_string()` → `into_owned()`) across multiple crates

## [0.17.0] - 2026-03-20

### Added
- **UI / Editor / Terminal**: Hex color preview popup on `Ctrl+click` — clicking on a `#rgb` or `#rrggbb` value shows a color swatch while the button is held; works in both the editor and terminal panels
- **Theme**: 9 new built-in themes: `ayu-dark`, `catppuccin-macchiato`, `everforest`, `github-dark`, `gruvbox`, `kanagawa`, `material-ocean`, `rosepine`, `tokyonight`

### Fixed
- **Theme**: Menu bar items and editor cursor line now use `accented_fg` on `accented_bg` surfaces — fixes low-contrast rendering in `windows-98`, `dos-navigator`, and similar themes
- **Theme**: Disabled color contrast improved in classic retro themes (`norton-commander`, `volkov-commander`, `far-manager`, `windows-95`); `github-light` error color corrected to GitHub red
- **UI**: Indic script cursor desync fixed via unicode-width fork — cursor no longer drifts when editing text containing Devanagari, Bengali, or other complex scripts
- **File Manager**: Right arrow key now only expands directories in tree view; no longer also triggers directory entry
- **App**: Fixed double-nesting when copying a directory with OverwriteAll conflict mode selected

### Changed
- **Refactor**: Removed leaky pub exports, dead methods, and simplified regex statics across multiple crates (no behavior change)

## [0.16.4] - 2026-03-19

### Fixed
- **Git Status**: Pull button was silently truncated in narrow panels — buttons now wrap to the next line instead of being cut off
- **Git Status**: Button order changed to Pull → Push → Diff → Commit so the most critical sync actions appear first and are always visible
- **Git**: Files inside untracked directories now correctly show as Added in file manager git status
- **App**: `git fetch` errors are now displayed in the status bar instead of being silently swallowed
- **CI**: AUR PKGBUILD is now synced from the repository before version substitution

### Changed
- **Git Status / App**: Git panels (git-status, git-log) now sync their repository list when the user navigates to a new directory, so the panel reflects the current repo without a manual refresh
- **Refactor**: `ThemeColors` now derives `Copy` — eliminates heap allocations on every render frame
- **Refactor**: Parallel `unstaged_*` / `staged_*` tree fields in `GitStatusPanel` consolidated into a single `FileTree` struct, removing 8 redundant fields
- **Refactor**: Duplicate header rendering code in git-status panel extracted into reusable helpers (×4 → ×2 call sites)

## [0.16.3] - 2026-03-17

### Fixed
- **App**: Disk space in status bar is now cached per tick instead of calling `statvfs` on every render — eliminates potential blocking on NFS mounts under high input rate
- **App**: Resource modal auto-refresh interval unified — CPU, RAM and Disk modals all use `resource_monitor_interval` config (was hardcoded 3 s for process modals); default interval changed from 1 s to 2 s

### Changed
- **App**: Disk modal now auto-refreshes on tick like CPU/RAM modals
- **Refactor**: Preserve original error types in VFS/file-ops paths; remove dead code; optimize rendering hot path

## [0.16.2] - 2026-03-16

### Added
- **Terminal**: Shell picker submenu under Windows > Terminal — lists all available shells, marks default with ●, saves selection to config (#12)
- **Docs**: Document shell picker feature (en, ru, zh)

### Fixed
- **Terminal**: Deduplicate shells in picker by canonical path + basename — eliminates duplicates on NixOS and merged-usr distros while keeping sh/bash as separate entries
- **Windows**: Coalesce pasted text into bracketed paste events (#13)
- **Git**: Unpushed commits indicator was showing total project commits instead of ahead count
- **App**: Clear cached shells when closing menu by clicking outside it
- **UI**: Move Terminal to top of Windows submenu for faster access

## [0.16.1] - 2026-03-16

### Added
- **UI**: Calendar modal on clock click — monthly grid with day navigation (arrows, PgUp/PgDn for months, Home to jump to today)
- **UI**: Colorized panel titles and improved status bar styling
- **Git Log**: Open commit in browser with `o` / `Shift+Enter`
- **VFS**: FTP/FTPS and SMB connection support via address bar input

### Changed
- **Refactor**: Deduplicate grapheme utilities into shared `termide-ui` crate
- **Refactor**: Clean up menu bar rendering, remove `TERMIDE_LANG` env variable
- **Performance**: Fix render allocations and SMB error handling
- **Docs**: Sync documentation with recent feature changes

## [0.16.0] - 2026-03-16

### Added
- **Windows**: Native Windows 11/10 support via ConPTY (no WSL required)
- **Windows**: Native Win32 APIs for disk space and process detection
- **Windows**: Git Bash as default shell on Windows
- **Windows**: Windows MSVC build target in CI release workflow
- **Theme**: New `terminal` theme — classic black background inheriting terminal colors
- **Network**: Real-time network throughput monitor (download/upload) in header bar
- **Security**: Symlink validation in scripts loader — prevents directory traversal
- **Security**: 30-second timeout for background git operations (push/pull/fetch)
- **i18n**: `git_operation_timed_out` translation in all 15 locales

### Fixed
- **SSH**: Ghost divider line and drag coalescing for smooth SSH resize
- **File Manager**: Open source files in editor even when executable bit is set
- **Docs**: Sync theme count (24→25), language count (15+→21), remove duplicate doc link
- **Docs**: Fix deb package description language count (19→21)
- **Code**: Cleanup formatting and dead code from PRs #9, #10, #11
- **Build**: Gate executable permission variables behind `#[cfg(unix)]`

### Changed
- **Performance**: Replace PowerShell subprocess calls with native Win32 APIs on Windows
- **Docs**: Add native Windows installation section to all 3 language docs
- **Docs**: Update platform list to include native Windows support

## [0.15.4] - 2026-03-15

### Added
- **Git Status**: Trigger background `git fetch` on Ctrl+R refresh
- **App**: Bell notification for git push/pull completion and terminal exit
- **Clipboard**: OSC 52 clipboard fallback for SSH/headless sessions

### Fixed
- **Terminal**: Prevent panic on UTF-8 search (Cyrillic, emoji) — advance by match length instead of 1 byte
- **File Manager**: Use full path when entering nested directory in tree view

### Changed
- **Performance**: Skip mouse handler processing and simplify OSC 52 logic
- **Performance**: Skip idle timer reset and forced redraw on mouse hover
- **Performance**: Replace `.repeat()` padding with static `PAD` slice in file manager rendering
- **Performance**: Cache menu layout in `MenuLayout` struct to avoid repeated allocations
- **Refactor**: Improve VFS error logging in batch handler
- **Refactor**: Remove dead `find_visible_by_path` method

## [0.15.3] - 2026-03-13

### Added
- **Git Status**: Single-click directory icon to expand/collapse tree nodes

### Fixed
- **Modal**: Correct quit confirm title and button layout
- **Modal**: Adjust checkbox indent and spacing in InputModal
- **i18n**: Add `modal_confirm_title` key — ConfirmModal no longer shows "Yes" as title
- **i18n**: Localize hardcoded "Confirm" string in file manager paste confirmation
- **Docs**: Fix syntax highlighting language count in README (19→21)
- **Docs**: Update CONTRIBUTING.md with current i18n architecture (15 languages, TOML-based)

### Changed
- **Refactor**: Replace SelectModal with ChoiceModal for editor close dialogs

## [0.15.2] - 2026-03-13

### Added
- **File Manager**: Tree view with expandable/collapsible directories (`→`/`←` or `l`/`h` in vim mode)
- **File Manager**: In-tree incremental search (`/`) — filter files as you type with auto-expanding matches
- **File Manager**: Cascading selection — selecting a directory with `Insert` selects all files within it
- **File Manager**: Nested git status — directories show aggregated status of their children
- **Search Modal**: Unified search modal with file glob and content search modes from file manager (`Ctrl+F` / `Ctrl+Shift+F`)
- **Search Modal**: Tree-based result display with expandable file groups for content search

### Fixed
- **Search Modal**: Tab/Shift+Tab now trigger initial search in non-Text modes (matching F3/Shift+F3 behavior)
- **Git**: Handle empty original content for new/untracked files in diff cache

### Changed
- **Refactor**: Deduplicated nested submenu navigation in menu actions
- **Refactor**: Unified git-status file selection and tree building helpers
- **Refactor**: Extracted VFS URL parsing and source name helpers in batch handler
- **Performance**: Cached line boundary calculations in git-status panel loops

## [0.15.1] - 2026-03-11

### Added
- **Terminal**: Text search with `Ctrl+F` — search across scrollback buffer and visible screen with match highlighting, navigation, and auto-scroll
- **Core**: `Searchable` trait for unified search across Editor, Journal, and Terminal panels
- **Search Modal**: Button focus area with keyboard navigation (Down/Up to switch, Left/Right between buttons)

### Fixed
- **Terminal**: Default search keybinding changed from `Ctrl+Shift+F` to `Ctrl+F` — host terminals (GNOME Terminal, etc.) intercept `Ctrl+Shift+F`
- **Journal**: Auto-scroll suppressed during active search to keep viewport on current match

## [0.15.0] - 2026-03-10

### Added
- **File Manager**: Symlink creation from copy modal and follow-symlink navigation
- **UI**: Emoji icons for panel types in title bars
- **File Manager**: Font modifier styling — ITALIC for symlinks, BOLD for executables
- **File Manager**: Grouped sorting — directories → executables → regular files

### Changed
- **Editor**: Git gutter uses background-colored line numbers with auto-contrast instead of foreground coloring
- **Refactor**: Reduced coupling, tightened visibility (`pub(crate)`), extracted panel factory
- **Performance**: Cached SFTP file name allocations, reduced per-frame config cloning
- **Docs**: Updated README and docs — CLI options, Ctrl+/ comment toggle, package managers

### Fixed
- **Git**: Inline diff detection for consecutive modified lines (Del…Del Ins…Ins blocks now paired correctly)
- **Git**: Symlink path resolution — `canonicalize()` before `strip_prefix()` for diff loading
- **Git Status**: Directory label format in tree view
- **UI**: Tilde expansion for paths in copy/move/symlink/save-as modals
- **File Ops**: Prevent symlink deletion from destroying target data
- **File Manager**: Prevent ".." from being selectable
- **UI**: Double spacing in collapsed panel headers

## [0.14.3] - 2026-03-08

### Fixed
- **Resource Modals**: Normalize CPU % by core count (0–100% of total capacity instead of per-core)
- **Resource Modals**: Filter out threads (VfsLoader, GC-marker) and kernel threads from process lists
- **Resource Modals**: Add spacing between count and CPU columns to prevent overlap at high values
- **Resource Modals**: Always show process count (was hidden when count=1)
- **Resource Modals**: Remove colon separator in Segments modal rows
- **Resource Modals**: Auto-refresh CPU/RAM modal content every 3 seconds
- **SSH**: Validate port range (1–65535) instead of digits-only check

### Changed
- **Disk Modal**: Redesigned with free%, free, total columns and colored free values
- **Disk Modal**: Added column headers with i18n support (15 languages)
- **Performance**: Zero-allocation case-insensitive sort in file manager (was allocating on every comparison)
- **Performance**: Terminal keybindings cloned only when config changes (was cloned every frame)
- **Code Quality**: Synced ConflictResolution variants across core/modal/file-ops
- **Code Quality**: Added `#[must_use]` to 11 pure getters in BookmarksConfig
- **Security**: FTP password zeroed in memory on provider drop

## [0.14.2] - 2026-03-06

### Added
- **Editor**: Toggle comment with Ctrl+/ (line/block comment support)
- **Keyboard**: Ctrl+/ added to help panel shortcuts

### Fixed
- **Keyboard**: Normalize Ctrl+/ for legacy terminals (Ctrl+_ mapping)
- **App**: Require double-click on title bar to open directory picker (prevents accidental opens)

## [0.14.1] - 2026-03-04

### Added
- **File Manager**: F3 opens files in read-only mode (view mode)
- **File Manager**: Directory picker on title click for quick navigation
- **File Manager**: Keyboard shortcuts for rename (R/F2), view (V/F3), edit (E/F4), new file (F/Ctrl+N)
- **Git Status**: Keyboard shortcuts for revert, view, edit
- **Layout**: Improved accordion panel insertion and removal behavior
- **Git Status**: Auto-fetch on init to show correct pull button

### Changed
- **I18n**: `init()` and `init_with_language()` return `Result` instead of panicking
- **Codebase**: Added `must_use` attributes, fixed unsafe unwrap

### Fixed
- **Terminal**: Resize alternate screen buffer on window resize
- **Git**: Canonicalize paths before strip_prefix for symlink repos
- **File Manager**: Deleted files appearing in wrong directories
- **Keyboard**: Fixed incorrect and missing keyboard shortcuts in documentation

## [0.14.0] - 2026-02-25

### Added
- **UI**: Replace home directory prefix with `~` in terminal title, FileManager panel titles, sessions modal, and directory switcher
- **UI**: Update terminal window title when switching or creating sessions
- **Editor**: Ctrl+Up/Down for paragraph/symbol navigation

### Changed
- **UI**: Deduplicate dropdown hit-test logic, fix swallowed errors in menu rendering
- **Panel Operations**: Auto-close operations panel when it becomes empty

## [0.13.0] - 2026-02-24

### Added
- **Editor**: Auto-closing brackets and quotes with context-aware logic (don't close apostrophes mid-word)
- **Editor**: Ctrl+Left/Right word navigation and Ctrl+Shift+Left/Right word selection
- **Editor**: Split-bracket indent on Enter between matching pairs (`{|}` → three lines with proper indentation)
- **Editor**: `auto_indent` and `auto_close_brackets` configuration options

### Changed
- **VFS**: Deduplicate SFTP operations via `spawn_op`/`spawn_op2` helpers (-224 LOC)
- **I18n**: Replace unsafe pointer cast in `t()` with safe `Box::leak` approach
- **I18n**: Use fallback instead of guard-checked `expect` in pluralization
- **Editor**: Extract word boundary logic from vim motions into shared `word_boundary` module

## [0.12.6] - 2026-02-23

### Added
- **CLI**: `--log-level`, `--no-lsp`, `--config` command-line arguments
- **CLI**: Set terminal window/tab title to "Termide: <cwd>" on startup
- **Logger**: TRACE log level and trace user input events

### Changed
- **Git Status**: Remove flat view mode, always use tree view
- **ProgressModal**: Deduplicate 8 constructors via shared base + struct update syntax (-166 LOC)
- **API**: Return `&[T]` instead of `&Vec<T>` in `PanelGroup::panels()` and `TerminalScreen::get_line_by_absolute()`
- **Constants**: Centralize `MEGABYTE` in `termide-config`, remove duplicates from `panel-editor` and `modal`
- **Codebase**: Remove unused `_buffer` parameter from `build_diagnostic_maps`
- **Codebase**: Remove redundant clones, deduplicate constructors, fix unwrap

### Fixed
- **Editor**: Invalidate wrap cache on selection delete
- **Journal**: Account for trailing empty line in auto-scroll check
- **Journal**: Bind auto-scroll to cursor position instead of key codes
- **Terminal**: Update cursor position on arrow key movement

## [0.12.5] - 2026-02-18

### Added
- **Git Status**: Auto-switch between tree and flat view based on panel width (>= 35 columns)

### Changed
- **Codebase**: Extract `TREE_VIEW_MIN_WIDTH` and `MAX_RECURSION_DEPTH` shared constants
- **Codebase**: Consolidate `SpeedTracker` into `file-ops` crate, re-export from `state`
- **Terminal**: Deduplicate constructor code via `set_env`/`spawn_reader`/`build` helpers
- **Git Status**: Optimize tree prefix computation from O(n²) to O(n) reverse scan
- **Clipboard**: Graceful fallback on headless systems instead of panic

### Fixed
- **Editor**: Correct cursor positioning with wide characters at wrap boundary and in no-wrap mode
- **Session**: Prevent duplicate unsaved buffer files on auto-save

## [0.12.4] - 2026-02-17

### Added
- **Outline**: YAML and XML regex fallback for outline panel when tree-sitter is unavailable

### Changed
- **Editor**: Extract viewport/scrolling logic into dedicated `editor_viewport.rs` module (-572 LOC from core.rs)
- **Editor**: Extract generic `poll_receiver` helper to deduplicate LSP polling methods
- **Codebase**: Replace magic numbers with named constants (`PROGRESS_THROTTLE_FILES`, `EXECUTABLE_MASK`)
- **Codebase**: Preserve error context in VFS lock/channel/FTP operations instead of discarding
- **Codebase**: Replace `is_none() + unwrap()` pattern with `is_none_or` and double `.all()` iteration with single-pass check

### Fixed
- **Git**: Show local commit count as ahead when no remote/upstream is configured
- **Git Status**: Re-discover git repository on refresh after external `git init`
- **Session**: Restore non-empty orphaned unsaved buffers instead of deleting them
- **Editor**: Invalidate word-wrap cache on undo/redo, replace, and vim edits

## [0.12.3] - 2026-02-09

### Added
- **Status Bar**: Display LF/CRLF line ending indicator before encoding (UTF-8) in editor status bar

### Changed
- **Codebase**: Deduplicate `LineEnding` enum — single definition in buffer crate root, reused internally

### Fixed
- **Buffer**: Normalize CRLF line endings to LF on file load, preserving original type for save
- **Editor**: Normalize line endings on paste for VTE-based terminals
- **Terminal**: Add Alt+Enter as fallback for newline input on VTE terminals
- **Codebase**: Reduce duplication and improve safety across VFS and rendering modules

## [0.12.2] - 2026-02-08

### Added
- **i18n**: Complete Chinese (zh) localization — translated all remaining English UI strings
- **i18n**: Translated git action labels (stage, unstage, commit, etc.) across all locales
- **Documentation**: Added full Chinese documentation set (doc/zh/) and README.zh.md

### Changed
- **Documentation**: Updated English and Russian docs with new keybindings, menu items, panel types, LSP/Vim sections, and modernized config example

### Fixed
- **Outline Panel**: CJK headings no longer truncated to first character — use display width instead of character index for positioning

## [0.12.1] - 2026-02-08

### Added
- **File Manager**: Toggle hidden files visibility with `.` key

### Changed
- **InfoModal**: Colored segments, multiline support and truncation
- **Codebase**: Rename Welcome remnants to Help across codebase

### Fixed
- **Layout**: Refresh stale panels on next/prev switch in group — fixes Outline going empty after panel switching
- **File Manager**: Treat directory symlinks as directories
- **App**: Enable search in vim normal mode and JournalPanel
- **Outline**: Repopulate outline after expanding collapsed panel

## [0.12.0] - 2026-02-07

### Added
- **Outline Panel**: Structural code navigation using tree-sitter queries with regex fallback for markdown/HTML; tree-drawing prefixes, cursor sync, and keyboard/mouse navigation
- **Global Hotkeys**: Keyboard shortcuts for Outline, Diagnostics, and Git Log panels
- **File Manager Edit Button**: Replaced Git Status button with Edit in file info modal

### Changed
- **Code Quality**: Eliminated unsafe unwraps across app and git crates, deduplicated batch operations
- **Modal Handlers**: Deduplicated modal handlers, added path traversal guard and RwLock recovery
- **Panel Index Cleanup**: Removed obsolete panel_index field, fixed related clippy warnings

### Fixed
- **Outline Sync**: Outline panel now syncs on panel navigation and debounces live edits
- **Outline Resync on Close**: Outline panel rebinds to another editor (or clears) when tracked editor is closed

## [0.11.3] - 2026-02-06

### Added
- **4 New Themes**: Matrix (digital rain), Terminator (Skynet HUD), Pip-Boy (Fallout CRT), Manuscript (medieval parchment)
- **Adaptive Default Layout**: Width-dependent session layout — wide terminals (>= 160 cols) get 3-group layout, normal terminals get 2-group layout with sidebar accordion
- **GitStatus in Default Sidebar**: New sessions automatically include GitStatus panel in the sidebar accordion when a git repository is detected
- **Diagnostic Row Caching**: Editor caches diagnostic row counts for faster viewport scrolling with LSP diagnostics

### Changed
- **State Module Split**: Refactored monolithic `crates/state/src/lib.rs` into submodules: `batch`, `layout`, `operations`, `pending_action`, `ui`
- **Dead Code Removal**: Removed unused functions across 7 crates (`clipboard::has_text`, `git::check_git_available`, `logger::get_entries`, `editor::cleanup_temp_file`, `theme::all_themes`, `theme::builtin_theme_names`, `system_monitor::cpu_usage_float`)
- **Removed text-search Crate**: Deleted unused `termide-text-search` crate from workspace
- **Documentation Update**: Updated README, architecture docs, and developer guides (EN+RU) to reflect current workspace structure, 24 themes, 15 languages, all panel types

### Fixed
- **Security**: Updated `time` crate 0.3.45 → 0.3.47 to fix stack exhaustion DoS vulnerability (GHSA)
- **Editor Diagnostics**: Reverted diagnostic row deduplication in viewport scroll methods that caused incorrect cursor positioning
- **Watcher Registration**: Fixed watchers not being registered on session switch; optimized `.git/objects` watch exclusion
- **Terminal Link Highlight**: Fixed Ctrl+click link highlight offset for non-ASCII content in terminal panel
- **File Manager Git Root**: Preserved `git_root` on internal navigation, fixed post-commit refresh losing git context
- **File Manager Redraw**: Fixed missing redraw after async git status update completed

## [0.11.2] - 2026-02-04

### Fixed
- **UTF-8 Panic**: Fixed byte-index panic when resizing panels with Cyrillic/Unicode text — now truncates by display width, not byte offset
- **Editor Word-Wrap Mouse**: Fixed cursor mispositioning on mouse click in word-wrap mode when git deletion markers are present
- **Editor Word-Wrap Scroll**: Fixed viewport failing to scroll past lines with deletion markers or diagnostics in word-wrap mode
- **Editor Visual Cursor**: Fixed cursor unable to reach end of last visual row during page navigation in word-wrap mode
- **Editor Inline Diff Click**: Fixed mouse click offset in no-wrap mode when inline diff deleted text shifts visual positions
- **Git Status Stale Panel**: Collapsed git-status panel now marks itself stale and refreshes on expand (MarkStale/RefreshIfStale)
- **Git Status Title**: Collapsed git-status panel title now updates branch/file counts on git/filesystem events
- **Git Diff Toggle**: Mouse click on file header in git-diff panel now correctly toggles collapse
- **Operations Panel Focus**: Opening the operations panel no longer steals focus from the active editor
- **CodeQL Security**: Broke taint chain for cleartext-logging alerts in VFS types

## [0.11.1] - 2026-02-01

### Added
- **109 New Tests**: Added tests across 8 crates covering critical gaps (layout, config, buffer, clipboard, core, git, i18n, session)

### Changed
- **Stale-on-Collapse Optimization**: Collapsed panels skip tick/watcher/git/LSP background work; refresh once when expanded again
- **Expanded-Aware Iterators**: Added `iter_all_panels_with_expanded_state_mut()` and `iter_expanded_panels_mut()` to LayoutManager
- **LSP Polling Scoped to Expanded Editors**: Loading status updates only run for visible editor panels

### Fixed
- **CI/Security**: Vendored OpenSSL for cross-platform builds, fixed macOS statvfs types, redacted credentials from logs
- **SFTP Stale Bug**: Remote panels are never marked stale by local fs/git events (prevents broken reconnections)
- **VFS Spinner Hang**: FileManager tick always drains VFS and git-status receivers even when collapsed, preventing stuck spinners
- **VFS Error Draining**: Fixed early return in FileManager tick that prevented VFS error results from being consumed

## [0.11.0] - 2026-02-01

### Added
- **VFS with SFTP Support**: Remote file operations via sftp:// protocol — browse, open, edit, upload, download remote files
- **Unified File Operations System**: OperationManager with pause/cancel support for copy, move, delete, upload, download
- **Operations Panel**: Dedicated panel showing active file operations with progress cards and speed tracking
- **Conflict Resolution**: End-to-end conflict handling — overwrite, skip, rename, overwrite-all, skip-all
- **Byte Progress Bar**: Single-file upload/download progress with byte-level granularity
- **Background Operations Indicator**: Status bar indicator for running file operations
- **Ctrl+C Copy in Terminal**: Copy selected text with Ctrl+C when selection is active
- **Auto-scroll During Selection**: Continuous auto-scroll when dragging mouse beyond editor/terminal viewport
- **Word Wrap Caching**: Cached word wrap functions for faster cursor movement in large files
- **Text Selection in Modals**: Full text selection support in all input fields
- **Word Wrap in Journal**: JournalPanel now supports word-wrapped log entries
- **Version Header in Help**: Help panel displays current version
- **Mouse Scroll Coalescing**: Batched scroll events reduce render cycles during fast scrolling

### Changed
- **i18n Cleanup**: Removed 98 dead translation keys, wired 30 new keys for previously hardcoded UI strings
- **OperationManager Migration**: Migrated local copy, delete, batch upload/download, and directory copy to unified system
- **Logging Migration**: Switched to standard `log` crate macros throughout the codebase
- **Module Decomposition**: Split monolithic `app/mod.rs` into focused submodules (watcher, session, background_ops, etc.)
- **SuggestionInput Component**: Extracted reusable dropdown input widget from bookmark modal
- **Zero-alloc Rendering**: Reduced allocations in rendering hot paths with static buffers
- **Adaptive Tick Rate**: Event loop slows from 24 FPS to 5 FPS after 500ms idle, reducing CPU to near-zero
- **Conditional System Monitor Redraw**: Only redraws status bar when CPU% or memory MB actually changes
- **Watcher Registration**: Split from per-tick polling; registration runs only on panel add/navigate

### Fixed
- **Operations Panel Tracking**: Fixed batch and remote operation tracking in operations panel
- **Conflict Reuse**: Fixed conflict resolution reuse and batch progress tracking
- **Duplicate Downloads**: Prevented duplicate downloads when copying from remote
- **Editor Upload Flow**: Fixed close-after-save and file manager refresh for remote saves
- **Session Panel Widths**: Adapt panel widths to current terminal size on session restore
- **Terminal Duplicate Prompts**: Prevented duplicate prompts during sync_output transitions
- **Editable Select Padding**: Fixed extra empty lines and padding in dropdown
- **VFS Path Sync**: Fixed local directory navigation path synchronization
- **Git Session Restore**: Preserved repository list when restoring session with submodule
- **Unicode Search Highlighting**: Corrected Unicode handling in editor search
- **Spinner CPU Usage**: Throttled spinner redraws to reduce idle CPU
- **Bookmark Navigation**: Fixed dropdown keyboard navigation and mouse click handling

## [0.10.1] - 2026-01-23

### Changed
- **LSP Performance**: Reduced lock contention and reorganized response handling
- **Editor Refactoring**: Extracted mouse handling to separate module
- **Modal Cleanup**: Removed unused panel_index field from SelectOption
- **Theme Colors**: Updated theme color usage in modals and dropdowns

### Fixed
- **Terminal Sync Artifacts**: Defer cache invalidation during sync_output batches to prevent partial frame rendering
- **Terminal Render Clearing**: Clear render area before drawing to prevent visual artifacts
- **Modal Width Stability**: Fixed editable select width during dropdown toggle
- **Terminal Cache**: Added cache invalidation for all buffer-modifying operations

## [0.10.0] - 2026-01-23

### Added
- **Vim Mode**: Full vim keybinding support for Editor panel with Cyrillic keyboard layout support
- **Directory Switcher**: Quick directory navigation modal with Ctrl+P, recent directories, and fuzzy search
- **Bookmark Add Modal**: Smart group input with dropdown suggestions for organizing bookmarks
- **Modal Paste Support**: Paste text directly into modal input fields with control character filtering

### Fixed
- **Terminal Visual Artifacts**: Fixed race condition in sync_output cache invalidation
- **Terminal Batch Rendering**: Force cache invalidation on ED (clear screen) commands
- **Buffer Invariant**: Added ensure_buffer_size() to prevent IL/DL edge cases

### Documentation
- Added documentation for vim mode, directory switcher, and bookmarks features

## [0.9.1] - 2026-01-22

### Added
- **Linux TTY Support**: Native terminal colors for Linux console/framebuffer (TERM=linux)
- **Remote Branch Display**: Git Status panel shows remote branches not available locally
- **DECSTBM Scroll Regions**: Proper CSI scroll region support for terminal applications

### Changed
- **Terminal Refactoring**: Extracted utility modules (clipboard, disk_space, link_detection, shell_utils)
- **Editor Refactoring**: Decomposed core.rs into focused modules (LSP, movement, search, text)
- **Git Refactoring**: Split monolithic lib.rs into command, commits, files, operations modules
- **Performance**: Cached regex patterns for link detection, reduced panel code duplication
- **DRY Improvements**: Extracted helpers for file/terminal opening across panels

### Fixed
- **Synchronized Output**: Fixed cache invalidation when exiting sync_output mode (CSI ? 2026 l)
- **CI Release Notes**: Fixed extraction of release notes from CHANGELOG.md

### Performance
- **Terminal**: Reduced SSH input latency and htop rendering overhead

## [0.9.0] - 2026-01-20

### Added
- **LSP Integration**: Full Language Server Protocol support with completion, diagnostics, hover, and go-to-definition
- **Git Diff Panel**: GitHub-style diff viewer with commit diff viewing from Git Log panel
- **Save As Modal**: New dialog with executable checkbox for setting file permissions (Ctrl+Shift+S)
- **Report Scripts**: Scripts with `.report.` suffix run in background and show output in modal dialog
- **Runtime Language Switching**: Change UI language on the fly with 15 language support
- **Dynamic Help Panel**: Replaced static WelcomePanel with context-aware help
- **Git Status Enhancements**: Init button when no repository, left-ellipsis path truncation, enhanced file properties
- **Terminal Features**: File path detection, multi-line link highlighting, bracketed paste support
- **Editor Features**: Disk space info in status bar, improved PageUp/PageDown behavior
- **UI Improvements**: Smart title truncation with Unicode ellipsis, unified animated spinners

### Changed
- **Menu Renamed**: "Tools" → "Windows", "Actions" → "Scripts" for better UX
- **Keybindings**: Ctrl+Shift+S now opens Save As (was Force Save)
- **Submenu Renamed**: "Manage actions" → "Manage scripts"
- **Git Diff Style**: Unified file headers with termide design system
- **Refactoring**: Extensive code cleanup with Command Pattern, state extraction, and helper consolidation

### Fixed
- **i18n**: Format keys moved to correct section, warnings redirected to journal
- **Git**: Submodule detection by parsing .gitmodules
- **Copy/Move Modals**: Removed duplicate text

### Documentation
- **LSP Docs**: Added comprehensive LSP documentation with configuration examples
- **Scripts Docs**: Updated for new menu names and .report. suffix feature
- **Editor Docs**: Added Ctrl+Shift+S Save As keybinding

## [0.8.9] - 2026-01-15

### Added
- **Terminal URL detection**: Ctrl+hover highlights URLs (cyan + underline), copies to clipboard, Ctrl+click opens in browser
- **ImagePanel reuse**: Browsing images reuses existing panel instead of creating new ones
- **Git async operations**: Push/Pull run in background with spinner indicator and result modal

### Fixed
- **Modal UX**: InfoModal closes only on Enter, Escape, or button click (not any key press)
- **Modal display**: Git operation results show actual output without "Error:"/"Status:" labels
- **Unicode click detection**: Fixed button click detection for Unicode text using grapheme width
- **Git TUI corruption**: Stdout/stderr piped to prevent git output from corrupting terminal display

### Changed
- **Git spinner location**: Moved from status bar to GitStatusPanel for better visibility during panel switches
- **UI cleanup**: Consolidated duplicate code and removed dead code
- **Menu structure**: Restructured menu and fixed log viewer truncation

## [0.8.8] - 2026-01-13

### Security
- **lru vulnerability**: Fixed GHSA-rhfx-m35p-ff5j (IterMut Stacked Borrows violation) by updating to lru 0.16.3

### Added
- **Configurable keybindings**: Full keybinding customization via config.toml for all panels
- **Shared abstractions**: New ClickTracker, Viewport, SelectionStyle utilities for DRY code

### Changed
- **Dependencies**: Updated ratatui 0.29→0.30, ratatui-image 5→10
- **Performance**: 50-500x speedup in hot paths (grapheme iteration, git diff markers, LRU eviction, gitignore checks)
- **Refactoring**: Integrated ClickTracker into GitStatusPanel and FileManager (~40 LOC saved)

## [0.8.7] - 2026-01-12

### Added
- **Install script**: Nix installation method with `nix profile install` for NixOS users
- **Install script**: Nix shown as "(recommended for NixOS)" on NixOS systems

### Fixed
- **Install script**: Works correctly when piped via `curl | sh` (reads from /dev/tty)
- **Install script**: Fixed download URLs (removed incorrect `v` prefix from version)
- **Install script**: Fixed ANSI escape codes appearing literally in success message
- **Install script**: Added `--refresh` flag to ensure latest version is installed via Nix

### Changed
- **Build**: Enabled LTO and strip for release builds (-14% binary size: 29→25 MiB)
- **Packaging**: Removed obsolete help/themes install steps (files are embedded in binary)
- **Nix**: Track Cargo.lock for reproducible flake builds

## [0.8.6] - 2026-01-11

### Added
- **i18n**: 25 missing translation keys for Git panel and preferences in 7 languages (de, es, fr, hi, pt, th, zh)

### Fixed
- **Theme dropdown**: Mouse clicks now work correctly for all items (not just first 12)
- **Terminal paste**: Removed explicit flush preventing React/Ink TUI app overflow errors (e.g., Claude Code)

### Changed
- **README**: Added "Why TermIDE?" comparison table and quick navigation links
- **README**: Fixed theme screenshot paths

## [0.8.5] - 2026-01-07

### Added
- **Universal install script**: New `install.sh` for easy cross-platform installation

### Fixed
- **Config hot-reload**: Editor now applies settings (theme, word_wrap, tab_size) when saving config.toml
- **UTF-8 paths**: Git Status panel correctly handles non-ASCII file paths in truncation

### Changed
- **Git repo discovery**: Repositories now discovered from panel paths instead of project root
- **Performance**: O(n²) → O(n log n) optimization in nested paths removal algorithm
- **Performance**: Reduced allocations in search replace using `take()` instead of `clone()`
- **Code quality**: Extracted helper methods in GitStatusPanel (git operations, rendering, navigation, mouse handling)
- **Code quality**: Removed unused `SearchDirection` and `Action::Group` from buffer module

## [0.8.4] - 2026-01-06

### Added
- **CI/CD automation**: Automatic AUR and Homebrew updates on release via GitHub Actions
- **AUR packages published**: `termide` (source) and `termide-bin` (binary) now available on AUR

### Fixed
- **Terminal text selection**: Selection now uses absolute buffer coordinates
- **Selection persistence**: Selection follows text when scrolling through scrollback
- **Ctrl+Shift+C**: Keyboard shortcut for copying terminal selection
- **Selection cleanup**: Selection cleared on keyboard input
- **Trailing whitespace**: Preserved when copying selected text

## [0.8.3] - 2026-01-01

### Fixed
- CI: Use Ubuntu 22.04 for Linux builds to ensure glibc compatibility with Debian 12

## [0.8.2] - 2026-01-01

### Added
- **Inline diff visualization**: Character-level diff highlighting for modified lines in editor (deleted text in red, inserted in green)
- **Git gutter markers**: Visual indicators in editor line numbers (`+` for added, `~` for modified lines)
- **Revert button**: Quick revert action for individual files in Git Status panel

### Fixed
- Git commands now properly detect repository when editing files in subdirectories
- Inline diff line mapping correctly tracks modified lines when other lines are added/deleted above
- Debian package (.deb) now includes binary in `/usr/bin/`
- README.md download links corrected for .deb and .rpm packages

## [0.8.1] - 2025-12-28

### Added
- **Alt+G hotkey**: Quick access to open/focus Git Status panel
- **Git Status navigation**: Spatial navigation with Up/Down between sections, Left/Right within rows
- **Git Status sticky headers**: Staged/Unstaged headers stay visible when scrolled
- **CommitModal improvements**: PageUp/PageDown support, mouse scroll in textarea
- **Terminal Shift+Enter**: Insert newline for multi-line input

### Fixed
- Git Status panel: PageDown now scrolls fully to show all files
- Terminal: Shift+Enter sends newline instead of CSI u escape sequence
- Editor: Mouse scroll no longer jumps back to cursor position
- CommitModal: Textarea border now uses correct accent color

### Documentation
- Added Shift+Enter shortcut to terminal documentation (EN/RU)
- Added Git panel menu item and Alt+G shortcut to UI docs (EN/RU)
- Updated help files for all 9 languages with Git panel shortcuts

## [0.8.0] - 2025-12-27

### Added
- **Git Status Panel**: Full git status panel with staged/unstaged files, commit/push/pull actions
- **Git Log Panel**: View commit history with navigation
- **Sessions Menu**: New/switch/change-root session actions via Ctrl+S menu
- **CommitModal**: Multi-line textarea for entering commit messages with Commit/Cancel buttons
- **TextArea component**: Multi-line text input with 2D cursor, selection, undo/redo, clipboard support
- **Input field improvements**: Text selection, undo/redo (Ctrl+Z/Y), clipboard support in modal input fields

### Fixed
- Modal input fields: UTF-8 handling, clipboard operations, text selection
- Collapsed panel titles: now show truncated title instead of empty string
- Git Status panel title: properly displays repo name, branch, and status indicators

### Changed
- Git Status panel: spinner icon during refresh, status numbers moved to panel title
- InlineSelector component: improved styling and interaction

## [0.7.0] - 2025-12-18

### Added
- **ImagePanel**: Native image preview using terminal graphics protocols (Kitty, Sixel, iTerm2)
- **Panel resize**: Drag-and-drop panel border resizing with mouse
- **F3 key**: View file without executing (executables open in editor)
- **Shift+Enter**: Force open file with system application (xdg-open)
- **Execute on Enter**: Run executable files directly in terminal
- Smart file type detection: raster images → ImagePanel, vector/video/binary → xdg-open

### Fixed
- Sessions list: cursor now positions on current session
- Editor: off-by-one error in smart word wrap
- SaveAs dialog: now uses file manager's working directory

### Changed
- Split `min_panel_width` config into separate parameters for finer control
- Binary file detection extracted to shared utility (`core::util::is_binary_file`)

### Documentation
- Updated file manager docs with new keyboard shortcuts (F3, Shift+Enter)
- Updated help screens for all 9 languages

## [0.6.1] - 2025-12-16

### Added
- Live theme preview: theme changes on cursor navigation in theme selection menu
- Theme restored on cancel (Esc), saved on confirm (Enter)

### Fixed
- Menu toggle on repeated click (Preferences dropdown now closes on second click)
- Nested submenu toggle (Themes menu closes on repeated click)
- i18n: pluralization for time_*_ago functions (fixed "{plural}" appearing in session list)

### Performance
- Git status: optimized from 6 to 2 git process spawns per call (66% reduction)
- RenamePattern::apply(): reduced allocations using Vec<&str> instead of Vec<String>

### Refactoring
- Extracted CursorNavigation trait for modal cursor navigation (DRY, -70 LOC)
- Extracted git_command helpers to reduce duplication
- DRY improvements in system-monitor and status_bar
- Removed dead code across multiple crates (~300 LOC)

## [0.6.0] - 2025-12-16

### Added
- File search modal (Ctrl+Shift+P) with async glob pattern matching
- Content search modal (Ctrl+Shift+F) with regex support for searching text in files
- Theme selection UI with nested dropdown menu in Preferences
  - Color preview for each theme showing bg/fg and accent colors
  - Immediate theme application and config persistence
- Theme refactoring: `all_theme_names()` and `get_by_name()` API for theme system

### Fixed
- Syntax highlighting fallback to theme foreground color for light themes
- Session modal: current session now highlighted with accent color and selectable
- Session modal and file search UX improvements

### Documentation
- Added file search (Ctrl+Shift+P) and content search (Ctrl+Shift+F) shortcuts
- Updated theme documentation with new menu-based selection method

## [0.5.4] - 2025-12-15

### Added
- Session switching modal (Alt+M → Sessions) to switch between open termide sessions
- Static loading indicator for file watcher initialization (replaced animated Braille spinner)

### Fixed
- Word wrap cursor positioning unified calculation
- Mouse selection offset with word wrap enabled
- Disk space indicator formatting (removed space before unit: "411/467GB")

### Performance
- File watcher now uses `ignore` crate to skip .gitignored directories

### Documentation
- Updated project structure in README and architecture docs to reflect workspace crates
- Updated i18n section to show all 9 supported languages
- Added Ctrl+D (duplicate line) to editor help files

## [0.5.3] - 2025-12-15

### Fixed
- Git status color flickering on directory reload (preserve cache during refresh)
- `.git` directory date not updating on commit when viewing repo root
- Single mouse click copying character to clipboard in terminal (now only drag selection copies)
- File manager git status update timing and CPU format display in menu bar

### Changed
- Unified git and filesystem watchers into single `UnifiedWatcher` with separate debounce intervals (300ms files, 1000ms git)

### Performance
- Optimized rendering and reduced memory allocations

## [0.5.2] - 2025-12-14

### Fixed
- Terminal scroll not working during user input wait (scroll events now bypass modal check)
- i18n placeholders showing '{}' instead of values (all 9 language files updated with named placeholders)

### Changed
- Removed duplicate `/i18n/` folder from project root (was unused copy)
- Moved `/help/` files to `crates/panel-misc/help/` for better code organization

## [0.5.1] - 2025-12-13

### Changed
- Terminal panel performance optimizations
  - Use `has_pending_output()` in event loop for efficient redraw triggering
  - Pre-allocate spans Vec for reduced allocations
  - Use O(1) VecDeque methods for row 0 operations
- Remove crates.io publishing (distribution via GitHub Releases, deb/rpm only)

### Fixed
- Git status display in file info modal now shows actual change count
- File manager cursor resets to position 0 when entering subdirectory
- Version consistency across modal, panel-editor, ui-render crates

## [0.5.0] - 2025-12-13

### Added
- Editor Tab key insertion and block indent/unindent (Tab/Shift+Tab)
- External file change detection with reload/close dialog
- Log viewer panel with Editor-based rendering (cursor, selection support)
- Mouse scroll based on cursor position, not panel focus
- Recursive file watching for git repositories

### Changed
- **Major architecture refactoring**: extracted 31 workspace crates from monolithic src/
  - Modular crate structure: app, app-core, app-event, app-modal, app-panel, etc.
  - Improved build times with incremental compilation
  - Better code organization and separation of concerns
- Type-safe panel communication architecture
  - `PanelCommand` enum replacing unsafe `dyn Any` downcasting
  - `CommandResult` enum for type-safe command responses
  - `handle_command()` method on Panel trait
- Modal dialog code consolidation
  - Shared frame rendering with [X] close button
  - Shared input field rendering with cursor
  - Reduced code duplication in search/replace modals
- Config restructured to nested TOML sections
- Async git diff computation to prevent UI freeze
- Gitignore-aware filesystem updates

### Fixed
- File manager cursor position preserved after file deletion
- Copy/paste operations no longer cause unwanted scroll
- Local timezone display for file modification times
- File sizes rounded to whole units and right-aligned
- Git diff deduplication to prevent UI freeze
- FS watcher feedback loops and deleted files display

### Performance
- Async git diff and gitignore-aware FS updates
- Cache `find_repo_root()` and throttle spinner
- Conditional redraw to reduce idle CPU usage
- Memory optimization: removed redundant clones

### Tests
- PanelCommand and CommandResult unit tests (7 tests in core)
- Editor handle_command integration tests (9 tests)
- FileManager handle_command integration tests (8 tests)
- Modal base module tests (4 tests)
- Large file handling tests (7 tests)
  - 10K+ line file loading and navigation
  - Scroll performance benchmark (50K lines in <100ms)

### Code Quality
- Zero TODO/FIXME comments in production code
- All 5 unsafe blocks documented with SAFETY comments
- Replaced 21+ critical `unwrap()` calls with `expect()` + context messages
- Fixed error swallowing in Editor `handle_key()` - errors now shown to user
- Removed dead code: unused `RequestDirSize` event and `PanelProvider` trait methods
- Optimized `get_selected_text()` - no longer copies entire buffer for large selections

## [0.4.0] - 2025-12-07

### Added
- Double-click word selection in editor
  - Select word between nearest delimiters with double-click
  - Proper handling of alphanumeric word boundaries
- Smart word wrapping with word boundary detection
  - Breaks lines at word boundaries when possible
  - Falls back to hard break for words wider than viewport
- Visual line navigation for word-wrapped text
  - Cursor Up/Down moves through visual lines, not buffer lines
  - Preserves preferred column across visual line movements
- Proper Unicode rendering for CJK and combining characters
  - Chinese/Japanese/Korean characters display with correct 2-column width
  - Hindi and other scripts with combining characters render correctly
  - Uses grapheme clusters for proper text segmentation
- Localization for 7 new languages
  - German (de), Spanish (es), French (fr), Hindi (hi)
  - Japanese (ja), Korean (ko), Portuguese (pt), Thai (th), Chinese (zh)
- Panel reordering hotkeys
  - Alt+[ and Alt+] to reorder panels within current group
  - Alt+PageUp/PageDown context-aware (reorder or switch)
- Kitty keyboard protocol support for proper Alt+Cyrillic handling

### Changed
- Major editor architecture decomposition
  - Extracted cursor movement to dedicated modules (physical, visual)
  - Separated rendering into focused modules (line, wrap, cursor, highlights)
  - Created RenderContext for shared rendering state
  - Keyboard handling with Command Pattern
- Translations migrated from Rust code to TOML files
  - Easier to add/update translations
  - Cleaner separation of concerns
- Terminal VT100 parser extracted to dedicated module
- Extensive code cleanup and DRY refactoring
  - Extracted TextInputHandler for modal inputs
  - Created path_utils module for path resolution
  - Added panel downcast helpers (PanelExt trait)

### Fixed
- Cursor Up/Down navigation with word wrap
- Git status tracking in subdirectories
- Editor navigation and viewport issues with word wrap
- App initialization with correct terminal size

### Performance
- Critical hot path optimizations (100-270x faster)
  - Vec pre-allocation when size is known
  - Eliminated unnecessary string allocations
  - Optimized terminal character shift with copy_within

## [0.3.0] - 2025-12-04

### Added
- Release management Claude Code skill for automated release workflow
  - Pre-release quality checks (fmt, clippy, test, build)
  - Multi-source change analysis (uncommitted, commits, file states)
  - Interactive version selection with validation
  - Automated version updates across 12+ files
  - Auto-generated CHANGELOG entries from git history
  - Post-update quality verification
  - Conventional commit generation and git tag creation
- XDG Base Directory Specification support
  - Config: `~/.config/termide/` (or `$XDG_CONFIG_HOME/termide/`)
  - Data: `~/.local/share/termide/` (or `$XDG_DATA_HOME/termide/`)
  - Cache: `~/.cache/termide/` (or `$XDG_CACHE_HOME/termide/`)
  - Proper cross-platform paths (Linux, macOS, Windows)
- Automatic session persistence with configurable retention
  - Sessions save automatically on focus loss (debounced)
  - Auto-cleanup of sessions older than configured retention period (default: 30 days)
  - Per-project session storage
  - Unsaved buffer persistence across sessions
- Comprehensive project documentation
  - CHANGELOG.md with full version history (0.1.0 to 0.2.0)
  - CONTRIBUTING.md with development guidelines
  - Updated issue templates
  - Revised security policy
  - Contributor Covenant Code of Conduct

### Changed
- **BREAKING**: FileManager is now a regular closable panel
  - Removed special fixed left panel handling
  - FileManager can be closed, resized, and moved between groups
  - Default initialization with 2 FileManager panels (50/50 layout)
  - Simplified architecture (-350 lines of code)
  - All panels are now first-class citizens with identical capabilities
  - Existing sessions will load with default layout

## [0.2.0] - 2025-12-04

### Added
- Comprehensive logging system with configurable levels (debug, info, warn, error)
- Real-time git diff visualization in editor line numbers
  - Display uncommitted changes with color-coded line numbers
  - Show deletion markers with count on horizontal lines
  - In-memory diff computation with debounced updates (300ms)
  - Localized deletion marker text (English/Russian)
- Configurable word wrap option in editor (enabled by default)
- Per-project session storage with automatic unsaved buffer persistence
- Automatic cleanup of old sessions (configurable retention period, default 30 days)
- New configuration options:
  - `word_wrap` - Enable/disable word wrap in editor
  - `min_log_level` - Minimum logging level (debug, info, warn, error)
  - `session_retention_days` - Session cleanup retention period
  - `show_git_diff` - Toggle git diff visualization
  - `fm_extended_view_width` - Minimum width for file manager extended view

### Changed
- Rewrite clipboard system using arboard library
  - Support both CLIPBOARD and PRIMARY selections on Linux
  - More reliable cross-platform clipboard operations
- Improve cursor rendering across all panels
  - Use inverse colors instead of theme selection colors
  - Better visual contrast and cursor visibility
  - Handle reverse attribute correctly in terminal panels
- Improve config auto-completion with hash-based detection
  - Automatically detect ALL missing config keys
  - No manual maintenance of required_keys array
  - Correctly handle optional fields
  - Normalize config file format

### Fixed
- Word wrap rendering bug causing single-line display
- Cursor going off-screen with git diff deletion markers
- Viewport calculations now account for virtual lines (deletion markers)
- Empty line rendering in word wrap mode
- Modified flag after undo/redo operations
- File manager navigation now remembers directory when going up
- Old API tests marked as ignored to fix CI

## [0.1.5] - 2025-12-02

### Fixed
- Package build issues for .deb and .rpm on ARM64 architecture
  - Removed aarch64 from package build matrices to avoid cross-compilation issues
  - Binary tarballs still support all platforms including ARM64

### Added
- Local package build testing script (`scripts/test-packages.sh`)

## [0.1.4] - 2025-12-02

### Added
- Package manager distribution support:
  - Debian/Ubuntu packages (.deb)
  - Fedora/RHEL/CentOS packages (.rpm)
  - Arch Linux AUR packages (source and binary variants)
  - Homebrew formula for macOS/Linux
- Enhanced Nix Flake support:
  - Add `packages.default` output with `rustPlatform.buildRustPackage`
  - Add `apps.default` for `nix run` support
  - Add `overlays.default` for nixpkgs integration
  - Install help files and themes in postInstall phase
- Automatic config file completion for new configuration keys
- Comprehensive installation documentation for all package managers

### Changed
- Reorganize README installation section with collapsible details blocks
- Use emoji icons for better visual navigation in documentation
- Update GitHub Actions workflow to build .deb and .rpm packages automatically

### Fixed
- GitHub Actions workflow dependencies (crates.io publication now requires all builds to succeed)
- Binary paths in cargo-deb and cargo-generate-rpm for cross-compilation
- Fail-fast strategy in build matrices to see all failures

## [0.1.3] - 2025-12-02

### Added
- **Accordion panel system** - Major architectural improvement
  - Smart panel stacking based on terminal width
  - Vertical accordion layout within horizontal groups
  - One expanded panel per group, others collapse to title bar
  - Configurable minimum panel width threshold (80 characters)
- New navigation hotkeys:
  - `Alt+Up/Down` - Navigate panels within group
  - `Alt+PgUp/PgDn` - Move panel to previous/next group
  - `Alt+Home/End` - Move panel to first/last group
  - `Alt+Plus/Minus` - Increase/decrease active group width
  - `Alt+Backspace` - Toggle panel stacking (merge/unstack)
- Developer documentation (`doc/en/architecture.md`, `doc/en/developer-guide.md`)

### Changed
- Complete panel layout system redesign
  - New `LayoutManager` for centralized panel group management
  - New `PanelGroup` for vertical panel stacking
  - Separate panel rendering logic
- Panel width management improvements
  - Fix redistribute after group deletion (8 locations)
  - Add zero-sum balance correction for resize operations
  - Fix auto-stacking calculation to use average width
  - Add proportional width redistribution across all groups

### Removed
- **BREAKING**: Removed `LayoutMode` (SimplePanel/MultiPanel) in favor of dynamic groups
- **BREAKING**: Changed panel navigation model from flat to hierarchical (groups + panels)

## [0.1.2] - 2025-11-29

### Added
- Duplicate line/selection feature (`Ctrl+D`)
- Replace operation feedback ("Replaced N occurrence(s)" message)
- File size validation before opening in editor (100 MB limit)
- Configurable tab size support (reads from `config.toml`)
- Crates.io publishing in release workflow

### Changed
- Migrate to semantic versioning tags without 'v' prefix (e.g., `0.1.2` instead of `v0.1.2`)
- Update license in Cargo.toml from dual (MIT OR Apache-2.0) to MIT only
- Improve error handling across the application
  - Replace panic with graceful error handling in theme parsing
  - Falls back to hardcoded default theme on parse errors
  - Better mutex error handling in terminal (22 `.lock().unwrap()` replaced with `.expect()`)
- Add clear error messages for oversized files

### Fixed
- Application crashes from invalid theme files
- Editor tab size now respects user configuration

## [0.1.1] - 2025-11-25

### Added
- Interactive search modal (`Ctrl+F`) with live preview and match counter
- Interactive replace modal (`Ctrl+H`) with dual input fields
- Tab/Shift+Tab navigation in search mode
- State preservation for search/replace queries
- `[X]` close button on editor panels
- Arrow key navigation between fields in replace modal

### Fixed
- Replace operation skipping matches on same line
- Inconsistent cursor positioning (now always at end of match with selection)
- Prev/Next navigation buttons resetting search state
- Escape key behavior (closes search first, then panel)
- Enter key in replace modal (now replaces instead of deleting)

### Changed
- Update match positions after replacement operations
- Standardize cursor positioning across all search/replace operations

## [0.1.0] - 2025-11-25

### Added
- Initial TermIDE release with complete feature set
- Terminal-based IDE with syntax highlighting for 15+ programming languages
  - Rust, Python, JavaScript, TypeScript, Go, C/C++, Java, Ruby, PHP
  - Haskell, Nix, HTML, CSS, JSON, TOML, YAML, Bash, Markdown
- Smart file manager with intuitive TUI interface
  - File type icons with attributes column
  - Symlink and executable file detection
  - Advanced keyboard and mouse selection controls
  - Recursive git status for directories
- Integrated virtual terminal with full PTY support
  - Ctrl+Shift+V paste with bracketed paste mode
  - 24 FPS rendering
  - Scrollback buffer and ANSI color support
- Multi-panel layout system
- Git integration
  - Background git status monitoring with file watching
  - Automatic updates on repository changes
  - Color-coded status indicators
  - Dimmed styling for gitignored files
  - Support for repository subdirectories
- 12 built-in themes
  - Dark: Default, Midnight, Dracula, OneDark, Monokai, Nord, Solarized Dark
  - Light: Atom One Light, Ayu Light, GitHub Light, Material Lighter, Solarized Light
  - Custom theme support from config directory
- System resource monitoring
  - Real-time CPU and RAM usage
  - Color-coded alerts
- Multi-language support (English, Russian)
  - Full Cyrillic keyboard layout support
  - Case-preserving hotkey translation
- Mouse support for all panels and UI elements
- Clipboard system for cut/copy/paste operations
- Batch file operations (copy, move, delete)
- Quit confirmation for unsaved changes and running processes
- Robust error handling and file size limits
- Automatic directory refresh on filesystem changes
- Cross-platform support (Linux, macOS, Windows via WSL)
- Multi-architecture builds (x86_64, ARM64)

### Technical
- Built with Rust using ratatui TUI framework
- Crossterm for cross-platform terminal manipulation
- Portable-pty for PTY implementation
- Tree-sitter for syntax highlighting
- Ropey for text buffer management
- Sysinfo for system resource monitoring
- Pre-commit hooks for code quality
- Comprehensive test suite
