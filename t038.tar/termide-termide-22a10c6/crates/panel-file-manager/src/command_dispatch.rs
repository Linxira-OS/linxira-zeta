//! File manager command dispatch: hotkey table construction and the
//! `execute_command` router that turns `FmCommand`s into panel events.

use std::path::PathBuf;

use termide_config::{Config, KeyBinding};
use termide_core::{HotkeyTable, PanelEvent};
use termide_git::GitStatus;
use termide_modal::{ActiveModal, ConfirmModal, InputModal};
use termide_state::PendingAction;
use termide_ui::{clipboard, path_utils};

use super::{keyboard, utils, FileManager};

/// Build HotkeyTable for the file manager from config.
pub(crate) fn build_fm_hotkey_table(config: &Config) -> HotkeyTable {
    let mut t = HotkeyTable::new();
    let kb = &config.file_manager.keybindings;

    // File operations
    t.insert("rename", &kb.rename);
    t.insert("view", &kb.view);
    t.insert("edit", &kb.edit);
    t.insert("copy", &kb.copy);
    t.insert("move", &kb.move_item);
    t.insert("create_dir", &kb.create_dir);
    t.insert("create_file", &kb.create_file);
    t.insert("delete", &kb.delete);
    t.insert("info", &kb.info);
    t.insert("pack", &kb.pack);

    // Search
    t.insert("search", &kb.search);
    t.insert("search_content", &kb.search_content);
    t.insert("search_replace", &kb.search_replace);

    // Navigation
    t.insert("refresh", &kb.refresh);
    t.insert("go_parent", &kb.go_parent);
    t.insert("go_home", &kb.go_home);
    t.insert("toggle_selection", &kb.toggle_selection);
    t.insert("select_all", &kb.select_all);
    t.insert("toggle_hidden", &kb.toggle_hidden);

    // open_external: config binding, always ensure O present
    if let Some(ref binding) = kb.open_external {
        let mut keys: Vec<String> = match binding {
            KeyBinding::Single(s) => vec![s.clone()],
            KeyBinding::Multiple(v) => v.clone(),
        };
        if !keys.iter().any(|k| k == "O") {
            keys.push("O".into());
        }
        t.insert("open_external", &Some(KeyBinding::Multiple(keys)));
    } else {
        t.insert(
            "open_external",
            &Some(KeyBinding::Multiple(vec!["O".into(), "Alt+Enter".into()])),
        );
    }
    t.insert("switch_directory", &kb.switch_directory);
    t.insert("go_to_path", &kb.go_to_path);
    t
}

impl FileManager {
    /// Execute a file manager command and return resulting events.
    pub(crate) fn execute_command(&mut self, command: keyboard::FmCommand) -> Vec<PanelEvent> {
        use keyboard::FmCommand;

        let mut events = Vec::new();

        // Say so up front rather than let the operation fail half-way (a
        // move would extract and then fail to delete the source). A modal,
        // because the status bar keeps the file info over an info message.
        if self.vfs.current_path().is_archive() && command.modifies_directory() {
            let t = termide_i18n::t();
            self.show_info_modal(t.modal_error_title(), t.fm_archive_read_only());
            return events;
        }

        match command {
            // Navigation
            FmCommand::MoveUp => self.move_up(),
            FmCommand::MoveDown => self.move_down(),
            FmCommand::PageUp => {
                self.selected = self.selected.saturating_sub(self.visible_height);
            }
            FmCommand::PageDown => {
                let max_index = self.visible_count().saturating_sub(1);
                self.selected = (self.selected + self.visible_height).min(max_index);
            }
            FmCommand::GoHome => {
                self.selected = 0;
                self.scroll_offset = 0;
            }
            FmCommand::GoEnd => {
                self.selected = self.visible_count().saturating_sub(1);
            }
            FmCommand::Enter => {
                if let Some(event) = self.enter() {
                    events.push(event);
                }
            }
            FmCommand::GoParent => {
                // Use VfsState for navigation (works for both local and remote paths)
                // navigate_up returns None if already at root - don't refresh in that case
                if self.at_local_drive_root() {
                    events.push(PanelEvent::OpenDirectorySwitcher);
                } else if self.leave_archive() {
                } else if let Some(dir_name) = self.vfs.navigate_up() {
                    self.navigation.save_for_going_up(dir_name);
                    // Sync local path with VfsState
                    self.current_path = self.vfs.path_buf();
                    let _ = self.load_directory();
                }
            }
            FmCommand::GoHomeDir => {
                if let Some(home) = dirs::home_dir() {
                    self.current_path = dunce::canonicalize(&home).unwrap_or(home);
                    let _ = self.load_directory();
                }
            }

            // Selection
            FmCommand::ToggleSelection => {
                self.toggle_selection();
            }
            FmCommand::SelectAll => self.select_all(),
            FmCommand::ClearSelection => {
                // If there's a pending VFS operation, cancel it instead of clearing selection
                if self.vfs.has_pending_operation() {
                    if let Some(message) = self.vfs.cancel_pending() {
                        // Sync FileManager path with VfsState
                        self.current_path = self.vfs.path_buf();
                        let _ = self.load_directory();
                        // Show cancellation modal
                        let t = termide_i18n::t();
                        self.show_info_modal(t.connection_cancelled_title(), &message);
                        events.push(PanelEvent::ClearStatus);
                    }
                } else {
                    self.selection.clear();
                }
            }
            FmCommand::MoveUpWithSelection => self.move_up_with_selection(),
            FmCommand::MoveDownWithSelection => self.move_down_with_selection(),
            FmCommand::PageUpWithSelection => self.page_up_with_selection(),
            FmCommand::PageDownWithSelection => self.page_down_with_selection(),
            FmCommand::SelectToHome => self.select_to_home(),
            FmCommand::SelectToEnd => self.select_to_end(),
            FmCommand::MoveUpWithToggle => self.move_up_with_toggle(),
            FmCommand::MoveDownWithToggle => self.move_down_with_toggle(),
            FmCommand::PageUpWithToggle => self.page_up_with_toggle(),
            FmCommand::PageDownWithToggle => self.page_down_with_toggle(),

            // File operations
            FmCommand::NewFile => {
                let t = termide_i18n::t();
                let modal = InputModal::new(t.modal_create_file_title(), "");
                let action = PendingAction::CreateFile {
                    directory: self.current_path.clone(),
                };
                self.modal_request = Some((action, ActiveModal::Input(Box::new(modal))));
            }
            FmCommand::NewDirectory => {
                let t = termide_i18n::t();
                let modal = InputModal::new(t.modal_create_dir_title(), "");
                let action = PendingAction::CreateDirectory {
                    directory: self.current_path.clone(),
                };
                self.modal_request = Some((action, ActiveModal::Input(Box::new(modal))));
            }
            FmCommand::DeleteFiles => {
                if self.is_remote() {
                    // Remote delete - use VfsPath
                    let vfs_paths = self.get_selected_vfs_paths();
                    if !vfs_paths.is_empty() {
                        let t = termide_i18n::t();
                        let title = if vfs_paths.len() == 1 {
                            let file_name = vfs_paths[0]
                                .file_name()
                                .map(|n| n.to_string_lossy().into_owned())
                                .unwrap_or_else(|| "file".to_string());
                            t.modal_delete_single_title(&file_name)
                        } else {
                            t.modal_delete_multiple_title(vfs_paths.len())
                        };
                        let modal = ConfirmModal::new(&title, "");
                        let action = PendingAction::DeleteRemotePath {
                            paths: vfs_paths,
                            vfs_manager: self.vfs_manager_arc(),
                        };
                        self.modal_request = Some((action, ActiveModal::Confirm(Box::new(modal))));
                    }
                } else {
                    // Local delete - use PathBuf
                    let paths = self.get_selected_paths();
                    if !paths.is_empty() {
                        let t = termide_i18n::t();
                        let title = if paths.len() == 1 {
                            let file_name = path_utils::get_file_name_str(&paths[0]);
                            t.modal_delete_single_title(file_name)
                        } else {
                            t.modal_delete_multiple_title(paths.len())
                        };
                        let modal = ConfirmModal::new(&title, "");
                        let action = PendingAction::DeletePath { paths };
                        self.modal_request = Some((action, ActiveModal::Confirm(Box::new(modal))));
                    }
                }
            }
            // The app answers a copy/move request with its own destination
            // picker (`handle_modal_request` sees no target directory), so
            // the modal sent along is a placeholder that is never shown.
            FmCommand::CopyFiles => {
                let paths = self.get_selected_paths();
                if !paths.is_empty() {
                    let action = PendingAction::CopyPath {
                        sources: paths,
                        target_directory: None,
                        create_symlink: false,
                        create_relative_symlink: false,
                    };
                    let modal = InputModal::new("", "");
                    self.modal_request = Some((action, ActiveModal::Input(Box::new(modal))));
                }
            }
            FmCommand::Pack => self.request_pack(),
            FmCommand::MoveFiles => {
                let paths = self.get_selected_paths();
                if !paths.is_empty() {
                    let action = PendingAction::MovePath {
                        sources: paths,
                        target_directory: None,
                    };
                    let modal = InputModal::new("", "");
                    self.modal_request = Some((action, ActiveModal::Input(Box::new(modal))));
                }
            }
            FmCommand::RenameFile => {
                if let Some(te) = self.entry_under_cursor() {
                    let entry = &te.file_entry;
                    // Only allow renaming files and directories (not deleted or special entries)
                    if entry.git_status == GitStatus::Deleted {
                        return events;
                    }
                    let filename = entry.name.clone();
                    // For remote panels we must hand the operation layer a
                    // VFS URL pair, not a local PathBuf — otherwise the
                    // move falls through the `is_vfs_url` check and the
                    // file ends up renamed on the *local* filesystem (a
                    // very nasty surprise when local and remote share a
                    // path like /home/$USER).
                    let (source, target_dir) = if self.vfs.is_remote() {
                        let parent = self.vfs.current_path().clone();
                        let src_url = parent.join(&filename).to_url_string();
                        let parent_url = parent.to_url_string();
                        (PathBuf::from(src_url), Some(PathBuf::from(parent_url)))
                    } else {
                        let path = te.full_path.clone();
                        let parent = path.parent().map(|p| p.to_path_buf());
                        (path, parent)
                    };
                    let t = termide_i18n::t();
                    // The title already says "Rename"; a prompt here would
                    // only repeat the name that is in the field.
                    let modal = InputModal::with_default(t.op_type_rename(), "", &filename);
                    let action = PendingAction::MovePath {
                        sources: vec![source],
                        target_directory: target_dir,
                    };
                    self.modal_request = Some((action, ActiveModal::Input(Box::new(modal))));
                }
            }
            FmCommand::EditFile => {
                if let Some(event) = self.edit_file() {
                    events.push(event);
                }
            }
            FmCommand::ViewFile => {
                if let Some(event) = self.view_file() {
                    events.push(event);
                }
            }
            FmCommand::OpenExternal => {
                if let Some(event) = self.open_external() {
                    events.push(event);
                }
            }

            // Search
            FmCommand::Search => {
                // File-name search is an inline bar docked in the panel.
                self.open_name_bar();
                events.push(PanelEvent::NeedsRedraw);
            }
            FmCommand::SearchContent => {
                // Content search is an inline bar docked in the panel.
                self.open_content_bar(false);
                events.push(PanelEvent::NeedsRedraw);
            }
            FmCommand::SearchReplace => {
                // Content replace: same inline bar with the Replace field.
                self.open_content_bar(true);
                events.push(PanelEvent::NeedsRedraw);
            }

            // Misc
            FmCommand::ShowFileInfo => self.show_file_info(),
            FmCommand::Refresh => {
                let _ = self.reload_directory();
            }
            FmCommand::ToggleHidden => {
                self.show_hidden = !self.show_hidden;
                let _ = self.reload_directory();
            }
            FmCommand::NextPanel => {
                let modal = ConfirmModal::new("", "");
                self.modal_request = Some((
                    PendingAction::NextPanel,
                    ActiveModal::Confirm(Box::new(modal)),
                ));
            }
            FmCommand::PrevPanel => {
                let modal = ConfirmModal::new("", "");
                self.modal_request = Some((
                    PendingAction::PrevPanel,
                    ActiveModal::Confirm(Box::new(modal)),
                ));
            }
            FmCommand::GoToPath => {
                // Open input modal to enter path or URL (supports sftp://, ftp://, etc.)
                let t = termide_i18n::t();
                // Use directory at cursor position (may differ from panel root in tree view)
                let current_path = if let Some(te) = self.tree_entry_at(self.selected) {
                    if te.file_entry.is_dir {
                        te.full_path.display().to_string()
                    } else {
                        te.full_path
                            .parent()
                            .map(|p| p.display().to_string())
                            .unwrap_or_else(|| self.display_path())
                    }
                } else {
                    self.display_path()
                };
                let modal =
                    InputModal::with_default(t.fm_goto_title(), t.fm_goto_prompt(), &current_path);
                let action = PendingAction::GoToPath {
                    current_directory: self.current_path.clone(),
                };
                self.modal_request = Some((action, ActiveModal::Input(Box::new(modal))));
            }

            FmCommand::SwitchDirectory => {
                return vec![PanelEvent::OpenDirectorySwitcher];
            }

            // Tree expand/collapse
            FmCommand::ExpandDir => {
                if let Some(te) = self.tree_entry_at(self.selected) {
                    if te.expanded == Some(false) {
                        self.expand_dir(self.selected);
                    }
                }
            }
            FmCommand::CollapseDir => {
                // If current item is an expanded dir, collapse it
                // If current item is inside an expanded subtree, jump to parent dir
                if let Some(te) = self.tree_entry_at(self.selected) {
                    if te.expanded == Some(true) {
                        self.collapse_dir(self.selected);
                    } else if te.depth > 0 {
                        // Navigate up to parent directory in tree
                        self.jump_to_parent_dir();
                    }
                }
            }

            // No operation
            FmCommand::None => {}
        }

        events
    }

    /// Copy the selected items to the system clipboard (global
    /// `PanelCommand::Copy`).
    ///
    /// Local items go as a native file list so other applications paste them
    /// as files. Two cases stay newline-joined text:
    ///
    /// - Remote and in-archive panels: a `file://` URL cannot name such an
    ///   entry, and a remote panel's `full_path` can look like a local path
    ///   that also exists locally (see the rename path above), so `exists()`
    ///   alone is not a safe test — the panel's protocol is.
    /// - A selection holding a symlink: the file flavor asks the OS for the
    ///   real path, so the link would arrive at the destination as its
    ///   target, under the target's name. Text is the honest fallback. The
    ///   whole selection falls back, not just the link — dropping items from
    ///   the clipboard would be worse than losing the flavor.
    pub(crate) fn clipboard_copy_selection(&self) {
        let paths = self.get_selected_paths();
        if paths.is_empty() {
            return;
        }

        let text = clipboard::paths_to_text(&paths);

        if self.vfs.current_path().is_remote() || self.selection_has_symlink() {
            let _ = clipboard::copy(&text);
            return;
        }

        if let Err(e) = clipboard::copy_files(&paths) {
            log::debug!("file clipboard unavailable ({}), copying paths as text", e);
            let _ = clipboard::copy(&text);
        }
    }

    /// Publish the selected items as a cut (global `PanelCommand::Cut`).
    ///
    /// Local items go as a native file list, exactly like [`Self::
    /// clipboard_copy_selection`], plus the in-app marker that turns a later
    /// paste into a move. Publishing the list is the safe half of the
    /// trade-off: no clipboard format carries a cut flag, so Finder and
    /// Explorer paste a copy and leave the original — a stray copy is one
    /// `rm` away from fixed, a deleted original is not. The move itself
    /// happens inside termide only, and [`clipboard::is_cut`] guards it.
    ///
    /// Remote and in-archive panels refuse instead of degrading to a copy.
    /// `MovePath` takes local paths, so a cut there could not move anything;
    /// letting it publish would leave the user holding a cut that pastes as a
    /// copy with no word said, and a silent copy is the one outcome a cut must
    /// never produce. The refusal names itself, so the keystroke is not lost.
    pub(crate) fn clipboard_cut_selection(&mut self) {
        let paths = self.get_selected_paths();
        if paths.is_empty() {
            return;
        }

        // The archive refusal already exists and reads exactly right; remote
        // needs its own words. The order matters: an in-archive path reports
        // `is_remote()` too, so the archive test has to come first or a cut
        // inside an archive would be refused as if it were remote.
        if self.vfs.current_path().is_archive() {
            let t = termide_i18n::t();
            self.show_info_modal(t.modal_error_title(), t.fm_archive_read_only());
            return;
        }
        if self.vfs.current_path().is_remote() {
            let t = termide_i18n::t();
            self.show_info_modal(t.modal_error_title(), t.fm_cut_local_only());
            return;
        }

        // A selection holding a symlink stays on the text path, as it does for
        // copy: the file flavor asks the OS for the real path, so a move would
        // relocate the target rather than the link.
        if self.selection_has_symlink() {
            let _ = clipboard::cut_paths_as_text(&paths);
            return;
        }

        if let Err(e) = clipboard::cut_files(&paths) {
            log::debug!("file clipboard unavailable ({}), cutting paths as text", e);
            let _ = clipboard::cut_paths_as_text(&paths);
        }
    }

    /// Paste files referenced by the system clipboard into the cursor's tree
    /// level (global `PanelCommand::Paste`).
    ///
    /// Reads the clipboard itself: both the native file list (a copy made by
    /// this panel or by Finder/Explorer) and newline-separated paths.
    pub(crate) fn clipboard_paste_files(&mut self) {
        self.request_paste_of(clipboard::paste_paths());
    }

    /// Paste paths handed over by a bracketed paste (global
    /// `PanelCommand::PasteText`).
    ///
    /// On macOS `Cmd+V` never reaches [`PanelCommand::Paste`]: the terminal
    /// emulator answers it and types the clipboard's text flavor into the
    /// pane, which arrives here. Taking the key only when the text names real
    /// files keeps a prose paste from being swallowed — it falls through to
    /// the panel's normal key handling unchanged.
    ///
    /// Only absolute paths qualify: a relative one would resolve against the
    /// process working directory, not the panel's, so `exists()` could match
    /// an unrelated file and paste it under the wrong name. Termide's own
    /// copy publishes absolute paths, so this only discards text that was
    /// never a file list.
    pub(crate) fn clipboard_paste_text(&mut self, text: &str) -> bool {
        let files: Vec<PathBuf> = clipboard::text_to_paths(text)
            .into_iter()
            .filter(|path| path.is_absolute() && path.exists())
            .collect();

        if files.is_empty() {
            return false;
        }

        self.request_paste_of(files);
        true
    }

    /// Confirm, then land `files` in the cursor's tree level — as a move when
    /// the clipboard still carries them as a cut, otherwise as a copy. The
    /// single path both paste entries funnel through.
    fn request_paste_of(&mut self, files: Vec<PathBuf>) {
        if files.is_empty() {
            return;
        }

        // Land the paste at the cursor's tree level —
        // same rule as create_file / create_dir use via
        // `create_target_dir`. Cursor on a root entry
        // pastes into `current_path`; cursor inside an
        // expanded subdir, or on the expanded subdir
        // itself, pastes into that subdir.
        let (local_target, _vfs_target) = self.create_target_dir();

        // Move only where the destination is local. `MovePath` takes local
        // paths, and a remote panel's target has no scheme here, so a move
        // into one would be resolved against the local filesystem — which
        // would then delete the source and write it somewhere else. Copy is
        // the only honest option there, so the cut is not even consulted.
        // `is_remote()` already covers an in-archive path, which reports it.
        let as_move = !self.vfs.current_path().is_remote() && clipboard::is_cut(&files);

        let t = termide_i18n::t();
        let names = utils::paste_names_summary(&files);
        let dest = local_target.display().to_string();
        let message = if as_move {
            t.fm_paste_move_confirm(files.len(), &names, &dest)
        } else {
            t.fm_paste_confirm(files.len(), &names, &dest)
        };
        let action = if as_move {
            PendingAction::MovePath {
                sources: files,
                target_directory: Some(local_target),
            }
        } else {
            PendingAction::CopyPath {
                sources: files,
                target_directory: Some(local_target),
                create_symlink: false,
                create_relative_symlink: false,
            }
        };
        let modal = ConfirmModal::new(termide_i18n::t().modal_confirm_title(), &message);
        self.modal_request = Some((action, ActiveModal::Confirm(Box::new(modal))));
    }
}
