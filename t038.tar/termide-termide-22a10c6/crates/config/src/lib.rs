//! Configuration management for termide.
//!
//! This crate provides configuration loading, saving, and validation
//! with support for TOML format and XDG directory conventions.

pub mod bookmarks;
pub mod commands;
pub mod conflicts;
pub mod constants;
pub mod diff;
pub mod keybindings;
mod settings;
mod xdg;

pub use bookmarks::{Bookmark, BookmarkType, BookmarksConfig};
pub use conflicts::{
    actions_reachable_only_by_function_key, binding_requires_kitty,
    binding_requires_macos_all_keys, enumerate_bindings, find_conflicts, BindingLocation,
    ConflictKind, HotkeyConflict,
};
pub use diff::{diff_toml, merge_partial};
pub use keybindings::{
    is_go_end, is_go_home, is_move_down, is_move_up, parse_keybinding, DatabaseKeybindings,
    EditorKeybindings, FileManagerKeybindings, GitDiffKeybindings, GitLogKeybindings,
    GitStatusKeybindings, GlobalKeybindings, KeyBinding, ParsedKeyBinding, TerminalKeybindings,
    ViewerKeybindings,
};
pub use settings::{builtin_web_engines, WEB_BACKENDS, WEB_DISPLAYS};
pub use settings::{is_cli_provider, permission_modes};
pub use settings::{
    AiSettings, Config, Connection, CustomLanguage, DatabaseSettings, EditorSettings,
    FileManagerSettings, FoldBlocks, GeneralSettings, GitDiffSettings, GitLogSettings,
    GitStatusSettings, HighlightSettings, IconMode, LegacyConfig, LinkOpen, LoggingSettings,
    LspServerSettings, LspSettings, ReasoningParam, TerminalSettings, VfsSettings, ViewerSettings,
    WebSettings, DEFAULT_CONTEXT_WINDOW_FALLBACK,
};
/// The type of `[ai] reasoning`.
pub use termide_agent_core::ThinkingLevel;
pub use xdg::{get_config_dir, get_data_dir};

use anyhow::Result;
use std::path::{Path, PathBuf};

/// Default values as constants
pub mod defaults {
    pub const THEME_NAME: &str = "default";
    pub const LANGUAGE: &str = "auto";
    pub const AUTO_STACK_THRESHOLD: u16 = 80;
    pub const MIN_PANEL_WIDTH: u16 = 20;
    pub const PROJECT_RETENTION_DAYS: u32 = 30;
    pub const TAB_SIZE: usize = 4;
    pub const SHOW_GIT_DIFF: bool = true;
    pub const WORD_WRAP: bool = true;
    pub const VIM_MODE: bool = false;
    pub const LARGE_FILE_THRESHOLD_MB: u64 = 5;
    pub const CONTENT_SEARCH_MAX_FILE_SIZE_MB: u64 = 1;
    pub const EXTENDED_VIEW_WIDTH: usize = 50;
    pub const FM_DIR_SIZE_IN_WIDE_VIEW: bool = true;
    /// Per-directory time budget (ms) for the size walk rendered in FM wide view.
    /// `0` disables the feature the same way as `FM_DIR_SIZE_IN_WIDE_VIEW = false`.
    pub const FM_DIR_SIZE_BUDGET_MS: u64 = 100;
    pub const MIN_LOG_LEVEL: &str = "info";
    pub const RESOURCE_MONITOR_INTERVAL: u64 = 2000;
    pub const BELL_ON_OPERATION_COMPLETE: bool = true;
    /// Minimum panel width (columns) to enable tree/wide view in list panels
    pub const TREE_VIEW_MIN_WIDTH: u16 = 35;
    // LSP defaults
    pub const LSP_ENABLED: bool = true;
    pub const LSP_AUTO_COMPLETION: bool = true;
    pub const LSP_COMPLETION_DELAY_MS: u64 = 150;
    pub const LSP_HOVER_DELAY_MS: u64 = 1000;
}

/// Path to the per-project config override file:
/// `<project_root>/.termide/config.toml`.
///
/// This path is the single source of truth for whether a project has an
/// active override — its existence enables overlay loading and switches
/// the Settings save target. The file is created/removed by an explicit
/// user action in the Settings modal.
pub fn project_config_path(project_root: &Path) -> PathBuf {
    project_root.join(".termide").join("config.toml")
}

/// The fields `[ai]` described its single endpoint with before connections.
const LEGACY_AI_CONNECTION_KEYS: [&str; 5] = [
    "provider",
    "base_url",
    "model",
    "api_key_env",
    "context_window_fallback",
];

/// The connection a file written before `[ai.connections]` describes.
const LEGACY_AI_CONNECTION: &str = "default";

/// Keys renamed since they were first written: the table they live in, the
/// old name and the new one.
///
/// Serde aliases are not enough for these. A layered load merges the user's
/// file into the serialised defaults, which already hold the new name, and a
/// table with both a field and its alias is rejected as a duplicate — so the
/// old spelling is renamed in the raw file before it is merged.
const RENAMED_KEYS: [(&[&str], &str, &str); 4] = [
    (
        &["general"],
        "session_retention_days",
        "project_retention_days",
    ),
    (
        &["general", "keybindings"],
        "open_sessions",
        "open_projects",
    ),
    (&["general", "keybindings"], "new_session", "new_project"),
    (
        &["general", "keybindings"],
        "detach_session",
        "detach_instance",
    ),
];

/// Read a file written by an earlier version in today's shape.
fn migrate_legacy(value: &mut toml::Value) {
    migrate_renamed_keys(value);
    migrate_ai_connection(value);
    migrate_ai_autofold(value);
}

/// Rename the keys of [`RENAMED_KEYS`]. When a file has both spellings the
/// new one wins and the old one is dropped.
fn migrate_renamed_keys(value: &mut toml::Value) {
    for (table_path, old, new) in RENAMED_KEYS {
        let table = table_path
            .iter()
            .try_fold(&mut *value, |v, key| v.get_mut(*key))
            .and_then(toml::Value::as_table_mut);
        let Some(table) = table else {
            continue;
        };
        if let Some(field) = table.remove(old) {
            table.entry(new).or_insert(field);
        }
    }
}

/// `[ai] autofold = true/false` became `fold_blocks`: folded once a block
/// finishes, or never.
fn migrate_ai_autofold(value: &mut toml::Value) {
    let Some(ai) = value.get_mut("ai").and_then(toml::Value::as_table_mut) else {
        return;
    };
    let Some(autofold) = ai.remove("autofold").and_then(|v| v.as_bool()) else {
        return;
    };
    let fold = if autofold { "on-finish" } else { "never" };
    ai.entry("fold_blocks")
        .or_insert_with(|| toml::Value::String(fold.to_string()));
}

/// Move a pre-connections `[ai]` endpoint into a connection of its own:
/// `provider`, `base_url`, `model`, `api_key_env` and
/// `context_window_fallback` become `[ai.connections.default]`, and new
/// sessions start on it unless `[ai] connection` names another. A file
/// without them is left as it is; the next save writes the new shape.
fn migrate_ai_connection(value: &mut toml::Value) {
    let Some(ai) = value.get_mut("ai").and_then(toml::Value::as_table_mut) else {
        return;
    };
    let mut legacy = toml::value::Table::new();
    for key in LEGACY_AI_CONNECTION_KEYS {
        if let Some(field) = ai.remove(key) {
            legacy.insert(key.to_string(), field);
        }
    }
    if legacy.is_empty() {
        return;
    }
    let connections = ai
        .entry("connections")
        .or_insert_with(|| toml::Value::Table(Default::default()));
    if let Some(connections) = connections.as_table_mut() {
        connections
            .entry(LEGACY_AI_CONNECTION)
            .or_insert(toml::Value::Table(legacy));
    }
    ai.entry("connection")
        .or_insert_with(|| toml::Value::String(LEGACY_AI_CONNECTION.to_string()));
}

/// What [`Config::load_layered`] produced.
#[derive(Debug, Clone)]
pub struct LayeredConfig {
    /// Defaults, overlaid with the global file and then the project file.
    pub effective: Config,
    /// Defaults overlaid with the global file only: the baseline the
    /// project file is diffed against when it is saved.
    pub global_layer: Config,
    /// Settings that were left out, and why, one line per file.
    pub warnings: Vec<String>,
}

/// Overlay the config file at `path`, if it exists, on `value`, keeping
/// only what still parses. What was left out is reported in `warnings`,
/// after the file is copied aside.
fn overlay_file(value: &mut toml::Value, path: &Path, warnings: &mut Vec<String>) {
    if !path.exists() {
        return;
    }
    let parsed = std::fs::read_to_string(path)
        .map_err(|e| e.to_string())
        .and_then(|text| toml::from_str::<toml::Value>(&text).map_err(|e| e.to_string()));
    let problem = match parsed {
        Ok(mut overlay) => {
            migrate_legacy(&mut overlay);
            let rejected = overlay_valid(value, &overlay);
            if rejected.is_empty() {
                return;
            }
            format!("ignored invalid settings: {}", rejected.join("; "))
        }
        Err(e) => format!("not read, using the other layers only: {}", e.trim()),
    };
    let backup = back_up(path);
    warnings.push(match backup {
        Ok(backup) => format!(
            "Config {}: {problem}. The file as it was is kept at {}",
            path.display(),
            backup.display()
        ),
        Err(e) => format!(
            "Config {}: {problem}. Could not copy it aside ({e}); saving settings will drop what was ignored",
            path.display()
        ),
    });
}

/// Whether `text` is a TOML document without any table: the flat format
/// config files had before they were split into sections.
fn is_flat(text: &str) -> bool {
    toml::from_str::<toml::value::Table>(text)
        .is_ok_and(|table| !table.values().any(toml::Value::is_table))
}

/// Copy `path` to `<path>.bak`, replacing an older copy.
fn back_up(path: &Path) -> std::io::Result<PathBuf> {
    let mut name = path.as_os_str().to_owned();
    name.push(".bak");
    let backup = PathBuf::from(name);
    std::fs::copy(path, &backup)?;
    Ok(backup)
}

/// Merge `overlay` into `base` as [`merge_partial`] does, leaving out each
/// setting that would make `base` fail to parse as a [`Config`]. Returns the
/// dotted path of every setting left out, with the reason.
fn overlay_valid(base: &mut toml::Value, overlay: &toml::Value) -> Vec<String> {
    let mut candidate = base.clone();
    merge_partial(&mut candidate, overlay);
    if parse_error(&candidate).is_none() {
        *base = candidate;
        return Vec::new();
    }
    let mut rejected = Vec::new();
    overlay_valid_at(base, &mut Vec::new(), overlay, &mut rejected);
    rejected
}

/// Try each entry of the table `overlay`, found at `path`, on its own. An
/// entry that fails is split further when both it and its counterpart in
/// `base` are tables; otherwise it is left out whole — a table that `base`
/// does not have yet (a new connection, a new LSP server) is only valid
/// with all its fields together.
fn overlay_valid_at(
    base: &mut toml::Value,
    path: &mut Vec<String>,
    overlay: &toml::Value,
    rejected: &mut Vec<String>,
) {
    let Some(entries) = overlay.as_table() else {
        return;
    };
    for (key, entry) in entries {
        path.push(key.clone());
        let mut partial = entry.clone();
        for segment in path.iter().rev() {
            let mut table = toml::value::Table::new();
            table.insert(segment.clone(), partial);
            partial = toml::Value::Table(table);
        }
        let mut candidate = base.clone();
        merge_partial(&mut candidate, &partial);
        match parse_error(&candidate) {
            None => *base = candidate,
            Some(_)
                if entry.is_table() && value_at(base, path).is_some_and(toml::Value::is_table) =>
            {
                overlay_valid_at(base, path, entry, rejected);
            }
            Some(e) => rejected.push(format!("{} ({})", path.join("."), e.trim())),
        }
        path.pop();
    }
}

/// Why `value` does not parse as a [`Config`], if it does not.
fn parse_error(value: &toml::Value) -> Option<String> {
    value
        .clone()
        .try_into::<Config>()
        .err()
        .map(|e| e.message().to_string())
}

/// The value at the dotted `path` inside `value`.
fn value_at<'a>(value: &'a toml::Value, path: &[String]) -> Option<&'a toml::Value> {
    path.iter().try_fold(value, |v, key| v.get(key.as_str()))
}

impl Config {
    /// Load configuration from the global file.
    ///
    /// On first run, creates the file with `Config::default()`. Returns a
    /// fully `normalize()`-d `Config` (all `Option<KeyBinding>` slots
    /// filled). A legacy flat file (no tables at all) is converted in
    /// memory; the file keeps its shape until the next save.
    ///
    /// Does **not** layer in the per-project override file. For startup
    /// use [`Config::load_layered`].
    pub fn load() -> Result<Self> {
        let config_path = Self::config_file_path()?;

        if config_path.exists() {
            let original_content = std::fs::read_to_string(&config_path)?;

            // Try parsing as new structured format first
            let parsed = toml::from_str::<toml::Value>(&original_content).and_then(|mut value| {
                migrate_legacy(&mut value);
                value.try_into()
            });
            let mut config: Self = match parsed {
                Ok(config) => config,
                // Only a file without any table is the legacy flat format.
                // Anything else that fails is a structured file with a bad
                // value, and `LegacyConfig` — which accepts every document —
                // would quietly turn it into defaults.
                Err(e) if !is_flat(&original_content) => return Err(e.into()),
                Err(_) => {
                    let legacy: LegacyConfig = toml::from_str(&original_content)?;
                    let mut config: Config = legacy.into();
                    config.normalize();
                    return Ok(config);
                }
            };

            // Fill None keybinding values with defaults. The on-disk file is
            // intentionally not rewritten here — diff-form files would otherwise
            // expand back to fully-normalized content on every startup.
            config.normalize();
            Ok(config)
        } else {
            // First run: don't write a config file with the defaults — that
            // would defeat the diff-against-defaults invariant. The file is
            // created lazily, the first time the user changes a setting.
            let mut config = Self::default();
            config.normalize();
            Self::ensure_themes_dir()?;
            Ok(config)
        }
    }

    /// Load configuration with the layered global → project overlay.
    ///
    /// The result holds:
    /// - `effective`: `Config::default()` overlaid with the global file
    ///   (if any) and then with `<project_root>/.termide/config.toml`
    ///   (if any). This is what the running app sees.
    /// - `global_layer`: the same minus the project overlay — the baseline
    ///   used when computing diffs for the project file.
    /// - `warnings`: what had to be left out, for the caller to log once the
    ///   logger is up.
    ///
    /// When `custom_global` is `Some`, layering is bypassed: the file is
    /// loaded as the entire effective config, and `global_layer` is a
    /// clone of it. This preserves the historical `--config` semantics
    /// where the user-supplied file is the single source of truth.
    pub fn load_layered(
        custom_global: Option<&Path>,
        project_root: &Path,
    ) -> Result<LayeredConfig> {
        if let Some(path) = custom_global {
            let cfg = Self::load_from(path)?;
            return Ok(LayeredConfig {
                effective: cfg.clone(),
                global_layer: cfg,
                warnings: Vec::new(),
            });
        }

        let global_path = Self::config_file_path()?;
        let global_existed = global_path.exists();
        let loaded = Self::load_layers(Some(&global_path), &project_config_path(project_root))?;

        // Make sure the themes directory exists on first run.
        if !global_existed {
            Self::ensure_themes_dir()?;
        }
        Ok(loaded)
    }

    /// Overlay the files at `global_path` and `project_path`, where they
    /// exist, on the built-in defaults.
    ///
    /// A file that cannot be read keeps only what is valid in it: settings
    /// with a wrong type or value are left out one by one rather than
    /// dropping the whole file, and a file that is not TOML at all is left
    /// out entirely. Either way the file is copied to `<name>.bak` first,
    /// because the next save writes the running config over it and would
    /// otherwise lose what was left out.
    fn load_layers(global_path: Option<&Path>, project_path: &Path) -> Result<LayeredConfig> {
        let mut value = toml::Value::try_from(Self::default())?;
        let mut warnings = Vec::new();

        if let Some(path) = global_path {
            overlay_file(&mut value, path, &mut warnings);
        }
        // The global layer (defaults + global) is the baseline for
        // diff-saving the project file later.
        let global_layer_value = value.clone();
        overlay_file(&mut value, project_path, &mut warnings);

        // Every overlaid key was checked, so both layers parse.
        let mut effective: Self = value.try_into()?;
        effective.normalize();
        let mut global_layer: Self = global_layer_value.try_into()?;
        global_layer.normalize();

        Ok(LayeredConfig {
            effective,
            global_layer,
            warnings,
        })
    }

    /// Load configuration from a specific file path.
    ///
    /// Unlike `load()`, this does not create the file if it doesn't exist
    /// and does not auto-save normalized content back.
    pub fn load_from(path: &std::path::Path) -> Result<Self> {
        let content = std::fs::read_to_string(path)?;
        let mut value: toml::Value = toml::from_str(&content)?;
        migrate_legacy(&mut value);
        let mut config: Self = value.try_into()?;
        config.normalize();
        Ok(config)
    }

    /// Write only the fields that differ from `baseline` to `path`.
    ///
    /// Both operands are serialized to `toml::Value` and `diff_toml` is
    /// applied. The result is rendered as pretty TOML and written to
    /// `path`, creating any missing parent directories. When the diff is
    /// empty the file is written as an empty document — callers that
    /// want different behaviour (e.g. delete an empty file) should
    /// inspect the diff themselves.
    pub fn save_to(&self, path: &Path, baseline: &Config) -> Result<()> {
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }

        let actual_value = toml::Value::try_from(self)?;
        let baseline_value = toml::Value::try_from(baseline)?;
        let diff = diff_toml(&actual_value, &baseline_value)
            .unwrap_or_else(|| toml::Value::Table(Default::default()));

        let content = toml::to_string_pretty(&diff)?;
        std::fs::write(path, content)?;
        Ok(())
    }

    /// Whether this config holds anything other than the shipped defaults.
    ///
    /// What "Reset to Defaults" acts on, and therefore what decides whether
    /// that button has any work to do. Deliberately not the same question as
    /// "are there unsaved edits": a config saved months ago still differs from
    /// the defaults, and resetting it is exactly what the button is for.
    pub fn differs_from_defaults(&self) -> bool {
        let mut defaults = Config::default();
        defaults.normalize();
        let Ok(actual) = toml::Value::try_from(self) else {
            return false;
        };
        let Ok(baseline) = toml::Value::try_from(defaults) else {
            return false;
        };
        crate::diff::diff_toml(&actual, &baseline).is_some()
    }

    /// Save the user's global config: only fields differing from the
    /// built-in defaults are written.
    ///
    /// The baseline is normalised first. `Config::default()` derives its
    /// keybindings, so every one of them is `None` there, while the running
    /// config has them all filled in — diffing against the raw default wrote
    /// the entire binding table into the user's file on the first save. Once
    /// written, those values stop being defaults: a binding added in a later
    /// version then collides with the frozen copy instead of appearing.
    pub fn save_global(&self) -> Result<()> {
        let path = Self::config_file_path()?;
        let mut default = Config::default();
        default.normalize();
        self.save_to(&path, &default)
    }

    /// Save a per-project override at `<project_root>/.termide/config.toml`:
    /// only fields differing from the supplied `global_layer` baseline are
    /// written. `global_layer` should be the `Config` that the global file
    /// would produce when overlaid on `Config::default()` — i.e. the
    /// `global_layer` value returned by [`Config::load_layered`].
    pub fn save_project(&self, project_root: &Path, global_layer: &Config) -> Result<()> {
        let path = project_config_path(project_root);
        self.save_to(&path, global_layer)
    }

    /// Backwards-compatible alias for [`Config::save_global`]. Older call
    /// sites used to write the full config to disk; the diff-against-
    /// defaults shrink is now applied unconditionally.
    pub fn save(&self) -> Result<()> {
        self.save_global()
    }

    /// Get path to config file.
    pub fn config_file_path() -> Result<PathBuf> {
        Ok(get_config_dir()?.join("config.toml"))
    }

    /// Get path to themes directory.
    pub fn get_themes_dir() -> Result<PathBuf> {
        Ok(get_config_dir()?.join("themes"))
    }

    /// Check if path is the config file.
    pub fn is_config_file(path: &std::path::Path) -> bool {
        Self::config_file_path().map(|p| p == path).unwrap_or(false)
    }

    /// Validate config content.
    pub fn validate_content(content: &str) -> Result<Config> {
        toml::from_str(content).map_err(|e| anyhow::anyhow!("{}", e))
    }

    /// Ensure themes directory exists.
    fn ensure_themes_dir() -> Result<()> {
        let themes_dir = Self::get_themes_dir()?;
        if !themes_dir.exists() {
            std::fs::create_dir_all(themes_dir)?;
        }
        Ok(())
    }
}

#[cfg(test)]
mod save_baseline_tests {
    use super::*;

    /// Saving must not write out settings the user never touched.
    ///
    /// `Config::default()` derives its keybindings, so they are all `None`
    /// there while the running config has them filled in by `normalize()`.
    /// Diffing against the raw default therefore wrote the entire binding
    /// table into the user's file on the very first save — and a binding
    /// frozen that way stops tracking the defaults, so a later version that
    /// adds or moves one collides with the copy instead of applying it.
    #[test]
    fn saving_an_untouched_config_writes_nothing() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");

        let mut config = Config::default();
        config.normalize();

        let mut baseline = Config::default();
        baseline.normalize();
        config.save_to(&path, &baseline).unwrap();

        let written = std::fs::read_to_string(&path).unwrap();
        assert!(
            !written.contains("quit"),
            "default bindings must not be frozen into the file:\n{written}"
        );
        assert!(
            written.trim().is_empty(),
            "an untouched config should write an empty file, got:\n{written}"
        );
    }

    /// What the user did change still round-trips.
    #[test]
    fn saving_keeps_the_settings_that_differ() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");

        let mut config = Config::default();
        config.normalize();
        config.general.theme = "dracula".to_string();

        let mut baseline = Config::default();
        baseline.normalize();
        config.save_to(&path, &baseline).unwrap();

        let written = std::fs::read_to_string(&path).unwrap();
        assert!(written.contains("dracula"), "got:\n{written}");

        let reloaded = Config::load_from(&path).unwrap();
        assert_eq!(reloaded.general.theme, "dracula");
    }
}

#[cfg(test)]
mod ai_connection_migration_tests {
    use super::*;

    fn migrated(text: &str) -> Config {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");
        std::fs::write(&path, text).unwrap();
        Config::load_from(&path).unwrap()
    }

    #[test]
    fn a_single_endpoint_in_ai_becomes_the_default_connection() {
        let config = migrated(
            r#"
            [ai]
            provider = "openai_compatible"
            model = "qwen"
            max_tokens_per_turn = 0
            "#,
        );
        assert_eq!(config.ai.default_connection(), Some("default"));
        let connection = &config.ai.connections["default"];
        assert_eq!(connection.model, "qwen");
        // What the file left out keeps the default it had.
        assert_eq!(connection.base_url, Connection::default().base_url);
        assert_eq!(config.ai.max_tokens_per_turn, 0);
        // Saved, the file has the new shape only.
        let saved = toml::to_string(&toml::Value::try_from(&config).unwrap()).unwrap();
        assert!(saved.contains("[ai.connections.default]"), "{saved}");
    }

    #[test]
    fn a_saved_connection_keeps_only_the_fields_it_sets() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");
        let mut config = Config::default();
        config.normalize();
        let baseline = config.clone();
        config.ai.connections.insert(
            "Codex".into(),
            Connection {
                provider: "codex".into(),
                ..Connection::default()
            },
        );
        config.save_to(&path, &baseline).unwrap();
        let saved = std::fs::read_to_string(&path).unwrap();
        assert_eq!(
            saved.trim(),
            "[ai.connections.Codex]\nprovider = \"codex\"",
            "{saved}"
        );
    }

    #[test]
    fn without_the_old_fields_there_are_no_connections() {
        let config = migrated("[ai]\nmax_tokens_per_turn = 1\n");
        assert!(config.ai.connections.is_empty());
        assert_eq!(config.ai.default_connection(), None);
    }

    #[test]
    fn the_old_fold_switch_becomes_its_mode() {
        let config = migrated("[ai]\nautofold = false\n");
        assert_eq!(config.ai.fold_blocks, FoldBlocks::Never);
        let config = migrated("[ai]\nautofold = true\n");
        assert_eq!(config.ai.fold_blocks, FoldBlocks::OnFinish);
        let config = migrated("[ai]\n");
        assert_eq!(config.ai.fold_blocks, FoldBlocks::Immediately);
    }

    #[test]
    fn a_named_default_and_an_existing_connection_are_kept() {
        let config = migrated(
            r#"
            [ai]
            model = "old"
            connection = "cloud"
            [ai.connections.cloud]
            provider = "anthropic_compatible"
            [ai.connections.default]
            model = "kept"
            "#,
        );
        assert_eq!(config.ai.default_connection(), Some("cloud"));
        assert_eq!(config.ai.connections["default"].model, "kept");
    }
}

#[cfg(test)]
mod layered_load_tests {
    use super::*;

    /// Load `global` (and `project`, when given) through the layered path
    /// the app starts with.
    fn layered(global: &str, project: Option<&str>) -> (LayeredConfig, tempfile::TempDir) {
        let dir = tempfile::tempdir().unwrap();
        let global_path = dir.path().join("config.toml");
        std::fs::write(&global_path, global).unwrap();
        let project_path = dir.path().join("project.toml");
        if let Some(project) = project {
            std::fs::write(&project_path, project).unwrap();
        }
        let loaded = Config::load_layers(Some(&global_path), &project_path).unwrap();
        (loaded, dir)
    }

    fn binding(text: &str) -> Option<KeyBinding> {
        Some(KeyBinding::Single(text.to_string()))
    }

    /// The defaults already hold `project_retention_days`; merging the old
    /// spelling next to it used to be a duplicate field that reset the whole
    /// config to defaults.
    #[test]
    fn the_old_retention_key_is_read_on_the_layered_path() {
        let (loaded, _dir) = layered(
            "[general]\ntheme = \"nord\"\nsession_retention_days = 7\n",
            None,
        );
        assert!(loaded.warnings.is_empty(), "{:?}", loaded.warnings);
        assert_eq!(loaded.effective.general.project_retention_days, 7);
        assert_eq!(loaded.effective.general.theme, "nord");
    }

    #[test]
    fn old_keybinding_names_are_read_on_the_layered_path() {
        let (loaded, _dir) = layered(
            "[general.keybindings]\nopen_sessions = \"Alt+1\"\nnew_session = \"Alt+2\"\ndetach_session = \"Alt+3\"\n",
            Some("[general.keybindings]\nopen_projects = \"Alt+4\"\n"),
        );
        assert!(loaded.warnings.is_empty(), "{:?}", loaded.warnings);
        let keys = &loaded.effective.general.keybindings;
        assert_eq!(keys.open_projects, binding("Alt+4"));
        assert_eq!(keys.new_project, binding("Alt+2"));
        assert_eq!(keys.detach_instance, binding("Alt+3"));
        assert_eq!(
            loaded.global_layer.general.keybindings.open_projects,
            binding("Alt+1")
        );
    }

    #[test]
    fn with_both_spellings_the_new_one_wins() {
        let (loaded, _dir) = layered(
            "[general]\nsession_retention_days = 7\nproject_retention_days = 9\n",
            None,
        );
        assert!(loaded.warnings.is_empty(), "{:?}", loaded.warnings);
        assert_eq!(loaded.effective.general.project_retention_days, 9);
    }

    #[test]
    fn an_invalid_value_leaves_out_only_itself() {
        let text = "[general]\ntheme = \"nord\"\nproject_retention_days = \"many\"\n[editor]\ntab_size = 8\n";
        let (loaded, dir) = layered(text, None);
        let config = &loaded.effective;
        assert_eq!(config.general.theme, "nord");
        assert_eq!(config.editor.tab_size, 8);
        assert_eq!(
            config.general.project_retention_days,
            defaults::PROJECT_RETENTION_DAYS
        );
        assert_eq!(loaded.warnings.len(), 1);
        assert!(
            loaded.warnings[0].contains("general.project_retention_days"),
            "{:?}",
            loaded.warnings
        );
        // Saving writes the running config over the file, so the original
        // is copied aside first.
        let backup = dir.path().join("config.toml.bak");
        assert_eq!(std::fs::read_to_string(backup).unwrap(), text);
    }

    #[test]
    fn a_file_that_is_not_toml_is_left_out_and_kept() {
        let (loaded, dir) = layered("[general\ntheme = ", Some("[editor]\ntab_size = 2\n"));
        assert_eq!(loaded.effective.editor.tab_size, 2);
        assert_eq!(loaded.warnings.len(), 1);
        assert!(dir.path().join("config.toml.bak").exists());
    }

    #[test]
    fn an_invalid_project_value_keeps_the_global_layer() {
        let (loaded, dir) = layered(
            "[editor]\ntab_size = 8\n",
            Some("[editor]\ntab_size = -1\nword_wrap = false\n"),
        );
        assert_eq!(loaded.effective.editor.tab_size, 8);
        assert!(!loaded.effective.editor.word_wrap);
        assert!(loaded.effective.editor.show_git_diff);
        assert_eq!(loaded.warnings.len(), 1);
        assert!(loaded.warnings[0].contains("editor.tab_size"));
        assert!(!dir.path().join("config.toml.bak").exists());
        assert!(dir.path().join("project.toml.bak").exists());
    }

    #[test]
    fn a_partial_compaction_table_keeps_the_other_defaults() {
        let (loaded, _dir) = layered("[ai.compaction]\nenabled = false\n", None);
        assert!(loaded.warnings.is_empty(), "{:?}", loaded.warnings);
        let compaction = loaded.effective.ai.compaction;
        assert!(!compaction.enabled);
        assert_eq!(
            compaction.reserve_tokens,
            termide_agent_core::CompactionPolicy::default().reserve_tokens
        );
    }

    #[test]
    fn only_a_file_without_tables_is_the_flat_format() {
        assert!(is_flat("theme = \"nord\"\ntab_size = 2\n"));
        assert!(is_flat(""));
        assert!(!is_flat("[general]\ntheme = 1\n"));
        assert!(!is_flat("not toml ["));
    }
}

#[cfg(test)]
mod lsp_servers_tests {
    use super::*;

    const USER_RUST: &str = r#"
        [lsp.servers.rust]
        command = "/opt/rust-analyzer"

        [lsp.servers.zig]
        command = "zls"
    "#;

    fn assert_user_entries_over_builtins(config: &Config) {
        let servers = &config.lsp.servers;
        assert_eq!(servers["rust"].command, "/opt/rust-analyzer");
        // Fields the entry leaves out keep the built-in's values.
        assert_eq!(servers["rust"].root_markers, vec!["Cargo.toml".to_string()]);
        assert_eq!(servers["zig"].command, "zls");
        for builtin in ["go", "php", "terraform", "dockerfile", "typescriptreact"] {
            assert!(servers.contains_key(builtin), "{builtin} was dropped");
        }
    }

    /// Saving a config file from the editor parses it directly.
    #[test]
    fn a_parsed_config_keeps_the_builtin_servers() {
        let config = Config::validate_content(USER_RUST).unwrap();
        assert_user_entries_over_builtins(&config);
    }

    /// `--config` loads a single file directly.
    #[test]
    fn a_config_file_loaded_alone_keeps_the_builtin_servers() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");
        std::fs::write(&path, USER_RUST).unwrap();
        assert_user_entries_over_builtins(&Config::load_from(&path).unwrap());
    }

    #[test]
    fn the_layered_path_keeps_the_builtin_servers() {
        let dir = tempfile::tempdir().unwrap();
        let global = dir.path().join("config.toml");
        std::fs::write(&global, USER_RUST).unwrap();
        let loaded = Config::load_layers(Some(&global), &dir.path().join("none.toml")).unwrap();
        assert!(loaded.warnings.is_empty(), "{:?}", loaded.warnings);
        assert_user_entries_over_builtins(&loaded.effective);
    }

    /// The merged built-ins are defaults, not user settings: a save writes
    /// back only what the user set.
    #[test]
    fn saving_writes_only_the_user_entries() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("config.toml");
        let config = Config::validate_content(USER_RUST).unwrap();
        let mut baseline = Config::default();
        baseline.normalize();
        config.save_to(&path, &baseline).unwrap();

        let written: toml::Value =
            toml::from_str(&std::fs::read_to_string(&path).unwrap()).unwrap();
        let servers = written["lsp"]["servers"].as_table().unwrap();
        let mut keys: Vec<_> = servers.keys().map(String::as_str).collect();
        keys.sort_unstable();
        assert_eq!(keys, ["rust", "zig"]);
        assert_eq!(
            servers["rust"]
                .as_table()
                .unwrap()
                .keys()
                .collect::<Vec<_>>(),
            ["command"]
        );
    }

    #[test]
    fn jsx_languages_have_a_builtin_server() {
        let servers = Config::default().lsp.servers;
        assert_eq!(
            servers["typescriptreact"].command,
            servers["typescript"].command
        );
        assert_eq!(
            servers["javascriptreact"].command,
            servers["javascript"].command
        );
    }
}
