//! Repo/branch selector dropdown filtering for the Git Status Panel.

use termide_git::{self as git};
use termide_ui::fuzzy::{rank, Query};

use crate::GitStatusPanel;

impl GitStatusPanel {
    /// Return indices into `self.branches` that match the current filter.
    /// When the filter is empty, returns all indices.
    pub(crate) fn filtered_branch_indices(&self) -> Vec<usize> {
        let mut query = Query::fuzzy_path(&self.branch_filter);
        rank(self.branches.iter().map(|b| query.score(b)))
    }

    /// Index into `self.branches` of the branch the panel shows.
    pub(crate) fn shown_branch_index(&self) -> usize {
        let shown = self.shown_branch();
        self.branches
            .iter()
            .position(|b| Some(b.as_str()) == shown)
            .unwrap_or(0)
    }

    /// Dropdown label of the branch at `idx`: `●` marks the main copy's
    /// branch, `⧉` one checked out in a linked worktree.
    pub(crate) fn branch_label(&self, idx: usize) -> String {
        let name = &self.branches[idx];
        git::branch_label(
            name,
            self.branch.as_deref() == Some(name.as_str()),
            self.worktrees.contains_key(name),
        )
    }

    /// Reset the branch filter state.
    pub(crate) fn reset_branch_filter(&mut self) {
        self.branch_filter.clear();
        self.show_branch_filter = false;
    }

    /// Return indices into repo list that match the current filter.
    pub(crate) fn filtered_repo_indices(&self) -> Vec<usize> {
        let repos = self.repo_manager.repos();
        let mut query = Query::fuzzy_path(&self.repo_filter);
        rank(repos.iter().map(|p| query.score(&git::get_repo_name(p))))
    }

    /// Reset the repo filter state.
    pub(crate) fn reset_repo_filter(&mut self) {
        self.repo_filter.clear();
        self.show_repo_filter = false;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn panel() -> GitStatusPanel {
        GitStatusPanel::new(&[])
    }

    #[test]
    fn empty_branch_filter_returns_all_indices() {
        let mut p = panel();
        p.branches = vec!["main".into(), "dev".into()];
        assert_eq!(p.filtered_branch_indices(), vec![0, 1]);
    }

    #[test]
    fn branch_filter_matches_case_insensitive_substrings() {
        let mut p = panel();
        p.branches = vec![
            "main".into(),
            "feature/login".into(),
            "Feature/Logout".into(),
        ];
        p.branch_filter = "log".into();
        assert_eq!(p.filtered_branch_indices(), vec![1, 2]);
    }

    #[test]
    fn branch_filter_with_no_match_is_empty() {
        // The Enter handler relies on this: an empty result means `.get(cursor)`
        // yields None, so no branch is checked out (previously it fell back to
        // index 0 and checked out the first branch).
        let mut p = panel();
        p.branches = vec!["main".into(), "dev".into()];
        p.branch_filter = "zzz".into();
        assert!(p.filtered_branch_indices().is_empty());
    }
}
